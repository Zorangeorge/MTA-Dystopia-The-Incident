local screenX, screenY = guiGetScreenSize()

local shoutText = false
local shoutDestroyTimer = false

addEvent("shoutallOnScreen", true)
addEventHandler("shoutallOnScreen", localPlayer, function(text, duration)
    -- disable current shout
    if isTimer(shoutDestroyTimer) then
        killTimer(shoutDestroyTimer)
        shoutText = false
        removeEventHandler("onClientRender", root, renderShoutText)
    end
        
    -- create shout
    shoutText = text
    addEventHandler("onClientRender", root, renderShoutText)
    
    -- disable it after 'x' seconds
    shoutDestroyTimer = setTimer(function()
        killTimer(shoutDestroyTimer)
        shoutText = false
        removeEventHandler("onClientRender", root, renderShoutText)
    end, duration * 1000, 1)
end)

function renderShoutText()
    if shoutText then
        dxDrawText(shoutText, screenX/4, screenY/4, screenX/4*3, screenY/4*3, tocolor(220, 20, 20, 220), 2, "bankgothic", "center", "top", false, true)
    end
end