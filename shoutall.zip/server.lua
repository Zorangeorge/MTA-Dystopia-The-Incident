addCommandHandler("shoutall", function(player, cmd, durationSec, ...)
    local accName = getAccountName(getPlayerAccount(player))
    if isObjectInACLGroup("user."..accName, aclGetGroup("Admin")) then
        
        local name = getPlayerName(player)
        local text = table.concat({...}," ")
            
        if not durationSec or not tonumber(durationSec) or tonumber(durationSec) <= 0 or not text or #text <= 0 then
            outputChatBox("[USE] /"..cmd.." <show duration seconds> <text>", root, 255, 255, 255, true)
            return
        end
            
            
        -- "\n" this is the linebreak, because we need the text under the admin's name.
        local finalShoutText = name..": \n"..text
        
        outputChatBox("#ff0000(#FF0040Shoutall#ff0000) "..finalShoutText, root, 255, 255, 255, true) -- send it to chat
        triggerClientEvent(root, "shoutallOnScreen", root, finalShoutText, tonumber(durationSec)) -- send it to players (client side)
    end
end)