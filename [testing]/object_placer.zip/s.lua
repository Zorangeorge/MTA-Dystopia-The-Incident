
-- Created by Spanky
-- Made in Germany
-- Free to use.
-- If youre a bro, do not remove my name!

function create(player, command, id)
local x,y,z = getElementPosition(player)
ha = createObject(id,x,y,z)
attachElements(ha,player,0,1,0)
end
addCommandHandler( "co", create )

function place(player)
detachElements(ha)
end
addCommandHandler( "po", place )

function rotate(player,command,rotate)
r = rotate
local x,y,z = getElementPosition(ha)
moveObject(ha,500,x,y,z,0,0,r)
end
addCommandHandler( "ro", rotate )