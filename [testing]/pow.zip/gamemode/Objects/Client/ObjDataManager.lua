-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjDataManager = {}
ObjDataManager.__index = ObjDataManager

function ObjDataManager.create()
  local _objDataManager = {}
  setmetatable(_objDataManager, ObjDataManager)
  _objDataManager._meta = {}
  _objDataManager._world = {}
  _objDataManager._cameras = {}
  _objDataManager._spawnpoints = {}
  _objDataManager._squadroles = {}
  _objDataManager._squadweapons = {}
  _objDataManager._vehicles = {}
  _objDataManager._projectiles = {}
  _objDataManager._engine = {}
  _objDataManager._objectsequences = {}
  _objDataManager._refuelspots = {}
  _objDataManager._repairspots = {}
  _objDataManager._warfactories = {}
  _objDataManager._ammodepots = {}
  return _objDataManager
end

-- init data manager
function ObjDataManager:init(data)
  self._meta = data["meta"]
  self._world = data["world"]
  self._cameras = data["cameras"]
  self._spawnpoints = data["spawnpoints"]
  self._squadroles = data["squadroles"]
  self._squadweapons = data["squadweapons"]
  self._vehicles = data["vehicles"]
  self._projectiles = data["projectiles"]
  self._engine = data["engine"]
  self._objectsequences = data["objectsequences"]
  self._refuelspots = data["refuelspots"]
  self._repairspots = data["repairspots"]
  self._warfactories = data["warfactories"]
  self._ammodepots = data["ammodepots"]
end

function ObjDataManager:getMetaData()
  return self._meta
end

function ObjDataManager:getWorldData()
  return self._world
end

function ObjDataManager:getCamerasData()
  return self._cameras
end

function ObjDataManager:getSpawnpointsData()
  return self._spawnpoints
end

function ObjDataManager:getSquadrolesData()
  return self._squadroles
end

function ObjDataManager:getSquadweaponsData()
  return self._squadweapons
end

function ObjDataManager:getVehiclesData()
  return self._vehicles
end

function ObjDataManager:getProjectilesData()
  return self._projectiles
end

function ObjDataManager:getEngineData()
  return self._engine
end

function ObjDataManager:getObjectSequencesData()
  return self._objectsequences
end

function ObjDataManager:getRefuelspotsData()
  return self._refuelspots
end

function ObjDataManager:getRepairspotsData()
  return self._repairspots
end

function ObjDataManager:getWarfactoriesData()
  return self._warfactories
end

function ObjDataManager:getAmmodepotsData()
  return self._ammodepots
end

-- Author: Ace_Gambit