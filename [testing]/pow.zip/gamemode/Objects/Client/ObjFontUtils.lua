-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjFontUtils = {}
ObjFontUtils.__index = ObjFontUtils

function ObjFontUtils.create()
  local _objFontUtils = {}
  setmetatable(_objFontUtils, ObjFontUtils)
  return _objFontUtils
end

-- init font utils
function ObjFontUtils:init()
  -- nah, don't need it...
end

function ObjFontUtils:toFilename(str)
  local result = ""
  for i = 1, (4 - string.len(str)) do
    result = result .. string.char(48)
  end
  return result .. str
end

-- returns table
function ObjFontUtils:getSplitStr(str, fontName)
  local tbl = {}
  local charTbl = {}
  if (str ~= "") then
    for i = 1, string.len(str) do
      -- get ASCII codes and create path
      table.insert(tbl, "data/fonts/" .. fontName .. "/" .. self:toFilename(string.byte(string.sub(str, i, i))) .. ".png")
      table.insert(charTbl, self:toFilename(string.byte(string.sub(str, i, i))))
    end
  end
  return tbl, charTbl
end

-- Author: Ace_Gambit