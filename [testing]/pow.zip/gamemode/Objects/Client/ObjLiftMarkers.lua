-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjLiftMarkers = {}
ObjLiftMarkers.__index = ObjLiftMarkers

function ObjLiftMarkers.create(id)
  local _objLiftMarkers = {}
  setmetatable(_objLiftMarkers, ObjLiftMarkers)
  _objLiftMarkers._data = nil
  _objLiftMarkers._markers = {}
  return _objLiftMarkers
end

-- init lift markers
function ObjLiftMarkers:init(data)
  local count = 500
  local color = nil
  self._data = data
  for k, v in ipairs(self._data["lifts"]) do
    -- create markers
    for kc, vc in ipairs(v["triggers"]) do
      color = split(vc[6], string.byte(' '))
      self._markers[count] = ObjClientMarker.create(tonumber(vc[2]), tonumber(vc[3]), tonumber(vc[4]), "cylinder", tonumber(vc[5]), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, count)
      count = count + 1
    end
  end
end

function ObjLiftMarkers:Tick()
  for k, v in pairs(self._markers) do
    self._markers[k]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjLiftMarkers:triggerPulse(id, start)
  self._markers[id]:triggerPulse(start)
end

function ObjLiftMarkers:lockToMarkerByID(player, id, locked)
  local slot = getPlayerWeaponSlot()
  if (not slot) then
    slot = 5
  end
  self._markers[id]:lockToMarker(player:getSource(), locked)
  player:setWeaponSlot(slot)
end

function ObjLiftMarkers:unlockFromMarkers(source)
  for k, v in ipairs(self._markers) do
    v:lockToMarker(source, false)
  end
end

-- Author: Ace_Gambit