-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientProjectiles = {}
ObjClientProjectiles.__index = ObjClientProjectiles

function ObjClientProjectiles.create()
  local _objClientProjectiles = {}
  setmetatable(_objClientProjectiles, ObjClientProjectiles)
  _objClientProjectiles._source = nil
  _objClientProjectiles._data = nil
  _objClientProjectiles._projectiles = {}
  return _objClientProjectiles
end

-- init client projectiles
function ObjClientProjectiles:init(source, data)
  local id = ""
  self._source = source
  self._data = data
  -- create projectiles
  for k, v in pairs(self._data["projectile"]) do
    id = self._data["projectile"][k]["id"]
    self._projectiles[id] = ObjClientProjectile.create(
      id,
      self._data["projectile"][k]["object-id"],
      tonumber(self._data["projectile"][k]["force"]),
      tonumber(self._data["projectile"][k]["projectile-type"]),
      tonumber(self._data["projectile"][k]["z-offset"]),
      tonumber(self._data["projectile"][k]["max-projectiles"]),
      self._data["projectile"][k]["creator-type"]
      )
  end
end

function ObjClientProjectiles:getProjectileByID(id)
  return self._projectiles[id]
end

function ObjClientProjectiles:getMaxProjectiles(id)
  return self:getProjectileByID(id):getMaxProjectiles()
end

function ObjClientProjectiles:getCreatorTypeByID(id)
  return self:getProjectileByID(id):getCreatorType()
end

function ObjClientProjectiles:resetTotalFiredByID(id)
  self:getProjectileByID(id):setTotalFired(0)
end

function ObjClientProjectiles:createClusterArea(x, y)
  local swap = {1, -1}
  return x + (math.random(1, 20) * swap[math.random(1, 2)]), y + (math.random(1, 20) * swap[math.random(1, 2)])
end

function ObjClientProjectiles:Process(id)
  local tmpProjectile = self:getProjectileByID(id)
  local tmpSource = getElementByID(tmpProjectile:getObjectID())
  local x, y, z = 0, 0, 0
  local vX, vY, vZ = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  local pX, pY, pZ = 0, 0, 0
  local force = 0
  local projectileType = 0
  local targets = {}
  local target = false
  if (tmpSource ~= false and getElementType(tmpSource) == "object") then
    x, y, z = getElementPosition(tmpSource)
    rotX, rotY, rotZ = getObjectRotation(tmpSource)
    x = x - math.sin(math.rad(rotZ)) * 2.5
    y = y + math.cos(math.rad(rotZ)) * 2.5
    force = tmpProjectile:getForce()
    projectileType = tmpProjectile:getProjectileType()
    if (tmpProjectile:getCreatorType() == "sam") then
      createProjectile(self._source, projectileType, x, y, z + 3.5 + tmpProjectile:getZOffSet(), force, self._source)
    end
    if (tmpProjectile:getCreatorType() == "barrage") then
      vX = math.sin (math.rad(-(rotZ))) * 1.2
      vY = math.cos(math.rad(-(rotZ))) * 1.2
      vZ = force
      createProjectile(self._source, projectileType, x, y, z + 3.5 + tmpProjectile:getZOffSet(), 0, nil, 0, 0, 0, vX, vY, vZ)
      createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 10, true, 1.0, false)
    end
    if (tmpProjectile:getCreatorType() == "ssm") then
      target = getElementByID("target" .. getPlayerName(self._source) .. id .. tmpProjectile:getTotalFired() + 1)
      if (target ~= false) then
        pX, pY, pZ = getElementPosition(self._source)
        pX, pY = self:createClusterArea(pX, pY)
        setElementPosition(target, pX, pY, pZ)
        createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 4, true, 1.0, false)
        createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 10, true, 1.0, false)
        createProjectile(self._source, 20, x, y, z + 3.5 + tmpProjectile:getZOffSet(), 0, target, 0, 0, 0, 0, 0, force)
      end
    end
    tmpProjectile:setTotalFired(tmpProjectile:getTotalFired() + 1)
    if (tmpProjectile:getTotalFired() >= tmpProjectile:getMaxProjectiles()) then
      triggerServerEvent("funcFreeProjectile", self._source, "funcFreeProjectile", {["id"] = id})
    end
  end
end

function ObjClientProjectiles:ProcessExplosion(id)
  local tmpProjectile = self:getProjectileByID(id)
  local tmpSource = getElementByID(tmpProjectile:getObjectID())
  local x, y, z = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  if (tmpSource ~= false and getElementType(tmpSource) == "object") then
    x, y, z = getElementPosition(tmpSource)
    rotX, rotY, rotZ = getObjectRotation(tmpSource)
    x = x - math.sin(math.rad(rotZ)) * 2.5
    y = y + math.cos(math.rad(rotZ)) * 2.5
    if (tmpProjectile:getCreatorType() == "barrage") then
      createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 10, true, 1.0, false)
    elseif (tmpProjectile:getCreatorType() == "ssm") then
      createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 4, true, 1.0, false)
      createExplosion(x, y, z + 3.5 + tmpProjectile:getZOffSet(), 10, true, 1.0, false)
    end
  end
end

-- Author: Ace_Gambit