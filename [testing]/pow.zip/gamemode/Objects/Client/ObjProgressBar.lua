-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjProgressBar = {}
ObjProgressBar.__index = ObjProgressBar

function ObjProgressBar.create(width, height, minVal, maxVal, position, outline)
  local _objProgressBar = {}
  setmetatable(_objProgressBar, ObjProgressBar)
  _objProgressBar._width = width
  _objProgressBar._height = height
  _objProgressBar._bar = nil
  _objProgressBar._progress = nil
  _objProgressBar._min = minVal
  _objProgressBar._max = maxVal
  _objProgressBar._position = position
  _objProgressBar._oldPos = position
  _objProgressBar._outline = outline
  _objProgressBar._step = width / maxVal
  _objProgressBar._fade = false
  _objProgressBar._alpha = 1.0
  return _objProgressBar
end

-- init progressbar
function ObjProgressBar:init()
  -- nah, don't need it...
end

function ObjProgressBar:focus()
    guiBringToFront(self._bar)
    guiBringToFront(self._progress)
end

function ObjProgressBar:Tick()
  if (self._fade and self._alpha > 0) then
    self._alpha = self._alpha - 0.05
    guiSetAlpha(self._bar, self._alpha)
    guiSetAlpha(self._progress, self._alpha)
  elseif (self._alpha <= 0) then
    self._fade = false
    self._alpha = 1.0
    guiSetVisible(self._bar, false)
    guiSetVisible(self._progress, false)
  end
end

function ObjProgressBar:setxy(x, y)
  local posXSet = 0
  local posYSet = 0
  local heightSet = 0
  if (self._outline) then
    self._step = (self._width - 6) / self._max
    posXSet = 3
    posYSet = 3
    widthSet = 6
    heightSet = 6
  end
guiSetPosition(self._bar, x, y, false)
guiSetPosition(self._progress, x+ posXSet, y+ posYSet, false)
end

-- create progressbar
function ObjProgressBar:createProgressBar(color, posX, posY)
  local posXSet = 0
  local posYSet = 0
  local heightSet = 0
  if (self._outline) then
    self._step = (self._width - 6) / self._max
    posXSet = 3
    posYSet = 3
    widthSet = 6
    heightSet = 6
  end
  self._bar = guiCreateStaticImage(posX, posY, self._width, self._height, "data/bars/bar-" .. color .. ".png", false)
  self._progress = guiCreateStaticImage(posX + posXSet, posY + posYSet, (self._position * self._step), self._height - heightSet, "data/bars/progress-" .. color .. ".png", false)
  guiSetVisible(self._bar, false)
  guiSetVisible(self._progress, false)
end

function ObjProgressBar:trimBar(width)
  if (self._outline and width > self._width - 6) then
    return self._width - 6
  elseif (not self._outline and width > self._width) then
    return self._width
  end
  return width
end

function ObjProgressBar:getHeightSet()
  if (self._outline) then
    return 6
  else
    return 0
  end
end

function ObjProgressBar:step()
  local heightSet = self:getHeightSet()
  self._position = self:trimBar(self._position + self._step)
  if (self._position < self._max) then
    guiSetSize(self._progress, self._position, self._height - heightSet, false)
  end
end

function ObjProgressBar:stepBack()
  local heightSet = self:getHeightSet()
  self._position = self:trimBar(self._position - self._step)
  if (self._position > self._min) then
    guiSetSize(self._progress, self._position, self._height - heightSet, false)
  end
end

function ObjProgressBar:stepMax()
  local heightSet = self:getHeightSet()
  self._position = self:trimBar(self._step * self._max)
  guiSetSize(self._progress, self._position, self._height - heightSet, false)
end

function ObjProgressBar:stepMin()
  local heightSet = self:getHeightSet()
  self._position = self:trimBar(self._step * self._min)
  guiSetSize(self._progress, self._position, self._height - heightSet, false)
end

function ObjProgressBar:show()
  self._fade = false
  self._alpha = 1.0
  guiSetAlpha(self._bar, self._alpha)
  guiSetAlpha(self._progress, self._alpha)
  guiSetVisible(self._bar, true)
  guiSetVisible(self._progress, true)
  self:focus()
end

function ObjProgressBar:hide()
  self._fade = true
end

function ObjProgressBar:setPosition(pos)
  local heightSet = 0
  if (self._outline) then
    heightSet = 6
  end
  self._position = self:trimBar(self._step * pos)
  if (self._oldPos ~= self._position) then
    if (self._position > self._min) then
      guiSetSize(self._progress, self._position, self._height - heightSet, false)
    end
    self._oldPos = self._position
  end
end

function ObjProgressBar:setMax(maxVal)
  self._max = maxVal
  self._step = self._width / self._max
end

-- Author: Ace_Gambit