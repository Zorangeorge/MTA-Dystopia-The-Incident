-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientPlayer = {}
ObjClientPlayer.__index = ObjClientPlayer

function ObjClientPlayer.create()
  local _objClientPlayer = {}
  setmetatable(_objClientPlayer, ObjClientPlayer)
  _objClientPlayer._source = nil
  _objClientPlayer._hud = {
      {
      "ammo",
      "area_name",
      "armour",
      "breath",
      "clock",
      "health",
      "money",
      "radar",
      "vehicle_name",
      "weapon"
      },
      {
      "ammo",
      "armour",
      "breath",
      "clock",
      "health",
      "radar",
      "weapon"
      }
                         }
  _objClientPlayer._firstSpawn = true
  -- NOTE: this flag is checked against the synced server flag!
  _objClientPlayer._protected = false
  return _objClientPlayer
end

-- init joined player
function ObjClientPlayer:init()
  -- nah, don't need it...
end

function ObjClientPlayer:callback()
  triggerServerEvent("callbackClient", self._source)
end

function ObjClientPlayer:getSource()
  return self._source
end

function ObjClientPlayer:setSource(source)
  self._source = source
end

function ObjClientPlayer:getFirstSpawn()
  return self._firstSpawn
end

function ObjClientPlayer:setFirstSpawn(firstSpawn)
  self._firstSpawn = firstSpawn
end

function ObjClientPlayer:setSkin(skin)
  triggerServerEvent("funcSetPlayerSkin", self._source, "funcSetPlayerSkin", {["skin"] = skin})
end

function ObjClientPlayer:setPosition(posX, posY, posZ, rot)
  triggerServerEvent("funcSpawnPlayer", self._source, "funcSpawnPlayer", {["posX"] = posX, ["posY"] = posY, ["posZ"] = posZ, ["rot"] = rot})
end

function ObjClientPlayer:hudHide()
  for k, v in ipairs(self._hud[1]) do
    showPlayerHudComponent(v, false)
  end
end

function ObjClientPlayer:hudShow()
  for k, v in ipairs(self._hud[2]) do
    showPlayerHudComponent(v, true)
  end
end

function ObjClientPlayer:getGameState()
  return getElementData(self._source, "gamestate")
end

function ObjClientPlayer:setGameState(gameState)
  setElementData(self._source, "gamestate", gameState)
end

function ObjClientPlayer:getBlip()
  triggerServerEvent("funcAttachBlip", self._source, "funcAttachBlip", nil)
end

function ObjClientPlayer:getProtected()
  return (self._protected and getElementData(self._source, "protected") == "1")
end

function ObjClientPlayer:setProtected(flag)
  self._protected = flag
end

function ObjClientPlayer:setWeaponSlot(slot)
  setPlayerWeaponSlot(getLocalPlayer(), slot)
end

-- Author: Ace_Gambit