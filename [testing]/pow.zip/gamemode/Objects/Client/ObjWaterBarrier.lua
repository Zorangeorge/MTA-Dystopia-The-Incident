-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjWaterBarrier = {}
ObjWaterBarrier.__index = ObjWaterBarrier

function ObjWaterBarrier.create()
  local _objWaterBarrier = {}
  setmetatable(_objWaterBarrier, ObjWaterBarrier)
  _objWaterBarrier._progressBars = nil
  _objWaterBarrier._timerUtils = nil
  _objWaterBarrier._textManager = nil
  _objWaterBarrier._running = false
  _objWaterBarrier._oldTick = 0
  return _objWaterBarrier
end

-- init water barrier
function ObjWaterBarrier:init(progressBars, timerUtils, textManager, screenX, screenY)
  self._progressBars = progressBars
  self._timerUtils = timerUtils
  self._textManager = textManager
  self._progressBars:createBar("PBarWaterBarrier", 168, 13, 0, 200, 0, "lightblue", (screenX / 2) - (168 / 2), (screenY / 2) - ((13 / 2) + 125), true)
end

function ObjWaterBarrier:Tick()
  if (self._progressBars:getBarByID("PBarWaterBarrier") ~= nil) then
    self._progressBars:TickByID("PBarWaterBarrier")
    if (self._oldTick ~= 0 and ((getTickCount() - self._oldTick) >= 5000)) then
      self._oldTick = 0
      self._progressBars:hideByID("PBarWaterBarrier")
      self._textManager:killAll()
    end
  end
end

function ObjWaterBarrier:setRunning(running)
  self._running = running
  if (self._running) then
    self._oldTick = 0
    self._progressBars:showByID("PBarWaterBarrier")
    self._textManager:triggerRoleText("waterbarrier")
    self._textManager:createInstructDsp({"waterbarrier", "blank"})
  else
    self._oldTick = getTickCount()
  end
end

function ObjWaterBarrier:getRunning()
  return self._running
end

function ObjWaterBarrier:killMeter()
  self._timerUtils:killTimerByID("TWaterBarrier")
  self._timerUtils:setCounterByID("CWaterBarrier", 0)
  self._progressBars:hideByID("PBarWaterBarrier")
  self._progressBars:setPositionByID("PBarWaterBarrier", 0)
  self._textManager:killAll()
end

function ObjWaterBarrier:step()
  if (self._progressBars:getBarByID("PBarWaterBarrier") == nil) then
    return
  end
  if (self._running) then
    if (self._timerUtils:getCounterByID("CWaterBarrier") < 200) then
      self._progressBars:stepByID("PBarWaterBarrier")
      self._timerUtils:counterByID("CWaterBarrier", 1)
    elseif (self._timerUtils:getCounterByID("CWaterBarrier") >= 200) then
      self:killMeter()
    end
  elseif (not self._running) then
    if (self._timerUtils:getCounterByID("CWaterBarrier") > 0) then
      self._progressBars:stepBackByID("PBarWaterBarrier")
      self._timerUtils:counterByID("CWaterBarrier", -1)
    elseif (self._timerUtils:getCounterByID("CWaterBarrier") <= 0) then
      self:killMeter()
    end
  end
end

-- Author: Ace_Gambit