-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjVehicleFuel = {}
ObjVehicleFuel.__index = ObjVehicleFuel

function ObjVehicleFuel.create()
  local _objVehicleFuel = {}
  setmetatable(_objVehicleFuel, ObjVehicleFuel)
  _objVehicleFuel._clientPlayer = nil
  _objVehicleFuel._vehicles = nil
  _objVehicleFuel._progressBars = nil
  _objVehicleFuel._textManager = nil
  _objVehicleFuel._refuelMarkers = nil
  _objVehicleFuel._maxFuel = 0
  _objVehicleFuel._maxRefuel = 0
  _objVehicleFuel._refuelBusy = false
  _objVehicleFuel._oldTick = 0
  return _objVehicleFuel
end

-- init vehicle fuel
function ObjVehicleFuel:init(clientPlayer, vehicles, progressBars, textManager, refuelMarkers, screenX, screenY)
  self._clientPlayer = clientPlayer
  self._vehicles = vehicles
  self._progressBars = progressBars
  self._textManager = textManager
  self._refuelMarkers = refuelMarkers
  self._progressBars:createBar("PBarVehicleFuel", 100, 13, 0, 0, 0, "darkblue", 60, 430, true)
  self._progressBars:createBar("PBarVehicleRefuel", 168, 13, 0, 0, 0, "fuelblue", (screenX / 2) - (168 / 2), (screenY / 2) - ((13 / 2) + 125), true)
end

function ObjVehicleFuel:Tick()
  if (self._progressBars:getBarByID("PBarVehicleFuel") ~= nil) then
    self._progressBars:TickByID("PBarVehicleFuel")
  end
  if (self._progressBars:getBarByID("PBarVehicleRefuel") ~= nil) then
    self._progressBars:TickByID("PBarVehicleRefuel")
  end
  if (self._oldTick ~= 0 and ((getTickCount() - self._oldTick) >= 2500)) then
    self._oldTick = 0
    playSoundFrontEnd(16)
  end
end

function ObjVehicleFuel:getRefuelBusy()
  return self._refuelBusy
end

function ObjVehicleFuel:getVehicleParameters(vehicle)
  return getElementData(vehicle, "id"), getElementData(vehicle, "fuel")
end

function ObjVehicleFuel:showBar(source)
  local id, fuel = self:getVehicleParameters(source)
  if (id ~= false and fuel ~= false) then
    fuel = tonumber(fuel)
    self._maxFuel = self._vehicles:getMaxFuelByID(id)
    self._progressBars:setMaxByID("PBarVehicleFuel", self._maxFuel)
    self._progressBars:setPositionByID("PBarVehicleFuel", fuel)
    self:update(source)
    self._progressBars:showByID("PBarVehicleFuel")
  end
end

function ObjVehicleFuel:showRefuelBar(source)
  local id, fuel = self:getVehicleParameters(source)
  local maxFuel = 0
  if (id ~= false and fuel ~= false) then
    fuel = tonumber(fuel)
    maxFuel = self._vehicles:getMaxFuelByID(id)
    self._maxRefuel = fuel
    self._progressBars:setMaxByID("PBarVehicleRefuel", maxFuel - fuel)
    self._progressBars:stepMinByID("PBarVehicleRefuel")
    self._refuelBusy = true
    self._progressBars:showByID("PBarVehicleRefuel")
    self._textManager:triggerRoleText("refuel")
    self._oldTick = getTickCount()
  end
end

function ObjVehicleFuel:hideBar()
  self._progressBars:hideByID("PBarVehicleFuel")
end

function ObjVehicleFuel:hideRefuelBar()
  self._progressBars:hideByID("PBarVehicleRefuel")
  self._textManager:killRoleText()
  self._oldTick = 0
end

function ObjVehicleFuel:update(source)
  local id = getElementData(source, "id")
  local fuel = getElementData(source, "fuel")
  local speed = 4.0
  if (id ~= false and fuel ~= false) then
    fuel = tonumber(fuel)
    if (source ~= nil and source ~= false and getElementType(source) == "vehicle") then
      self._progressBars:setPositionByID("PBarVehicleFuel", fuel)
      if (self._refuelBusy) then
        self._progressBars:setPositionByID("PBarVehicleRefuel", (fuel - self._maxRefuel) + (speed * 2))
      end
      -- lower fuel threshold...
      if (((fuel / self._maxFuel) * 100) <= 75 and not self._vehicles:getCanRefuelByID(id)) then
        if (self._vehicles:isPlayerController(self._clientPlayer:getSource())) then
          self._textManager:createInstructDsp({"lowfuel", "openrefuel", "blank"})
        end
        self._refuelMarkers:toggleRefuelSpotByID(tonumber(id) + 3000, true)
        self._vehicles:setCanRefuelByID(id, true)
      -- upper fuel threshold...
      elseif ((((fuel / self._maxFuel) * 100) + (speed * 2)) >= 100 and self._vehicles:getCanRefuelByID(id)) then
        self._vehicles:setCanRefuelByID(id, false)
        self._progressBars:setMaxByID("PBarVehicleRefuel", 1)
        self._progressBars:stepMaxByID("PBarVehicleRefuel")
        self:hideRefuelBar()
        self._refuelBusy = false
      end
      return fuel
    end
  end
  return 0
end

-- Author: Ace_Gambit