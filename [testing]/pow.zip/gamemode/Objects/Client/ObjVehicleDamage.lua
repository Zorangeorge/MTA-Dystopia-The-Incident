-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjVehicleDamage = {}
ObjVehicleDamage.__index = ObjVehicleDamage

function ObjVehicleDamage.create()
  local _objVehicleDamage = {}
  setmetatable(_objVehicleDamage, ObjVehicleDamage)
  _objVehicleDamage._clientPlayer = nil
  _objVehicleDamage._vehicles = nil
  _objVehicleDamage._progressBars = nil
  _objVehicleDamage._textManager = nil
  _objVehicleDamage._maxRepair = 0
  _objVehicleDamage._repairBusy = false
  _objVehicleDamage._oldTick = 0
  return _objVehicleDamage
end

-- init vehicle damage
function ObjVehicleDamage:init(clientPlayer, vehicles, progressBars, textManager, screenX, screenY)
  self._clientPlayer = clientPlayer
  self._vehicles = vehicles
  self._progressBars = progressBars
  self._textManager = textManager
  -- NOTE: critical vehicle damage is 250!
  self._progressBars:createBar("PBarVehicleDamage", 100, 13, 0, (1000 - 250), 0, "darkgreen", 60, 415, true)
  self._progressBars:createBar("PBarVehicleRepair", 168, 13, 0, 0, 0, "healthgreen", (screenX / 2) - (168 / 2), (screenY / 2) - ((13 / 2) + 125), true)
end

function ObjVehicleDamage:Tick()
  if (self._progressBars:getBarByID("PBarVehicleDamage") ~= nil) then
    self._progressBars:TickByID("PBarVehicleDamage")
  end
  if (self._progressBars:getBarByID("PBarVehicleRepair") ~= nil) then
    self._progressBars:TickByID("PBarVehicleRepair")
  end
  if (self._oldTick ~= 0 and ((getTickCount() - self._oldTick) >= 2500)) then
    self._oldTick = 0
    playSoundFrontEnd(16)
  end
end

function ObjVehicleDamage:showBar(source)
  self:update(source)
  self._progressBars:showByID("PBarVehicleDamage")
end

function ObjVehicleDamage:showRepairBar(source)
  local health = getElementHealth(source) - 250
  if (health ~= false) then
    self._maxRepair = health
    self._progressBars:setMaxByID("PBarVehicleRepair", (1000 - 250) - health)
    self._progressBars:stepMinByID("PBarVehicleRepair")
    self._repairBusy = true
    self._progressBars:showByID("PBarVehicleRepair")
    self._textManager:triggerRoleText("repair")
    self._oldTick = getTickCount()
  end
end

function ObjVehicleDamage:hideBar()
   self._progressBars:hideByID("PBarVehicleDamage")
end

function ObjVehicleDamage:hideRepairBar()
  self._progressBars:hideByID("PBarVehicleRepair")
  self._textManager:killRoleText()
  self._oldTick = 0
end

function ObjVehicleDamage:update(source)
  local id = getElementData(source, "id")
  local health = 0
  local speed = 2.0
  if (source ~= nil and source ~= false and id ~= false and getElementType(source) == "vehicle") then
    health = getElementHealth(source) - 250
    if (health ~= false) then
      self._progressBars:setPositionByID("PBarVehicleDamage", health)
      if (self._repairBusy) then
        self._progressBars:setPositionByID("PBarVehicleRepair", (health - self._maxRepair) + (speed * 2))
      end
      -- lower damage threshold...
      if (((health / (1000 - 250)) * 100) <= 75 and not self._vehicles:getCanRepairByID(id)) then
        if (self._vehicles:isPlayerController(self._clientPlayer:getSource())) then
          self._textManager:createInstructDsp({"highdamage", "openrepair", "blank"})
        end
        self._vehicles:setCanRepairByID(id, true)
      -- upper damage threshold...
      elseif ((((health / (1000 - 250)) * 100) + (speed * 2)) >= 100 and self._vehicles:getCanRepairByID(id)) then
        self._vehicles:setCanRepairByID(id, false)
        self._progressBars:setMaxByID("PBarVehicleRepair", 1)
        self._progressBars:stepMaxByID("PBarVehicleRepair")
        self:hideRepairBar()
        self._repairBusy = false
      end
    end
  else
    return false
  end
  return true
end

-- Author: Ace_Gambit