-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientColshape = {}
ObjClientColshape.__index = ObjClientColshape

function ObjClientColshape.create()
  local _objClientColshape = {}
  setmetatable(_objClientColshape, ObjClientColshape)
  return _objClientColshape
end

-- init client colshape
function ObjClientColshape:init()
  -- nah, don't need it...
end

function ObjClientColshape:createTube(posX, posY, posZ, radius, height, id)
  -- TODO: check for unique id?
  local colshape = createColTube(posX, posY, posZ - 1.480003585815, radius, height)
  setElementData(colshape, "id", id)
  setElementData(colshape, "flag", "0")
  return colshape
end

function ObjClientColshape:createSphere(posX, posY, posZ, radius, id)
  -- TODO: check for unique id?
  local colshape = createColSphere(posX, posY, posZ - 1.480003585815, radius)
  setElementData(colshape, "id", id)
  return colshape
end

-- Author: Ace_Gambit