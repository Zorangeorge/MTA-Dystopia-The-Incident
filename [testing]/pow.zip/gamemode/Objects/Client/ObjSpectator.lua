-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSpectator = {}
ObjSpectator.__index = ObjSpectator

function ObjSpectator.create()
  local _objSpectator = {}
  setmetatable(_objSpectator, ObjSpectator)
  _objSpectator._source = nil
  _objSpectator._cineManager = nil
  _objSpectator._camerasData = nil
  _objSpectator._spawnpointsData = nil
  _objSpectator._scoreBoard = nil
  _objSpectator._teams = {"Allies", "Axis"}
  _objSpectator._squads = {"alpha", "bravo", "charlie", "delta"}
  _objSpectator._count = -1
  return _objSpectator
end

-- init spectator
function ObjSpectator:init(source, cineManager, camerasData, spawnpointsData, scoreBoard)
  self._source = source
  self._cineManager = cineManager
  self._camerasData = camerasData
  self._spawnpointsData = spawnpointsData
  self._scoreBoard = scoreBoard
end

function ObjSpectator:update()
  if (self._count > -1) then
    self:updateRespawnTime()
  end
end

function ObjSpectator:Process(source)
  if (getElementType(source) == "gui-button") then
    for k, v in pairs(self._scoreBoard:getTabs()) do
      if (source == self._scoreBoard:getTabs()[k]["buttons"]["respawn"]) then
        self._count = -1
        self:respawnPlayer()
      end
    end
  end
end

function ObjSpectator:killedMode()
  local randTeam = math.random(1, 2)
  local randSquadName = math.random(1, 4)
  local randSquad = math.random(1, 16)
  local pos = split(self._camerasData[string.lower(self._teams[randTeam]) .. "-" .. self._squads[randSquadName]]["pos"], string.byte(' '))
  local target = split(self._camerasData[string.lower(self._teams[randTeam]) .. "-" .. self._squads[randSquadName]]["target"], string.byte(' '))
  local posX = tonumber(self._spawnpointsData[self._teams[randTeam]]["spawn"][randSquad]["posX"])
  local posY = tonumber(self._spawnpointsData[self._teams[randTeam]]["spawn"][randSquad]["posY"])
  local posZ = tonumber(self._spawnpointsData[self._teams[randTeam]]["spawn"][randSquad]["posZ"])
  local rot = tonumber(self._spawnpointsData[self._teams[randTeam]]["spawn"][randSquad]["rot"])
  fadeCamera(false, 0.5)
  self._cineManager:setCameraPos(true, tonumber(pos[1]) - 50.0, tonumber(pos[2]) - 50.0, tonumber(pos[3]) + 20.0, tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
  self._cineManager:triggerTrack(true, rot, 360, 0.8, 50, 20, posX, posY, posZ)
  self._count = 10
  self._scoreBoard:trigger(true)
end

function ObjSpectator:updateRespawnTime()
  for k, v in pairs(self._scoreBoard:getTabs()) do
    guiSetProperty(self._scoreBoard:getTabs()[k]["buttons"]["respawn"], "Disabled", "False")
    guiSetProperty(self._scoreBoard:getTabs()[k]["buttons"]["respawn"], "Text", "Respawn (" .. self._count .. ")")
  end
  if (self._count == 0) then
    self:respawnPlayer()
  end
  if (self._count > -1) then
    self._count = self._count - 1
  end
end

function ObjSpectator:respawnPlayer()
  triggerServerEvent("funcRespawnPlayer", self._source, "funcRespawnPlayer", nil)
  self._scoreBoard:trigger(false)
  self:reset()
end

function ObjSpectator:reset()
  for k, v in pairs(self._scoreBoard:getTabs()) do
    guiSetProperty(self._scoreBoard:getTabs()[k]["buttons"]["respawn"], "Disabled", "True")
    guiSetProperty(self._scoreBoard:getTabs()[k]["buttons"]["respawn"], "Text", "Respawn")
  end
end

-- Author: Ace_Gambit