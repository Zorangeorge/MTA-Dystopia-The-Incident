-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientProjectile = {}
ObjClientProjectile.__index = ObjClientProjectile

function ObjClientProjectile.create(id, objectID, force, projectileType, zOffSet, maxProjectiles, creatorType)
  local _objClientProjectile = {}
  setmetatable(_objClientProjectile, ObjClientProjectile)
  _objClientProjectile._id = id
  _objClientProjectile._objectID = objectID
  _objClientProjectile._force = force
  _objClientProjectile._projectileType = projectileType
  _objClientProjectile._zOffSet = zOffSet
  _objClientProjectile._maxProjectiles = maxProjectiles
  _objClientProjectile._creatorType = creatorType
  _objClientProjectile._totalFired = 0
  return _objClientProjectile
end

-- init projectile
function ObjClientProjectile:init()
  -- nah, don't need it...
end

function ObjClientProjectile:getObjectID()
  return self._objectID
end

function ObjClientProjectile:getForce()
  return self._force
end

function ObjClientProjectile:getProjectileType()
  return self._projectileType
end

function ObjClientProjectile:getZOffSet()
  return self._zOffSet
end

function ObjClientProjectile:getMaxProjectiles()
  return self._maxProjectiles
end

function ObjClientProjectile:getCreatorType()
  return self._creatorType
end

function ObjClientProjectile:setTotalFired(num)
  self._totalFired = num
end

function ObjClientProjectile:getTotalFired()
  return self._totalFired
end

-- Author: Ace_Gambit