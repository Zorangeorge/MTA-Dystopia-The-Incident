-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjKillMessages = {}
ObjKillMessages.__index = ObjKillMessages

function ObjKillMessages.create(posX, posY)
  local _objKillMessages = {}
  setmetatable(_objKillMessages, ObjKillMessages)
  _objKillMessages._squadrolesData = nil
  _objKillMessages._posX = posX
  _objKillMessages._posY = posY
  _objKillMessages._kills = { -- text/weapon id
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""},
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""},
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""},
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""},
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""},
      {["attacker"] = "", ["weapon"] = -1, ["player"] = ""}
                           }
  _objKillMessages._killsPlayers = { -- player elements
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil}
                           }
  _objKillMessages._killsDspShadow = { -- text shadow
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["player"] = nil}
                                    }
  _objKillMessages._killsDsp = { -- text/icons
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil},
      {["attacker"] = nil, ["weapon"] = nil, ["player"] = nil}
                              }
  _objKillMessages._fade = false
  _objKillMessages._alphaIn = 0
  _objKillMessages._alphaOut = 1
  _objKillMessages._offsetY = 0
  return _objKillMessages
end

function ObjKillMessages:updateDsp(element, visible, focused, propertyValue, posX, posY)
  guiSetVisible(element, visible)
  if (focused) then
    guiBringToFront(element)
  else
    guiMoveToBack(element)
  end
  guiSetProperty(element, "Disabled", propertyValue)
  guiSetPosition(element, posX, posY, false)
end

-- init kill messages
function ObjKillMessages:init(data)
  self._squadrolesData = data
  -- text shadows...
  for k, v in ipairs(self._killsDspShadow) do
    v["attacker"] = guiCreateLabel(0, 0, 80, 20, "", false)
    guiSetFont(v["attacker"], "default-bold-small")
    guiLabelSetColor(v["attacker"], 0, 0, 0)
    self:updateDsp(v["attacker"], false, false, "True", 0, 0)
    v["player"] = guiCreateLabel(0, 0, 80, 20, "", false)
    guiSetFont(v["player"], "default-bold-small")
    guiLabelSetColor(v["player"], 0, 0, 0)
    self:updateDsp(v["player"], false, false, "True", 0, 0)
  end
  -- text/icons...
  for k, v in ipairs(self._killsDsp) do
    v["attacker"] = guiCreateLabel(0, 0, 80, 20, "", false)
    guiSetFont(v["attacker"], "default-bold-small")
    self:updateDsp(v["attacker"], false, false, "True", 0, 0)
    -- blank icon...
    v["weapon"] = guiCreateStaticImage(0, 0, 32, 32, self:getWeaponIconByID(1000), false, nil)
    self:updateDsp(v["weapon"], false, false, "True", 0, 0)
    v["player"] = guiCreateLabel(0, 0, 80, 20, "", false)
    guiSetFont(v["player"], "default-bold-small")
    self:updateDsp(v["player"], false, false, "True", 0, 0)
  end
end

function ObjKillMessages:Tick()
  local x, y = 0, 0
  if (self._fade) then
    if (self._alphaIn <= 1 and self._alphaOut >= 0) then
      guiSetAlpha(self._killsDspShadow[1]["attacker"], self._alphaIn)
      guiSetAlpha(self._killsDsp[1]["attacker"], self._alphaIn)
      guiSetAlpha(self._killsDsp[1]["weapon"], self._alphaIn)
      guiSetAlpha(self._killsDspShadow[1]["player"], self._alphaIn)
      guiSetAlpha(self._killsDsp[1]["player"], self._alphaIn)
      guiSetAlpha(self._killsDspShadow[6]["attacker"], self._alphaIn)
      guiSetAlpha(self._killsDsp[6]["attacker"], self._alphaIn)
      guiSetAlpha(self._killsDsp[6]["weapon"], self._alphaOut)
      guiSetAlpha(self._killsDspShadow[6]["player"], self._alphaIn)
      guiSetAlpha(self._killsDsp[6]["player"], self._alphaIn)
      self._alphaIn = self._alphaIn + 0.05
      self._alphaOut = self._alphaOut - 0.05
    else
      -- hide just in case...
      guiSetText(self._killsDspShadow[6]["attacker"], "")
      guiSetText(self._killsDsp[6]["attacker"], "")
      -- blank icon...
      guiStaticImageLoadImage(self._killsDsp[6]["weapon"], self:getWeaponIconByID(1000))
      guiSetText(self._killsDspShadow[6]["player"], "")
      guiSetText(self._killsDsp[6]["player"], "")
      self._fade = false
      self._alphaIn = 0
      self._alphaOut = 1
    end
    if (self._offsetY < 32) then
      for k, v in ipairs(self._kills) do
        x, y = guiGetPosition(self._killsDspShadow[k]["attacker"], false)
        self:updateDsp(self._killsDspShadow[k]["attacker"], true, false, "True", x, y + self._offsetY)
        x, y = guiGetPosition(self._killsDsp[k]["attacker"], false)
        self:updateDsp(self._killsDsp[k]["attacker"], true, true, "True", x, y + self._offsetY)
        x, y = guiGetPosition(self._killsDsp[k]["weapon"], false)
        self:updateDsp(self._killsDsp[k]["weapon"], true, true, "True", x, y + self._offsetY)
        x, y = guiGetPosition(self._killsDspShadow[k]["player"], false)
        self:updateDsp(self._killsDspShadow[k]["player"], true, false, "True", x, y + self._offsetY)
        x, y = guiGetPosition(self._killsDsp[k]["player"], false)
        self:updateDsp(self._killsDsp[k]["player"], true, true, "True", x, y + self._offsetY)
      end
      self._offsetY = self._offsetY + 0.1
    end
  end
end

function ObjKillMessages:setRow(currentKey, previousKey, key)
  self._kills[currentKey][key] = self._kills[previousKey][key]
  if (key ~= "weapon") then
    self._killsPlayers[currentKey][key] = self._killsPlayers[previousKey][key]
  end
end

function ObjKillMessages:Process(source, killer, weapon)
  for i = 6, 2, -1 do
    self:setRow(i, i - 1, "attacker")
    self:setRow(i, i - 1, "weapon")
    self:setRow(i, i - 1, "player")
  end
  if (killer ~= nil and getElementType(killer) == "player") then
    if (getPlayerName(killer) ~= getPlayerName(source) and killer ~= source) then
      self._kills[1]["attacker"] = getPlayerName(killer)
      self._killsPlayers[1]["attacker"] = killer
    end
  end
  self._kills[1]["weapon"] = weapon
  self._kills[1]["player"] = getPlayerName(source)
  self._killsPlayers[1]["player"] = source
  self:createKillsDsp()
end

function ObjKillMessages:getPlayerTagColor(player)
  local tmpTeam = getPlayerTeam(player)
  local tmpRole = getElementData(player, "role")
  local color = nil
  if (player == false or player == nil or tmpTeam == false or tmpRole == false) then
    return 255, 255, 255
  else
    color = split(self._squadrolesData[getTeamName(tmpTeam)]["squadrole"][tmpRole]["color"], string.byte(' '))
    return tonumber(color[1]), tonumber(color[2]), tonumber(color[3])
  end
end

function ObjKillMessages:getWeaponIconByID(id)
  local icon = nil
  if (id == nil or id == false or id == -1) then
    return CKillIcons[1001]
  else
    icon = CKillIcons[id]
    if (icon == nil) then
      return CKillIcons[1001]
    else
      return icon
    end
  end
end

function ObjKillMessages:createKillsDsp()
  local posY = self._posY
  local offsetX = self._posX
  local textWidth = 0
  local textWidthOffet = 0
  local textHeight = 0
  local r, g, b = 0, 0, 0
  for k, v in ipairs(self._kills) do
    if (v["player"] ~= "") then
      -- double check...
      if (v["attacker"] ~= v["player"]) then
        guiSetText(self._killsDspShadow[k]["attacker"], v["attacker"])
        guiSetText(self._killsDsp[k]["attacker"], v["attacker"])
      else
        guiSetText(self._killsDspShadow[k]["attacker"], "")
        guiSetText(self._killsDsp[k]["attacker"], "")
      end
      r, g, b = self:getPlayerTagColor(self._killsPlayers[k]["attacker"])
      guiLabelSetColor(self._killsDsp[k]["attacker"], r, g, b)
      textWidth = guiLabelGetTextExtent(self._killsDsp[k]["attacker"])
      textHeight = guiLabelGetFontHeight(self._killsDsp[k]["attacker"])
      textWidthOffet = textWidth + 5
      -- text shadows...
      self:updateDsp(self._killsDspShadow[k]["attacker"], true, false, "True", (offsetX - textWidthOffet) + 1, (posY + 16) - (textHeight / 2) + 1)
      guiSetText(self._killsDspShadow[k]["player"], v["player"])
      self:updateDsp(self._killsDspShadow[k]["player"], true, false, "True", offsetX + 37 + 1, (posY + 16) - (textHeight / 2) + 1)
      -- text/icons...
      self:updateDsp(self._killsDsp[k]["attacker"], true, true, "True", (offsetX - textWidthOffet), (posY + 16) - (textHeight / 2))
      guiStaticImageLoadImage(self._killsDsp[k]["weapon"], self:getWeaponIconByID(v["weapon"]))
      self:updateDsp(self._killsDsp[k]["weapon"], true, true, "True", offsetX, posY)
      guiSetText(self._killsDsp[k]["player"], v["player"])
      r, g, b = self:getPlayerTagColor(self._killsPlayers[k]["player"])
      guiLabelSetColor(self._killsDsp[k]["player"], r, g, b)
      self:updateDsp(self._killsDsp[k]["player"], true, true, "True", offsetX + 37, (posY + 16) - (textHeight / 2))
      posY = posY + 42
    end
  end
  self._offsetY = 0
  self._fade = true
end

-- Author: Ace_Gambit