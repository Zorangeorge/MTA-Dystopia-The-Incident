-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjScoreBoard = {}
ObjScoreBoard.__index = ObjScoreBoard

function ObjScoreBoard.create()
  local _objScoreBoard = {}
  setmetatable(_objScoreBoard, ObjScoreBoard)
  _objScoreBoard._handle = nil
  _objScoreBoard._pane = nil
  _objScoreBoard._tabs = {
      ["All"] = {
      ["tab"] = nil,
      ["gridlist"] = nil,
      ["checkbox"] = nil,
      ["buttons"] = {
      ["refresh"] = nil,
      ["respawn"] = nil
                   },
      ["columns"] = {
      ["Player"] = nil,
      ["Kills"] = nil,
      ["Death"] = nil,
      ["Ratio"] = nil,
      ["Ping"] = nil
                    }
               },
      ["Allies"] = {
      ["tab"] = nil,
      ["gridlist"] = nil,
      ["checkbox"] = nil,
      ["buttons"] = {
      ["refresh"] = nil,
      ["respawn"] = nil
                   },
      ["columns"] = {
      ["Player"] = nil,
      ["Kills"] = nil,
      ["Death"] = nil,
      ["Ratio"] = nil,
      ["Ping"] = nil
                  }
                  },
      ["Axis"] = {
      ["tab"] = nil,
      ["gridlist"] = nil,
      ["checkbox"] = nil,
      ["buttons"] = {
      ["refresh"] = nil,
      ["respawn"] = nil
                   },
      ["columns"] = {
      ["Player"] = nil,
      ["Kills"] = nil,
      ["Death"] = nil,
      ["Ratio"] = nil,
      ["Ping"] = nil
                  }
                 }
                         }
  _objScoreBoard._teams = {
      ["Allies"] = {},
      ["Axis"] = {}
                         }
  _objScoreBoard._squads = {
      ["Allies"] = {
      ["alpha"] = {},
      ["bravo"] = {},
      ["charlie"] = {},
      ["delta"] = {}
                  },
      ["Axis"] = {
      ["alpha"] = {},
      ["bravo"] = {},
      ["charlie"] = {},
      ["delta"] = {}
                  }
                         }
  return _objScoreBoard
end

-- blatant copy/paste lol...
function ObjScoreBoard:round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

-- init scoreboard
function ObjScoreBoard:init(screenX, screenY)
  self._handle = guiCreateWindow((screenX / 2) - (300), (screenY / 2) - (250), 600, 500, "", false)
  guiSetVisible(self._handle, false)
  guiWindowSetMovable(self._handle, false)
  guiWindowSetSizable(self._handle, false)
  self._pane = guiCreateTabPanel(0.0, 0.05, 1.0, 1.0, true, self._handle)
  for k, v in pairs(self._tabs) do
    self._tabs[k]["tab"] = guiCreateTab(k, self._pane)
    guiSetFont(self._tabs[k]["tab"], "default-bold-small")
    self._tabs[k]["gridlist"] = guiCreateGridList(0.02, 0.1, 0.72, 0.86, true, self._tabs[k]["tab"])
    self._tabs[k]["checkbox"] = guiCreateCheckBox(0.02, 0.05, 0.5, 0.04, "KIA (Killed In Action)", true, true, self._tabs[k]["tab"])
    guiSetFont(self._tabs[k]["checkbox"], "default-bold-small")
    self._tabs[k]["buttons"]["refresh"] = guiCreateButton(0.76, 0.1, 0.22, 0.04, "Refresh", true, self._tabs[k]["tab"])
    guiSetFont(self._tabs[k]["buttons"]["refresh"], "default-bold-small")
    self._tabs[k]["buttons"]["respawn"] = guiCreateButton(0.76, 0.16, 0.22, 0.04, "Respawn", true, self._tabs[k]["tab"])
    guiSetFont(self._tabs[k]["buttons"]["respawn"], "default-bold-small")
    guiSetProperty(self._tabs[k]["buttons"]["respawn"], "Disabled", "True")
    self._tabs[k]["columns"]["Player"] = guiGridListAddColumn(self._tabs[k]["gridlist"], "Player", 0.3)
    self._tabs[k]["columns"]["Kills"] = guiGridListAddColumn(self._tabs[k]["gridlist"], "Kills", 0.2)
    self._tabs[k]["columns"]["Death"] = guiGridListAddColumn(self._tabs[k]["gridlist"], "Death", 0.2)
    self._tabs[k]["columns"]["Ratio"] = guiGridListAddColumn(self._tabs[k]["gridlist"], "Ratio", 0.2)
    self._tabs[k]["columns"]["Ping"] = guiGridListAddColumn(self._tabs[k]["gridlist"], "Ping", 0.2)
    for k, v in pairs(self._tabs[k]["columns"]) do
      guiSetFont(v, "default-bold-small")
    end
  end
end

function ObjScoreBoard:getTabs()
  return self._tabs
end

function ObjScoreBoard:Process(source)
  if (getElementType(source) == "gui-button") then
    for k, v in pairs(self._tabs) do
      if (source == self._tabs[k]["buttons"]["refresh"]) then
        self:update()
      end
    end
  end
end

function ObjScoreBoard:getStatus(player)
  if (isPlayerDead(player)) then
    return " (KIA)"
  else
    return ""
  end
end

function ObjScoreBoard:update()
  local row = nil
  local status = nil
  local tmpPlayers = 0
  local tmpTeam = nil
  local squad = nil
  -- stats
  local kills = 0
  local death = 0
  local ratio = 0
  for k, v in pairs(self._tabs) do
    guiGridListClear(self._tabs[k]["gridlist"])
  end
  for k, v in pairs(self._teams) do
    self._teams[k] = {}
  end
  for k, v in pairs(self._squads) do
    for kc, vc in pairs(self._squads[k]) do
      self._squads[k][kc] = {}
    end
  end
  for k, v in ipairs(getElementsByType("player")) do
    tmpPlayers = tmpPlayers + 1
    status = self:getStatus(v)
    tmpTeam = getPlayerTeam(v)
    -- Spectators
    if (tmpTeam == false) then
      kills = tonumber(getElementData(v, "stats")["kills"])
      death = tonumber(getElementData(v, "stats")["death"])
      if (kills == 0 and death == 0) then
        ratio = 0
      else
        ratio = (kills / death)
      end
      row = guiGridListAddRow(self._tabs["All"]["gridlist"])
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Player"], getPlayerName(v) .. status .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Kills"], kills .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Death"], death .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Ratio"], self:round(ratio, 1) .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Ping"], getPlayerPing(v) .. "       ", false, false)
    end
    -- Pending...
    if (tmpTeam ~= false) then
      table.insert(self._teams[getTeamName(tmpTeam)], v)
      squad = getElementData(v, "squad")
      if (squad ~= "") then
        table.insert(self._squads[getTeamName(tmpTeam)][squad], v)
      elseif (squad == "") then
        kills = tonumber(getElementData(v, "stats")["kills"])
        death = tonumber(getElementData(v, "stats")["death"])
        if (kills == 0 and death == 0) then
          ratio = 0
        else
          ratio = (kills / death)
        end
        row = guiGridListAddRow(self._tabs[getTeamName(tmpTeam)]["gridlist"])
        guiGridListSetItemText(self._tabs[getTeamName(tmpTeam)]["gridlist"], row, self._tabs[getTeamName(tmpTeam)]["columns"]["Player"], getPlayerName(v) .. status .. "       ", false, false)
        guiGridListSetItemText(self._tabs[getTeamName(tmpTeam)]["gridlist"], row, self._tabs[getTeamName(tmpTeam)]["columns"]["Kills"], kills .. "       ", false, false)
        guiGridListSetItemText(self._tabs[getTeamName(tmpTeam)]["gridlist"], row, self._tabs[getTeamName(tmpTeam)]["columns"]["Death"], death .. "       ", false, false)
        guiGridListSetItemText(self._tabs[getTeamName(tmpTeam)]["gridlist"], row, self._tabs[getTeamName(tmpTeam)]["columns"]["Ratio"], self:round(ratio, 1) .. "       ", false, false)
        guiGridListSetItemText(self._tabs[getTeamName(tmpTeam)]["gridlist"], row, self._tabs[getTeamName(tmpTeam)]["columns"]["Ping"], getPlayerPing(v) .. "       ", false, false)      
      end
    end
  end
  -- All
  for k, v in pairs(self._teams) do
    row = guiGridListAddRow(self._tabs["All"]["gridlist"])
    guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Player"], string.upper(k), true, false)
    for kc, vc in pairs(self._teams[k]) do
      status = self:getStatus(vc)
      kills = tonumber(getElementData(vc, "stats")["kills"])
      death = tonumber(getElementData(vc, "stats")["death"])
      if (kills == 0 and death == 0) then
        ratio = 0
      else
        ratio = (kills / death)
      end
      row = guiGridListAddRow(self._tabs["All"]["gridlist"])
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Player"], getPlayerName(vc) .. status .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Kills"], kills .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Death"], death .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Ratio"], self:round(ratio, 1) .. "       ", false, false)
      guiGridListSetItemText(self._tabs["All"]["gridlist"], row, self._tabs["All"]["columns"]["Ping"], getPlayerPing(vc) .. "       ", false, false)
    end
  end
  -- Allies and Axis
  for k, v in pairs(self._squads) do
    for kc, vc in pairs(self._squads[k]) do
      row = guiGridListAddRow(self._tabs[k]["gridlist"])
      guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Player"], string.upper(kc), true, false)
      for ks, vp in pairs(self._squads[k][kc]) do
        status = self:getStatus(vp)
        kills = tonumber(getElementData(vp, "stats")["kills"])
        death = tonumber(getElementData(vp, "stats")["death"])
        if (kills == 0 and death == 0) then
          ratio = 0
        else
          ratio = (kills / death)
        end
        row = guiGridListAddRow(self._tabs[k]["gridlist"])
        guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Player"], getPlayerName(vp) .. status .. "       ", false, false)
        guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Kills"], kills .. "       ", false, false)
        guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Death"], death .. "       ", false, false)
        guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Ratio"], self:round(ratio, 1) .. "       ", false, false)
        guiGridListSetItemText(self._tabs[k]["gridlist"], row, self._tabs[k]["columns"]["Ping"], getPlayerPing(vp) .. "       ", false, false)
      end
    end
  end
  guiSetProperty(self._handle, "Text", "Server Players (" .. tmpPlayers .. "/32)")
end

function ObjScoreBoard:autoSizeColumns()
  for k, v in pairs(self._tabs) do
    guiGridListAutoSizeColumn(self._tabs[k]["gridlist"], self._tabs[k]["columns"]["Player"])
    guiGridListAutoSizeColumn(self._tabs[k]["gridlist"], self._tabs[k]["columns"]["Kills"])
    guiGridListAutoSizeColumn(self._tabs[k]["gridlist"], self._tabs[k]["columns"]["Death"])
    guiGridListAutoSizeColumn(self._tabs[k]["gridlist"], self._tabs[k]["columns"]["Ratio"])
    guiGridListAutoSizeColumn(self._tabs[k]["gridlist"], self._tabs[k]["columns"]["Ping"])
  end
end

function ObjScoreBoard:trigger(show)
  self:update()
  self:autoSizeColumns()
  guiSetVisible(self._handle, show)
  showCursor(show)
  guiBringToFront(self._handle)
end

-- Author: Ace_Gambit