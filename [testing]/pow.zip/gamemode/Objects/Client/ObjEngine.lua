-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjEngine = {}
ObjEngine.__index = ObjEngine

function ObjEngine.create()
  local _objEngine = {}
  setmetatable(_objEngine, ObjEngine)
  _objEngine._data = nil
  return _objEngine
end

-- init engine
function ObjEngine:init(data)
  local collision = false
  self._data = data
  for k, v in ipairs(getElementsByType("object")) do
    collision = getElementData(v, "collision")
    setElementCollisionsEnabled(v, (collision == "yes" or not collision))
  end
end

function ObjEngine:replaceEngine()
  local id = 0
  local txd = nil
  local dff = nil
  for k, v in ipairs(self._data["model"]) do
    id = tonumber(v["model-id"])
    txd = engineLoadTXD("models/txd/" .. v["txd"])
    engineImportTXD(txd, id)
    dff = engineLoadDFF("models/" .. v["dff"], id)
    engineReplaceModel(dff, id)
  end
end

-- Author: Ace_Gambit