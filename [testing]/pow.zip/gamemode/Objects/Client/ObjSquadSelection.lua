-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSquadSelection = {}
ObjSquadSelection.__index = ObjSquadSelection

function ObjSquadSelection.create()
  local _objSquadSelection = {}
  setmetatable(_objSquadSelection, ObjSquadSelection)
  _objSquadSelection._clientPlayer = nil
  _objSquadSelection._camerasData = nil
  _objSquadSelection._cineManager = nil
  _objSquadSelection._curTeam = ""
  _objSquadSelection._curSquad = 1
  _objSquadSelection._oldSquad = 1
  _objSquadSelection._textManager = nil
  _objSquadSelection._squads = {"-alpha", "-bravo", "-charlie", "-delta"}
  _objSquadSelection._firstSwitch = true
  -- current amount of players in each squad
  -- use server script to get most recent updates!
  _objSquadSelection._curSquads = {
      ["Allies"] = {
      ["alpha"] = 0,
      ["bravo"] = 0,
      ["charlie"] = 0,
      ["delta"] = 0
                  },
      ["Axis"] = {
      ["alpha"] = 0,
      ["bravo"] = 0,
      ["charlie"] = 0,
      ["delta"] = 0
                }
                                 }
  return _objSquadSelection
end

-- init squad selection
function ObjSquadSelection:init(clientPlayer, camerasData, cineManager, textManager)
  self._clientPlayer = clientPlayer
  self._camerasData = camerasData
  self._cineManager = cineManager
  self._textManager = textManager
end

function ObjSquadSelection:updateSquads(params)
  for k, v in pairs(params) do
    for kc, vc in pairs(params[k]) do
      self._curSquads[k][kc] = params[k][kc]
    end
  end
end

function ObjSquadSelection:triggerSelection(team)
  self._curTeam = team
  self._textManager:createInstructDsp({"navsquad", "joinsquad", "backteam", "blank"})
  self._firstSwitch = true
  self:switch(1)
  self._firstSwitch = false
  self._textManager:setRoleTextIgnoreAudio(true)
  self._textManager:triggerRoleText(self._curTeam)
end

function ObjSquadSelection:switch(navDir)
  local pos = split(self._camerasData[self._curTeam .. self._squads[self._curSquad]]["pos"], string.byte(' '))
  local target = split(self._camerasData[self._curTeam .. self._squads[self._curSquad]]["target"], string.byte(' '))
  self._textManager:setMissionTextIgnoreAudio(true)
  if (not self._firstSwitch) then
    -- TODO: erm, sound?!
    fadeCamera(false, 0.5)
  end
  self._cineManager:setCameraPos(true, tonumber(pos[1]) - 2.0, tonumber(pos[2]) - 2.0, tonumber(pos[3]) + 2.0, tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
  self._cineManager:triggerTrack(true, 1, 360, 0.6, 5.0, 2.0, tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
  self._textManager:triggerMissionText(self._curTeam .. self._squads[self._curSquad])
  self._oldSquad = self._curSquad
  -- navigate between squads...
  if (navDir == 1 and self._curSquad == 4) then -- right key
    self._curSquad = 1
  elseif (navDir == 1 and self._curSquad < 4) then
    self._curSquad = self._curSquad + 1
  end
  if (navDir == 0 and self._curSquad == 1) then -- left key
    self._curSquad = 4
  elseif (navDir == 0 and self._curSquad > 1) then
    self._curSquad = self._curSquad - 1
  end
  self._textManager:setMissionTextIgnoreAudio(false)
end

function ObjSquadSelection:setPlayerSquad()
  local tmpTeam = getPlayerTeam(self._clientPlayer:getSource())
  if (tmpTeam ~= false) then
    if (self._curSquads[getTeamName(tmpTeam)][string.sub(self._squads[self._oldSquad], 2)] == 4) then -- NOTE: max players per squad is hardcoded!
      self._textManager:createInstructDsp({"nosquadslots", "navsquad", "blank"})
      playSoundFrontEnd(4)
      return false
    else
      triggerServerEvent("funcSetPlayerSquad", self._clientPlayer:getSource(), "funcSetPlayerSquad", {["squad"] = string.sub(self._squads[self._oldSquad], 2)})
      return true
    end
  end
end

-- Author: Ace_Gambit