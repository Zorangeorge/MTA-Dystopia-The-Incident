-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjInstructText = {}
ObjInstructText.__index = ObjInstructText

function ObjInstructText.create(fontName, fontWidthTbl)
  local _objInstructText = {}
  setmetatable(_objInstructText, ObjInstructText)
  _objInstructText._fontWidthTbl = fontWidthTbl
  _objInstructText._fontName = fontName
  _objInstructText._fontScale = 1.0
  _objInstructText._fontTbl = {}
  _objInstructText._charTbl = {}
  _objInstructText._imageTbl = {}
  _objInstructText._screenX = 0
  _objInstructText._screenY = 0
  _objInstructText._fontWidth = 0
  _objInstructText._canvasWidth = 50
  _objInstructText._canvasHeight = 50
  _objInstructText._fontPadding = 0
  _objInstructText._posX = 0
  _objInstructText._posY = 0
  _objInstructText._textWidth = 0
  _objInstructText._counter = 0
  _objInstructText._tblSize = 0
  _objInstructText._createText = false
  _objInstructText._textVisible = false
  return _objInstructText
end

-- init instruction text
function ObjInstructText:init(scrX, scrY)
  self._screenX = scrX
  self._screenY = scrY
end

function ObjInstructText:Tick()
  -- render visible
  if ((self._counter == self._tblSize and self._createText and self._triggerText) or self._triggerText) then
    -- kill any visible text elements
    self:killInstructText()
    self._createText = false
    self._triggerText = false
    self._counter = 0
    for k, v in ipairs(self._imageTbl) do
      guiSetVisible(v, true)
    end
    self._textVisible = true
  end
  -- we'll use tick to create the buffer frame by frame
  -- due to some odd reason the client 'locks' when using an ordinary loop
  if (self._createText and self._counter < self._tblSize) then
    self._posX = self._posX - ((self._canvasWidth - (self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale)) / 2)
    table.insert(self._imageTbl, guiCreateStaticImage(self._posX, self._posY, self._canvasWidth, self._canvasHeight, self._fontTbl[self._counter + 1], false))
    -- render invisible for now!
    self._fontWidth = self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale
    guiSetVisible(self._imageTbl[self._counter + 1], false)
    self._posX = self._posX + (self._canvasWidth - ((self._canvasWidth - self._fontWidth) / 2)) + self._fontPadding
    self._counter = self._counter + 1
  end
end

function ObjInstructText:createInstructText(fontUtils, text, fontScale)
  self._fontScale = fontScale
  self._canvasWidth = self._canvasWidth * fontScale
  self._canvasHeight = self._canvasHeight * fontScale
  self._imageTbl = {}
  self._fontTbl, self._charTbl = fontUtils:getSplitStr(text, self._fontName)
  self._textWidth = 0
  self._tblSize = 0
  self._counter = 0
  -- kill any visible text elements
  self:killInstructText()
  -- get width of text in pixels
  for k, v in ipairs(self._fontTbl) do
    self._fontWidth = self._fontWidthTbl[self._charTbl[k]] * self._fontScale
    self._textWidth = self._textWidth + self._fontWidth + self._fontPadding
    self._tblSize = self._tblSize + 1
  end
  -- calculate posX
  self._posX = (self._screenX / 2) - (self._textWidth / 2)
  -- calculate posY
  self._posY = self._screenY - ((self._canvasHeight * self._fontScale) * 4)
  -- position text on screen
  self._createText = true
end

function ObjInstructText:triggerInstructText()
  self._triggerText = true
end

-- NOTE: this does not destroy the actual images!
function ObjInstructText:killInstructText()
  -- render invisible
  for k, v in ipairs(self._imageTbl) do
    guiSetVisible(v, false)
  end
  self._textVisible = false
end

function ObjInstructText:getTextVisible()
  return self._textVisible
end

-- Author: Ace_Gambit