-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjProgressBars = {}
ObjProgressBars.__index = ObjProgressBars

function ObjProgressBars.create()
  local _objProgressBars = {}
  setmetatable(_objProgressBars, ObjProgressBars)
  _objProgressBars._bars = {}
  return _objProgressBars
end

-- init progressbars
function ObjProgressBars:init()
  -- nah, don't need it...
end

function ObjProgressBars:TickByID(id)
  self._bars[id]:Tick()
end

function ObjProgressBars:createBar(id, width, height, minVal, maxVal, position, color, posX, posY, outline)
  self._bars[id] = ObjProgressBar.create(width, height, minVal, maxVal, position, outline)
  self._bars[id]:createProgressBar(color, posX, posY)
end

function ObjProgressBars:showByID(id)
  self._bars[id]:show()
end

function ObjProgressBars:stepByID(id)
  self._bars[id]:step()
end

function ObjProgressBars:stepBackByID(id)
  self._bars[id]:stepBack()
end

function ObjProgressBars:stepMaxByID(id)
  self._bars[id]:stepMax()
end

function ObjProgressBars:stepMinByID(id)
  self._bars[id]:stepMin()
end

function ObjProgressBars:hideByID(id)
  self._bars[id]:hide()
end

function ObjProgressBars:getBarByID(id)
  return self._bars[id]
end

function ObjProgressBars:setPositionByID(id, pos)
  self._bars[id]:setPosition(pos)
end

function ObjProgressBars:setMaxByID(id, maxVal)
  self._bars[id]:setMax(maxVal)
end

function ObjProgressBars:setxybyid(id, x, y)
  self._bars[id]:setxy(tonumber(x), tonumber(y))
end

-- Author: Ace_Gambit