-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjRefuelMarkers = {}
ObjRefuelMarkers.__index = ObjRefuelMarkers

function ObjRefuelMarkers.create()
  local _objRefuelMarkers = {}
  setmetatable(_objRefuelMarkers, ObjRefuelMarkers)
  _objRefuelMarkers._data = nil
  _objRefuelMarkers._markers = {}
  _objRefuelMarkers._blips = {}
  return _objRefuelMarkers
end

-- init refuel markers
function ObjRefuelMarkers:init(data)
  local color = nil
  self._data = data
  for k, v in pairs(self._data) do
    color = split(v["color"], string.byte(' '))
    self._markers[v["id"]] = ObjClientMarker.create(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), "cylinder", tonumber(v["radius"]), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, v["id"])
    self._markers[v["id"]]:setClosed(true)
    self._blips[v["id"]] = createBlip(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 0, 2.0, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]))
    setBlipColor(self._blips[v["id"]], tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), 0)
  end
end

function ObjRefuelMarkers:Tick()
  for k, v in pairs(self._markers) do
    self._markers[k]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjRefuelMarkers:triggerPulse(id, start)
  self._markers[id .. ""]:triggerPulse(start)
end

function ObjRefuelMarkers:toggleRefuelSpotByID(id, show)
  local r, g, b, a = getBlipColor(self._blips[id .. ""])
  if (show) then
    setBlipColor(self._blips[id .. ""], r, g, b, 255)
    self._markers[id .. ""]:setClosed(false)
  else
    setBlipColor(self._blips[id .. ""], r, g, b, 0)
    self._markers[id .. ""]:setClosed(true)
  end
end

-- Author: Ace_Gambit