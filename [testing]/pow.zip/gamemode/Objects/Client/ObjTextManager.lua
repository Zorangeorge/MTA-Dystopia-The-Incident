-- client script
-- control the way text is displayed
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjTextManager = {}
ObjTextManager.__index = ObjTextManager

function ObjTextManager.create()
  local _objTextManager = {}
  setmetatable(_objTextManager, ObjTextManager)
  _objTextManager._fontUtils = nil
  _objTextManager._params = {}
  _objTextManager._screenX = 0
  _objTextManager._screenY = 0
  _objTextManager._count = 0
  _objTextManager._objMissionText = {}
  _objTextManager._curMissionKeyStr = ""
  _objTextManager._ignoreAudio = false
  _objTextManager._objInstructText = {}
  _objTextManager._objInstructDsp = {}
  _objTextManager._instructTblSize = 0
  _objTextManager._instructTrigger = false
  _objTextManager._instructDl = 5000
  _objTextManager._count = 0
  _objTextManager._oldTick = 0
  _objTextManager._tickAmount = 0
  _objTextManager._oldKillTick = 0
  _objTextManager._objRoleText = {}
  _objTextManager._curRoleKeyStr = "engineer"
  return _objTextManager
end

-- init text  manager
function ObjTextManager:init(fontUtils, params, screenX, screenY)
  self._fontUtils = fontUtils
  self._params = params
  self._screenX = screenX
  self._screenY = screenY
  for k, v in pairs(self._params[1]) do
    self._count = self._count + string.len(self._params[1][k]["value"])
  end
  for k, v in pairs(self._params[3]) do
    self._count = self._count + string.len(self._params[3][k]["value"])
  end
  for k, v in pairs(self._params[5]) do
    self._count = self._count + string.len(self._params[5][k]["value"])
  end
  return self._count
end

function ObjTextManager:createText()
  for k, v in pairs(self._params[1]) do
    self._objMissionText[k] = ObjMissionText.create(self._params[1][k]["fontname"], self._params[2])
    self._objMissionText[k]:init(self._screenX, self._screenY)
    -- create mission text
    self._objMissionText[k]:createMissionText(self._fontUtils, self._params[1][k]["value"], self._params[1][k]["scale"], self._params[1][k]["fadetime"])
    self._curMissionKeyStr = k
  end
  for k, v in pairs(self._params[3]) do
    self._objInstructText[k] = ObjInstructText.create(self._params[3][k]["fontname"], self._params[4])
    self._objInstructText[k]:init(self._screenX, self._screenY)
    -- create instruction text
    self._objInstructText[k]:createInstructText(self._fontUtils, self._params[3][k]["value"], self._params[3][k]["scale"])
  end
  for k, v in pairs(self._params[5]) do
    self._objRoleText[k] = ObjRoleText.create(self._params[5][k]["fontname"], self._params[6])
    self._objRoleText[k]:init(self._screenX, self._screenY)
    -- create squad role text
    self._objRoleText[k]:createRoleText(self._fontUtils, string.upper(self._params[5][k]["value"]), self._params[5][k]["scale"])
  end
end

function ObjTextManager:Tick()
  for k, v in pairs(self._objMissionText) do
    v:Tick()
  end
  for k, v in pairs(self._objInstructText) do
    v:Tick()
  end
  if (self._instructTrigger and self._count < self._instructTblSize) then
    if (self._count == 0) then
      self._objInstructDsp[self._count + 1]:triggerInstructText()
      self._count = self._count + 1
    elseif (self._count > 0 and (getTickCount() - self._oldTick) >= self._instructDl) then
      self._objInstructDsp[self._count]:killInstructText()
      self._objInstructDsp[self._count + 1]:triggerInstructText()
      self._oldTick = getTickCount()
      self._count = self._count + 1
    end
  elseif (self._instructTrigger and self._count >= self._instructTblSize and (getTickCount() - self._oldTick) >= 5000) then
    self._objInstructDsp[self._count]:killInstructText()
    self._instructTrigger = false
  end
  for k, v in pairs(self._objRoleText) do
    v:Tick()
  end
  if (self._oldKillTick > 0 and (getTickCount() - self._oldKillTick) >= self._tickAmount) then
    self._oldKillTick = 0
    self:killAll()
  end
end

-- just ignore...
function ObjTextManager:setInstructDl(value)
  self._instructDl = value
end

function ObjTextManager:triggerMissionText(key)
  self._objMissionText[self._curMissionKeyStr]:killMissionText()
  self._objMissionText[key]:setIgnoreAudio(self._ignoreAudio)
  self._objMissionText[key]:triggerMissionText()
  self._curMissionKeyStr = key
end

-- creates a temporary set of instructions and displays it with a hard coded interval
-- NOTE: you can only show one set of instructions at a time!
function ObjTextManager:createInstructDsp(instructDsp)
  self._instructTrigger = false
  for k, v in ipairs(self._objInstructDsp) do
    self._objInstructDsp[k]:killInstructText()
  end
  self._objInstructDsp = {}
  self._instructTblSize = 0
  self._count = 0
  for k, v in ipairs(instructDsp) do
    table.insert(self._objInstructDsp, self._objInstructText[instructDsp[k]])
    self._instructTblSize = self._instructTblSize + 1
  end
  self._oldTick = getTickCount()
  self._instructTrigger = true
end

function ObjTextManager:setRoleTextIgnoreAudio(ignore)
  self._objRoleText[self._curRoleKeyStr]:setIgnoreAudio(ignore)
end

function ObjTextManager:setMissionTextIgnoreAudio(ignore)
  self._ignoreAudio = ignore
end

function ObjTextManager:triggerRoleText(key)
  self._objRoleText[self._curRoleKeyStr]:killRoleText()
  self._objRoleText[key]:triggerRoleText()
  self._curRoleKeyStr = key
end

function ObjTextManager:killAll()
  for k, v in pairs(self._objMissionText) do
    if (self._objMissionText[k]:getTextVisible()) then
      self._objMissionText[k]:killMissionText()
    end
  end
  for k, v in pairs(self._objRoleText) do
    if (self._objRoleText[k]:getTextVisible()) then
      self._objRoleText[k]:killRoleText()
    end
  end
  self._instructTrigger = false
  for k, v in ipairs(self._objInstructDsp) do
    if (self._objInstructDsp[k]:getTextVisible()) then
      self._objInstructDsp[k]:killInstructText()
    end
  end
end

function ObjTextManager:killRoleText()
  for k, v in pairs(self._objRoleText) do
    if (self._objRoleText[k]:getTextVisible()) then
      self._objRoleText[k]:killRoleText()
    end
  end
end

function ObjTextManager:setKillTimer(tickAmount)
  self._tickAmount = tickAmount
  self._oldKillTick = getTickCount()
end

function ObjTextManager:clearScreen(timer)
  self:createInstructDsp({"blank"})
  self:setKillTimer(timer)
end

-- Author: Ace_Gambit