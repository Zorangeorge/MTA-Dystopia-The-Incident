-- client script
-- control the way camerascene's fade-in or out
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjCineManager = {}
ObjCineManager.__index = ObjCineManager

function ObjCineManager.create(timeToFade)
  local _objCineManager = {}
  setmetatable(_objCineManager, ObjCineManager)
  _objCineManager._source = nil
  _objCineManager._timeToFade = timeToFade / 2
  _objCineManager._triggerFade = false
  _objCineManager._fadedIn = true
  _objCineManager._oldTick = 0
  _objCineManager._lock = false
  _objCineManager._curRot = 1
  _objCineManager._maxRot = 360
  _objCineManager._velocity = 0.2
  _objCineManager._toTarget = 2.5
  _objCineManager._toTargetZ = 2.0
  _objCineManager._trackPosX = 0
  _objCineManager._trackPosY = 0
  _objCineManager._trackPosZ = 0
  _objCineManager._trackable = false
  return _objCineManager
end

-- init cine manager
function ObjCineManager:init(source)
  self._source = source
end

function ObjCineManager:Tick()
  self:fade()
  if (self._trackable) then
    self:track()
  end
end

function ObjCineManager:setFadedIn(fadedIn)
  self._fadedIn = fadedIn
end

-- fades a scene in or out depending on the state it's in
function ObjCineManager:fade()
  if (self._triggerFade) then
    -- screen is black...
    if ((not self._fadedIn and self._oldTick == 0 and not self._lock) or (not self._lock and self._oldTick > 0 and (getTickCount() - self._oldTick) >= ((self._timeToFade / 2) * 1000))) then
      -- fade in and lock
      fadeCamera(true, self._timeToFade)
      self._triggerFade = false
      self._fadedIn = true
      self._oldTick = 0
    -- screen is faded in
    elseif (self._fadedIn) then
      -- fade out and set old tick
      fadeCamera(false, (self._timeToFade / 2), 0, 0, 0)
      self._fadedIn = false
      self._oldTick = getTickCount()
    end
  end
end

function ObjCineManager:track()
  local x, y, z = self._trackPosX, self._trackPosY, self._trackPosZ
  x = x - math.sin(math.rad(self._curRot)) * self._toTarget
  y = y + math.cos(math.rad(self._curRot)) * self._toTarget
  self:setCameraPos(false, x, y, z + self._toTargetZ, self._trackPosX, self._trackPosY, self._trackPosZ)
  if (self._curRot >= self._maxRot) then
    self._curRot = 1
  else
    self._curRot = self._curRot + self._velocity
  end
end

-- rotate camera around target
function ObjCineManager:triggerTrack(trackable, rot, maxRot, velocity, toTarget, toTargetZ, posX, posY, posZ)
  self._trackable = trackable
  if (rot ~= nil and posX ~= nil and posZ ~= nil) then
    self._curRot = rot
    self._maxRot = maxRot
    self._velocity = velocity
    self._toTarget = toTarget
    self._toTargetZ = toTargetZ
    self._trackPosX = posX
    self._trackPosY = posY
    self._trackPosZ = posZ
  end
end

function ObjCineManager:setCameraPos(triggerFade, posX, posY, posZ, targetX, targetY, targetZ)
  local x, y, z = getElementPosition(self._source)
  if (triggerFade) then
    self._triggerFade = true
    self._lock = true
  end
  setCameraPosition(posX, posY, posZ)
  if (targetX == 0 and targetY == 0 and targetZ == 0) then
    setCameraLookAt(x, y, z)
  else
    setCameraLookAt(targetX, targetY, targetZ)
  end
  self._lock = false
end

-- Author: Ace_Gambit