-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjWarfactoryMarkers = {}
ObjWarfactoryMarkers.__index = ObjWarfactoryMarkers

function ObjWarfactoryMarkers.create()
  local _objWarfactoryMarkers = {}
  setmetatable(_objWarfactoryMarkers, ObjWarfactoryMarkers)
  _objWarfactoryMarkers._data = nil
  _objWarfactoryMarkers._markers = {}
  return _objWarfactoryMarkers
end

-- init warfactory markers
function ObjWarfactoryMarkers:init(data)
  local color = nil
  self._data = data
  for k, v in pairs(self._data["spots"]) do
    color = split(v["color"], string.byte(' '))
    self._markers[v["id"]] = {v["team"], ObjClientMarker.create(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), "cylinder", tonumber(v["radius"]), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, v["id"])}
  end
end

function ObjWarfactoryMarkers:Tick()
  for k, v in pairs(self._markers) do
    self._markers[k][2]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjWarfactoryMarkers:triggerPulse(id, start)
  self._markers[id .. ""][2]:triggerPulse(start)
end

function ObjWarfactoryMarkers:getTeamByID(id)
  return self._markers[id .. ""][1]
end

function ObjWarfactoryMarkers:isVehicleAllowed(player, id)
  if (isPlayerInVehicle(player)) then
    return (self:getTeamByID(id) == getElementData(getPlayerOccupiedVehicle(player), "team"))
  end
  return false
end

function ObjWarfactoryMarkers:updateClosed(player)
  local tmpTeam = getPlayerTeam(player)
  if (tmpTeam ~= false) then
    for k, v in pairs(self._markers) do
      v[2]:setClosed(not (getTeamName(tmpTeam) == v[1]))
    end
  end
end

-- Author: Ace_Gambit