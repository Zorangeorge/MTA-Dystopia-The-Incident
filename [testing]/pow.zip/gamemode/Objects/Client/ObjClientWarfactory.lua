-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientWarfactory = {}
ObjClientWarfactory.__index = ObjClientWarfactory

function ObjClientWarfactory.create()
  local _objClientWarfactory = {}
  setmetatable(_objClientWarfactory, ObjClientWarfactory)
  _objClientWarfactory._data = nil
  _objClientWarfactory._clientPlayer = nil
  _objClientWarfactory._textManager = nil
  _objClientWarfactory._cineManager = nil
  _objClientWarfactory._camerasData = nil
  _objClientWarfactory._campaigns = {"recon", "assault"}
  _objClientWarfactory._curCampaign = 1
  _objClientWarfactory._firstSwitch = true
  _objClientWarfactory._marker = nil
  _objClientWarfactory._teamName = ""
  _objClientWarfactory._complete = false
  return _objClientWarfactory
end

-- init client warfactory
function ObjClientWarfactory:init(data, clientPlayer, textManager, cineManager, camerasData)
  local markerX, markerY, markerZ = 0, 0, 0
  local radius = 0
  local color = nil
  self._data = data
  self._clientPlayer = clientPlayer
  self._textManager = textManager
  self._cineManager = cineManager
  self._camerasData = camerasData
  markerX = tonumber(self._data["markerX"])
  markerY = tonumber(self._data["markerY"])
  markerZ = tonumber(self._data["markerZ"])
  radius = tonumber(self._data["radius"])
  color = split(self._data["color"], string.byte(' '))
  self._marker = ObjClientMarker.create(markerX, markerY, markerZ, "cylinder", radius, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, 4000)
end

function ObjClientWarfactory:isValidVehicle(vehicle)
  return (getVehicleID(vehicle) == 470 or getVehicleID(vehicle) == 476)
end

function ObjClientWarfactory:Process(request, vehicle)
  if (request == "funcWaitingTransfer") then
    if (self:isValidVehicle(vehicle) and tonumber(getElementData(vehicle, "ammo")) <= 0) then
      self._textManager:createInstructDsp({"opentransfer", "blank"})
    else
      self._textManager:createInstructDsp({"closetransfer", "blank"})
      playSoundFrontEnd(14)
    end
  end
  if (request == "funcCanceledTransfer") then
    unbindKey("space", "down")
  end
  if (request == "funcStartTransfer") then
    if (self:isValidVehicle(vehicle)) then
      fadeCamera(false, 0.5)
      triggerServerEvent("funcStartTransfer", self._clientPlayer:getSource(), "funcStartTransfer", nil)
    end
  end
  if (request == "funcCampaignSelection") then
    self:triggerSelection()
  end
  if (request == "funcTestAttachments") then
    self:updateAttachments(vehicle)
  end
  if (request == "funcStartCampaign") then
    self:startCampaign()
  end
  if (request == "funcCancelCampaign") then
    self:cancelCampaign()
  end
  if (request == "funcUnfreezeTransfer") then
    triggerServerEvent("funcUnfreezeTransfer", self._clientPlayer:getSource(), "funcUnfreezeTransfer", nil)
  end
end

function ObjClientWarfactory:triggerSelection()
  self._complete = false
  self._firstSwitch = true
  self:switch()
  self._firstSwitch = false
  self._textManager:createInstructDsp({"navcampaign", "joincampaign", "blank"})
  self._textManager:setRoleTextIgnoreAudio(true)
  self._textManager:triggerRoleText("campaign")
end

function ObjClientWarfactory:switch()
  local pos = split(self._camerasData["campaign"]["pos"], string.byte(' '))
  local target = split(self._camerasData["campaign"]["target"], string.byte(' '))
  local team = getPlayerTeam(self._clientPlayer:getSource())
  -- whoops, you are not supposed to be here!
  if (team == false) then
    return
  else
    self._teamName = string.lower(getTeamName(team))
  end
  self._textManager:setMissionTextIgnoreAudio(true)
  if (not self._firstSwitch) then
    -- TODO: erm, sound?!
    fadeCamera(false, 0.5)
  end
  -- relocate camera
  self._cineManager:setCameraPos(true, tonumber(pos[1]) - 1.0, tonumber(pos[2]) - 1.0, tonumber(pos[3]) + 2.0, tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
  self._cineManager:triggerTrack(true, 0, 360, 0.4, 10.0, 5.0, tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
  self._textManager:triggerMissionText(self._teamName .. "-" .. self._campaigns[self._curCampaign])
  triggerServerEvent("funcSetAttachments", self._clientPlayer:getSource(), "funcSetAttachments", {["campaign"] = self._campaigns[self._curCampaign]})
  -- toggle between campaigns...
  if (self._curCampaign == 1) then
    self._curCampaign = 2
  else
    self._curCampaign = 1
  end
  self._textManager:setMissionTextIgnoreAudio(false)
end

function ObjClientWarfactory:startCampaign()
  if (not self._complete) then
    fadeCamera(false, 0.5)
    triggerServerEvent("funcStartCampaign", self._clientPlayer:getSource(), "funcStartCampaign", nil)
    self._complete = true
  end
end

function ObjClientWarfactory:cancelCampaign()
  if (not self._complete) then
    fadeCamera(false, 0.5)
    triggerServerEvent("funcCancelCampaign", self._clientPlayer:getSource(), "funcCancelCampaign", nil)
    self._complete = true
  end
end

-- NOTE: server-side object creation sometimes fails due to MTA bugs
-- create a client-side "shadow copy" when object creation fails
function ObjClientWarfactory:updateAttachments(vehicle)
  local campaign = getElementData(vehicle, "type")
  if (#getAttachedElements(vehicle) <= 1) then
    -- detach
    for k, v in ipairs(getAttachedElements(vehicle)) do
      detachElementFromElement(v)
      destroyElement(v)
    end
    for k, v in ipairs(self._data["attachments"]) do
      if (tonumber(v["vehicle-id"]) == getVehicleID(vehicle) and v["type"] == campaign) then
        attachElementToElement(createObject(tonumber(v["model-id"]), 0, 0, 0, 0, 0, 0), vehicle, tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), tonumber(v["rotX"]), tonumber(v["rotY"]), tonumber(v["rotZ"]))
      end
    end
  end
end

function ObjClientWarfactory:rotateAttachments(vehicle, rot)
  local campaign = getElementData(vehicle, "type")
  for k, v in ipairs(getAttachedElements(vehicle)) do
    for kc, vc in ipairs(self._data["attachments"]) do
      if (tonumber(vc["vehicle-id"]) == getVehicleID(vehicle) and vc["type"] == campaign) then
        if (getObjectModel(v) == tonumber(vc["model-id"])) then
          detachElementFromElement(v)
          attachElementToElement(v, vehicle, tonumber(vc["posX"]), tonumber(vc["posY"]), tonumber(vc["posZ"]), tonumber(vc["rotX"]), tonumber(vc["rotY"]), rot)
        end
      end
    end
  end
end

-- Author: Ace_Gambit