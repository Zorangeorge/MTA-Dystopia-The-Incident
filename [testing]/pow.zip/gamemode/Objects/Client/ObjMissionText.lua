-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

local fadeText = false

ObjMissionText = {}
ObjMissionText.__index = ObjMissionText

function ObjMissionText.create(fontName, fontWidthTbl)
  local _objMissionText = {}
  setmetatable(_objMissionText, ObjMissionText)
  _objMissionText._fontWidthTbl = fontWidthTbl
  _objMissionText._fontName = fontName
  _objMissionText._fontScale = 1.0
  _objMissionText._fontTbl = {}
  _objMissionText._charTbl = {}
  _objMissionText._imageTbl = {}
  _objMissionText._screenX = 0
  _objMissionText._screenY = 0
  _objMissionText._fontWidth = 0
  _objMissionText._canvasWidth = 127
  _objMissionText._canvasHeight = 127
  _objMissionText._fontPadding = 0
  _objMissionText._posX = 0
  _objMissionText._posY = 0
  _objMissionText._textWidth = 0
  _objMissionText._counter = 0
  _objMissionText._tblSize = 0
  _objMissionText._createText = false
  _objMissionText._triggerText = false
  _objMissionText._fadeTimer = nil
  _objMissionText._fadeAlpha = 1.0
  _objMissionText._oldTick = 0
  _objMissionText._fadeTime = 5000
  _objMissionText._ignoreAudio = false
  _objMissionText._textVisible = false
  return _objMissionText
end

-- init mission text
function ObjMissionText:init(scrX, scrY)
  self._screenX = scrX
  self._screenY = scrY
end

function ObjMissionText:setIgnoreAudio(ignore)
  self._ignoreAudio = ignore
end

-- trigger fade-out
function ObjMissionText:fade()
  fadeText = true
end

function ObjMissionText:Tick()
  -- render visible
  if ((self._counter == self._tblSize and self._createText and self._triggerText) or self._triggerText) then
    -- kill any visible text elements
    self:killMissionText()
    self._createText = false
    self._triggerText = false
    self._counter = 0
    for k, v in ipairs(self._imageTbl) do
      guiSetAlpha(v, 1.0)
      guiSetVisible(v, true)
    end
    if (not self._ignoreAudio) then
      playSoundFrontEnd(11)
    end
    self._fadeAlpha = 1.0
    self._fadeTimer = setTimer(self.fade, self._fadeTime, 1)
    self._oldTick = getTickCount()
    self._textVisible = true
  end
  -- we'll use tick to create the buffer frame by frame
  -- due to some odd reason the client 'locks' when using an ordinary loop
  if (self._createText and self._counter < self._tblSize) then
    self._posX = self._posX - ((self._canvasWidth - (self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale)) / 2)
    table.insert(self._imageTbl, guiCreateStaticImage(self._posX, self._posY, self._canvasWidth, self._canvasHeight, self._fontTbl[self._counter + 1], false))
    -- render invisible for now!
    self._fontWidth = self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale
    guiSetVisible(self._imageTbl[self._counter + 1], false)
    self._posX = self._posX + (self._canvasWidth - ((self._canvasWidth - self._fontWidth) / 2)) + self._fontPadding
    self._counter = self._counter + 1
  end
  -- fade
  if (fadeText) then
    self._fadeAlpha = self._fadeAlpha - 0.05
    for k, v in ipairs(self._imageTbl) do
      -- double check so we can kill it any time we want
      if (fadeText) then
        guiSetAlpha(v, self._fadeAlpha)
      end
    end
    if (self._fadeAlpha <= 0) then
      fadeText = false
      self:killMissionText()
    end
  end
  self:fadeKiller()
end

function ObjMissionText:createMissionText(fontUtils, text, fontScale, fadeTime)
  self._fadeTime = fadeTime
  self._fontScale = fontScale
  self._canvasWidth = self._canvasWidth * fontScale
  self._canvasHeight = self._canvasHeight * fontScale
  self._imageTbl = {}
  self._fontTbl, self._charTbl = fontUtils:getSplitStr(text, self._fontName)
  self._textWidth = 0
  self._tblSize = 0
  self._counter = 0
  -- kill any visible text elements
  self:killMissionText()
  -- get width of text in pixels
  for k, v in ipairs(self._fontTbl) do
    self._fontWidth = self._fontWidthTbl[self._charTbl[k]] * self._fontScale
    self._textWidth = self._textWidth + self._fontWidth + self._fontPadding
    self._tblSize = self._tblSize + 1
  end
  -- calculate posX
  self._posX = (self._screenX / 2) - (self._textWidth / 2)
  -- calculate posY
  self._posY = (self._screenY / 2) - ((self._canvasHeight * self._fontScale) / 2)
  -- position text on screen
  self._createText = true
end

function ObjMissionText:triggerMissionText()
  self._triggerText = true
end

-- NOTE: this does not destroy the actual images!
function ObjMissionText:killMissionText()
  -- kill any active timers
  killTimer(self._fadeTimer)
  -- kill active fading
  fadeText = false
  -- render invisible
  for k, v in ipairs(self._imageTbl) do
    guiSetVisible(v, false)
    guiSetAlpha(v, 0)
  end
  self._fadeAlpha = 1.0
  self._textVisible = false
end

-- due to an unresolved bug the mission text sometimes doesn't fade-out
-- clear mission text after n seconds just to be sure
function ObjMissionText:fadeKiller()
  if (self._oldTick > 0 and (getTickCount() - self._oldTick) >= (self._fadeTime + 1000)) then
    self:killMissionText()
    self._oldTick = 0
  end
end

function ObjMissionText:getTextVisible()
  return self._textVisible
end

-- Author: Ace_Gambit