-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjTimerUtils = {}
ObjTimerUtils.__index = ObjTimerUtils

function ObjTimerUtils.create()
  local _objTimerUtils = {}
  setmetatable(_objTimerUtils, ObjTimerUtils)
  _objTimerUtils._timers = {}
  _objTimerUtils._counters = {["CMain"] = 0, ["CFrames"] = 0, ["CWaterBarrier"] = 0}
  _objTimerUtils._numFrames = 0
  _objTimerUtils._loaded = false
  _objTimerUtils._spawned = false
  _objTimerUtils._locked = false
  return _objTimerUtils
end

-- init timer utils
function ObjTimerUtils:init()
  -- nah, don't need it...
end

function ObjTimerUtils:setTimerByID(id, timer)
  self._timers[id] = timer
end

function ObjTimerUtils:getTimerByID(id)
  return self._timers[id]
end

function ObjTimerUtils:setCounterByID(id, value)
  self._counters[id] = value
end

function ObjTimerUtils:getCounterByID(id)
  return self._counters[id]
end

function ObjTimerUtils:counterByID(id, value)
  if (value > 0) then
    self._counters[id] = self._counters[id] + value
  elseif (value < 0) then
    self._counters[id] = self._counters[id] - math.abs(value)
  end
end

function ObjTimerUtils:isRunning(timer)
  local timers = getTimers()
  for k, v in ipairs(timers) do
    if (v == timer) then
      return true
    end
  end
  return false
end

function ObjTimerUtils:killTimerByID(id)
  if (self._timers[id] ~= nil and self._timers[id] ~= false) then
    killTimer(self._timers[id])
  end
end

function ObjTimerUtils:getNumFrames()
  return self._numFrames
end

function ObjTimerUtils:setNumFrames(numFrames)
  self._numFrames = numFrames
end

function ObjTimerUtils:getLoaded()
  return self._loaded
end

function ObjTimerUtils:setLoaded(loaded)
  self._loaded = loaded
end

function ObjTimerUtils:getSpawned()
  return self._spawned
end

function ObjTimerUtils:setSpawned(spawned)
  self._spawned = spawned
end

function ObjTimerUtils:getLocked()
  return self._locked
end

function ObjTimerUtils:setLocked(locked)
  self._locked = locked
end

-- Author: Ace_Gambit