-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSpawnpoints = {}
ObjSpawnpoints.__index = ObjSpawnpoints

function ObjSpawnpoints.create()
  local _objSpawnpoints = {}
  setmetatable(_objSpawnpoints, ObjSpawnpoints)
  _objSpawnpoints._data = nil
  _objSpawnpoints._markers = {}
  _objSpawnpoints._teamsByID = {["Allies"] = 1, ["Axis"] = 2}
  _objSpawnpoints._spawnpointID = -1
  _objSpawnpoints._spawnspotID = -1
  return _objSpawnpoints
end

-- init spawnpoints
function ObjSpawnpoints:init(spawnpointsData)
  local color = nil
  local count = 1
  self._data = spawnpointsData
  for k, v in pairs(self._data) do
    color = split(self._data[k]["color"], string.byte(' '))
    table.insert(self._markers, ObjClientMarker.create(tonumber(self._data[k]["spawn"][1]["posX"]), tonumber(self._data[k]["spawn"][1]["posY"]), tonumber(self._data[k]["spawn"][1]["posZ"]), "cylinder", 2.0, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), 75, true, count))
    count = count + 1
  end
end

function ObjSpawnpoints:getData()
  return self._data
end

function ObjSpawnpoints:Tick()
  for k, v in ipairs(self._markers) do
    self._markers[k]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjSpawnpoints:triggerPulse(id, start)
  self._markers[id]:triggerPulse(start)
end

function ObjSpawnpoints:setPositionByTeam(teamName, spot)
  local posX = tonumber(self._data[teamName]["spawn"][spot]["posX"])
  local posY = tonumber(self._data[teamName]["spawn"][spot]["posY"])
  local posZ = tonumber(self._data[teamName]["spawn"][spot]["posZ"])
  self._markers[self._teamsByID[teamName]]:setPosition(posX, posY, posZ)
  self._spawnspotID = spot
end

function ObjSpawnpoints:getSpawnspotID()
  return self._spawnspotID
end

function ObjSpawnpoints:lockToMarkerByID(player, id, locked)
  local slot = getPlayerWeaponSlot()
  if (not slot) then
    slot = 5
  end
  self._markers[id]:lockToMarker(player:getSource(), locked)
  player:setWeaponSlot(slot)
end

function ObjSpawnpoints:unlockFromMarkers(source)
  for k, v in ipairs(self._markers) do
    v:lockToMarker(source, false)
  end
end

function ObjSpawnpoints:getSpawnpointID()
  return self._spawnpointID
end

function ObjSpawnpoints:setSpawnpointID(id)
  self._spawnpointID = id
end

-- Author: Ace_Gambit