-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjRoleText = {}
ObjRoleText.__index = ObjRoleText

function ObjRoleText.create(fontName, fontWidthTbl)
  local _objRoleText = {}
  setmetatable(_objRoleText, ObjRoleText)
  _objRoleText._fontWidthTbl = fontWidthTbl
  _objRoleText._fontName = fontName
  _objRoleText._fontScale = 1.0
  _objRoleText._fontTbl = {}
  _objRoleText._charTbl = {}
  _objRoleText._imageTbl = {}
  _objRoleText._screenX = 0
  _objRoleText._screenY = 0
  _objRoleText._fontWidth = 0
  _objRoleText._canvasWidth = 50
  _objRoleText._canvasHeight = 50
  _objRoleText._fontPadding = 0
  _objRoleText._posX = 0
  _objRoleText._posY = 0
  _objRoleText._textWidth = 0
  _objRoleText._counter = 0
  _objRoleText._tblSize = 0
  _objRoleText._createText = false
  _objRoleText._ignoreAudio = false
  _objRoleText._textVisible = false
  return _objRoleText
end

-- init role text
function ObjRoleText:init(scrX, scrY)
  self._screenX = scrX
  self._screenY = scrY
end

function ObjRoleText:setIgnoreAudio(ignore)
  self._ignoreAudio = ignore
end

function ObjRoleText:Tick()
  -- render visible
  if ((self._counter == self._tblSize and self._createText and self._triggerText) or self._triggerText) then
    -- kill any visible text elements
    self:killRoleText()
    self._createText = false
    self._triggerText = false
    self._counter = 0
    for k, v in ipairs(self._imageTbl) do
      guiSetVisible(v, true)
    end
    if (not self._ignoreAudio) then
      playSoundFrontEnd(4)
    end
    self._textVisible = true
  end
  -- we'll use tick to create the buffer frame by frame
  -- due to some odd reason the client 'locks' when using an ordinary loop
  if (self._createText and self._counter < self._tblSize) then
    self._posX = self._posX - ((self._canvasWidth - (self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale)) / 2)
    table.insert(self._imageTbl, guiCreateStaticImage(self._posX, self._posY, self._canvasWidth, self._canvasHeight, self._fontTbl[self._counter + 1], false))
    -- render invisible for now!
    self._fontWidth = self._fontWidthTbl[self._charTbl[self._counter + 1]] * self._fontScale
    guiSetVisible(self._imageTbl[self._counter + 1], false)
    self._posX = self._posX + (self._canvasWidth - ((self._canvasWidth - self._fontWidth) / 2)) + self._fontPadding
    self._counter = self._counter + 1
  end
end

function ObjRoleText:createRoleText(fontUtils, text, fontScale)
  self._fontScale = fontScale
  self._canvasWidth = self._canvasWidth * fontScale
  self._canvasHeight = self._canvasHeight * fontScale
  self._imageTbl = {}
  self._fontTbl, self._charTbl = fontUtils:getSplitStr(text, self._fontName)
  self._textWidth = 0
  self._tblSize = 0
  self._counter = 0
  -- kill any visible text elements
  self:killRoleText()
  -- get width of text in pixels
  for k, v in ipairs(self._fontTbl) do
    self._fontWidth = self._fontWidthTbl[self._charTbl[k]] * self._fontScale
    self._textWidth = self._textWidth + self._fontWidth + self._fontPadding
    self._tblSize = self._tblSize + 1
  end
  -- calculate posX
  self._posX = (self._screenX / 2) - (self._textWidth / 2)
  -- calculate posY
  self._posY = (self._screenY / 2) - ((self._canvasHeight * self._fontScale) * 2)
  -- position text on screen
  self._createText = true
end

function ObjRoleText:triggerRoleText()
  self._triggerText = true
end

-- NOTE: this does not destroy the actual images!
function ObjRoleText:killRoleText()
  -- render invisible
  for k, v in ipairs(self._imageTbl) do
    guiSetVisible(v, false)
  end
  self._textVisible = false
end

function ObjRoleText:getTextVisible()
  return self._textVisible
end

-- Author: Ace_Gambit