-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjTeamSelection = {}
ObjTeamSelection.__index = ObjTeamSelection

function ObjTeamSelection.create()
  local _objTeamSelection = {}
  setmetatable(_objTeamSelection, ObjTeamSelection)
  _objTeamSelection._clientPlayer = nil
  _objTeamSelection._camerasData = nil
  _objTeamSelection._cineManager = nil
  _objTeamSelection._spawnpointsData = nil
  _objTeamSelection._textManager = nil
  _objTeamSelection._spawn = {"Allies", "Axis"}
  _objTeamSelection._oldSpawn = 1
  _objTeamSelection._curSpawn = 1
  _objTeamSelection._roles = {"engineer", "marksman", "grenadier", "medic"}
  _objTeamSelection._oldRole = 1
  _objTeamSelection._curRole = 1
  _objTeamSelection._firstSwitch = true
  -- current amount of players in each team
  -- use server script to get most recent updates!
  _objTeamSelection._curTeams = {["Allies"] = 0, ["Axis"] = 0}
  return _objTeamSelection
end

-- init team selection screen
function ObjTeamSelection:init(clientPlayer, camerasData, cineManager, spawnpointsData, textManager)
  self._clientPlayer = clientPlayer
  self._camerasData = camerasData
  self._cineManager = cineManager
  self._spawnpointsData = spawnpointsData
  self._textManager = textManager
end

function ObjTeamSelection:updateTeams(params)
  for k, v in pairs(params) do
    self._curTeams[k] = params[k]
  end
end

function ObjTeamSelection:triggerSelection(restore)
  triggerServerEvent("funcUnsetPlayer", self._clientPlayer:getSource(), "funcUnsetPlayer", nil)
  if (restore) then
    self._curSpawn = self._oldSpawn
    self._curRole = self._oldRole
  end
  self._firstSwitch = true
  self:switch()
  self._firstSwitch = false
  self._textManager:createInstructDsp({"navteam", "navrole", "jointeam", "blank"})
  self._textManager:setRoleTextIgnoreAudio(true)
  self._textManager:triggerRoleText(self._roles[1])
end

function ObjTeamSelection:switch()
  local pos = split(self._camerasData[string.lower(self._spawn[self._curSpawn])]["pos"], string.byte(' '))
  local target = split(self._camerasData[string.lower(self._spawn[self._curSpawn])]["target"], string.byte(' '))
  local posX = tonumber(self._spawnpointsData[self._spawn[self._curSpawn]]["spawn"][1]["posX"])
  local posY = tonumber(self._spawnpointsData[self._spawn[self._curSpawn]]["spawn"][1]["posY"])
  local posZ = tonumber(self._spawnpointsData[self._spawn[self._curSpawn]]["spawn"][1]["posZ"])
  local rot = tonumber(self._spawnpointsData[self._spawn[self._curSpawn]]["spawn"][1]["rot"])
  self._textManager:setMissionTextIgnoreAudio(true)
  if (not self._firstSwitch) then
    -- TODO: erm, sound?!
    fadeCamera(false, 0.5)
  end
  -- relocate player and camera
  self._clientPlayer:setPosition(posX, posY, posZ + 1.0, rot)
  self._clientPlayer:setSkin(tonumber(self._spawnpointsData[self._spawn[self._curSpawn]]["skin"]))
  self._cineManager:setCameraPos(true, tonumber(pos[1]) - 1.5, tonumber(pos[2]) - 1.5, tonumber(pos[3]) + 1.0, tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
  self._cineManager:triggerTrack(true, rot, 360, 0.4, 1.5, 1.0, posX, posY, posZ)
  self._textManager:triggerMissionText(string.lower(self._spawn[self._curSpawn]))
  self._oldSpawn = self._curSpawn
  triggerServerEvent("funcSwitchWeapons", self._clientPlayer:getSource(), "funcSwitchWeapons", {["team"] = self._spawn[self._curSpawn], ["squadrole"] = self._roles[self._oldRole]})
  -- toggle between teams...
  if (self._curSpawn == 1) then
    self._curSpawn = 2
  else
    self._curSpawn = 1
  end
  self._textManager:setMissionTextIgnoreAudio(false)
end

function ObjTeamSelection:switchRole(navDir)
  self._textManager:setRoleTextIgnoreAudio(false)
  if (navDir == 1 and self._curRole == 4) then -- up key
    self._curRole = 1
  elseif (navDir == 1 and self._curRole < 4) then
    self._curRole = self._curRole + 1
  end
  if (navDir == 0 and self._curRole == 1) then -- down key
    self._curRole = 4
  elseif (navDir == 0 and self._curRole > 1) then
    self._curRole = self._curRole - 1
  end
  self._textManager:triggerRoleText(self._roles[self._curRole])
  self._oldRole = self._curRole
  triggerServerEvent("funcSwitchWeapons", self._clientPlayer:getSource(), "funcSwitchWeapons", {["team"] = self._spawn[self._oldSpawn], ["squadrole"] = self._roles[self._curRole]})
end

function ObjTeamSelection:setPlayerTeam()
  if (self._curTeams[self._spawn[self._oldSpawn]] == 16) then -- NOTE: max players per team is hardcoded!
    self._textManager:createInstructDsp({"noteamslots", "navteam", "blank"})
    playSoundFrontEnd(4)
    return false, nil
  else
    triggerServerEvent("funcSetPlayerTeam", self._clientPlayer:getSource(), "funcSetPlayerTeam", {["team"] = self._spawn[self._oldSpawn], ["squadrole"] = self._roles[self._oldRole]})
    return true, string.lower(self._spawn[self._oldSpawn])
  end
end

-- Author: Ace_Gambit