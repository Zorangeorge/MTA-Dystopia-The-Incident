-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjAmmodepotMarkers = {}
ObjAmmodepotMarkers.__index = ObjAmmodepotMarkers

function ObjAmmodepotMarkers.create()
  local _objAmmodepotMarkers = {}
  setmetatable(_objAmmodepotMarkers, ObjAmmodepotMarkers)
  _objAmmodepotMarkers._data = nil
  _objAmmodepotMarkers._type = {["air"] = "ring", ["land"] = "cylinder"}
  _objAmmodepotMarkers._markers = {}
  return _objAmmodepotMarkers
end

-- init ammo depot markers
function ObjAmmodepotMarkers:init(data)
  local color = nil
  self._data = data
  for k, v in pairs(self._data) do
    color = split(v["color"], string.byte(' '))
    self._markers[v["id"]] = {v["team"], ObjClientMarker.create(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), self._type[v["type"]], tonumber(v["radius"]), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, v["id"])}
    self._markers[v["id"]][2]:setClosed(true)
    if (v["type"] == "air") then
      self._markers[v["id"]][2]:setFacingTarget(tonumber(v["posX"]), tonumber(v["posY"]) + 100.0, tonumber(v["posZ"]))
    end
  end
end

function ObjAmmodepotMarkers:Tick()
  for k, v in pairs(self._markers) do
    self._markers[k][2]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjAmmodepotMarkers:triggerPulse(id, start)
  self._markers[id .. ""][2]:triggerPulse(start)
end

function ObjAmmodepotMarkers:getTeamByID(id)
  return self._markers[id .. ""][1]
end

function ObjAmmodepotMarkers:isVehicleAllowed(player, id)
  if (isPlayerInVehicle(player)) then
    return (self:getTeamByID(id) == getElementData(getPlayerOccupiedVehicle(player), "team"))
  end
  return false
end

function ObjAmmodepotMarkers:updateClosed(player, offsetAmmo)
  local tmpTeam = getPlayerTeam(player)
  local tmpVehicle = getPlayerOccupiedVehicle(player)
  local tmpAmmo = false
  local tmpCampaign = false
  if (tmpTeam ~= false and tmpVehicle ~= false) then
    tmpAmmo = getElementData(tmpVehicle, "ammo")
    tmpCampaign = getElementData(tmpVehicle, "type")
    if (player == getVehicleController(tmpVehicle) and tmpAmmo ~= false and tmpCampaign ~= false) then
      for k, v in pairs(self._markers) do
        v[2]:setClosed(not (getTeamName(tmpTeam) == v[1] and (tonumber(tmpAmmo) - offsetAmmo) <= 0 and tmpCampaign ~= "ranger"))
      end
      return
    end
  end
  for k, v in pairs(self._markers) do
    v[2]:setClosed(true)
  end
end

-- Author: Ace_Gambit