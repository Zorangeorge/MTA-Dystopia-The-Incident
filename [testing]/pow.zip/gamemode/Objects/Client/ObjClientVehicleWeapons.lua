-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientVehicleWeapons = {}
ObjClientVehicleWeapons.__index = ObjClientVehicleWeapons

function ObjClientVehicleWeapons.create()
  local _objClientVehicleWeapons = {}
  setmetatable(_objClientVehicleWeapons, ObjClientVehicleWeapons)
  _objClientVehicleWeapons._data = nil
  _objClientVehicleWeapons._textManager = nil
  _objClientVehicleWeapons._clientWarfactory = nil
  _objClientVehicleWeapons._clientPlayer = nil
  _objClientVehicleWeapons._flareArea = false
  _objClientVehicleWeapons._progressBars = nil
  _objClientVehicleWeapons._oldReloadPos = 200
  _objClientVehicleWeapons._turretDir = ""
  _objClientVehicleWeapons._turretSource = false
  _objClientVehicleWeapons._eventToggled = false
  -- bomb
  _objClientVehicleWeapons._bomb = false
  _objClientVehicleWeapons._object = false
  _objClientVehicleWeapons._sabotZ = -1
  _objClientVehicleWeapons._funcArmVWBomb = nil
  _objClientVehicleWeapons._funcArmVWReconASFlare = nil
  return _objClientVehicleWeapons
end

-- init client vehicle weapons
function ObjClientVehicleWeapons:init(data, textManager, clientWarfactory, clientPlayer, progressBars)
  self._data = data
  self._textManager = textManager
  self._clientWarfactory = clientWarfactory
  self._clientPlayer = clientPlayer
  self._progressBars = progressBars
  self._progressBars:createBar("PBarVehicleWeapons", 100, 13, 0, 200, 200, "purple", 60, 400, true)
  self._funcArmVWBomb =
    function (player, armed)
      local vX, vY, vZ = 0, 0, 0
      local x, y, z = 0, 0, 0
      if (not armed) then
        playSoundFrontEnd(42)
        detachElementFromElement(self._object)
        setTimer(setElementCollisionsEnabled, 500, 1, self._bomb, true)
        setTimer(self._funcArmVWBomb, 2500, 1, player, true)
      else
        -- velocity check over z-axis
        vX, vY, vZ = getElementVelocity(self._object)
        -- check if bomb bounced off (vZ becomes positive) or stopped moving
        if ((vZ > 0) or (vX == 0 and vY == 0 and vZ == 0)) then
          x, y, z = getElementPosition(self._bomb)
          -- detonate bomb
          destroyElement(self._bomb)
          blowVehicle(self._object, true)
          destroyElement(self._object)
          -- create explosion at bomb position
          triggerServerEvent("funcCreateExplosion", player, "funcCreateExplosion", {["posX"] = x, ["posY"] = y, ["posZ"] = z})
          -- create mini-flares
          createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
          createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
          createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
          createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
        else
          setTimer(self._funcArmVWBomb, 50, 1, player, true)
        end
      end
    end
  self._funcArmVWReconASFlare =
    function (player, armed)
      local x, y, z = 0, 0, 0
      local vX, vY, vZ = 0, 0, 0
      if (not armed) then
        playSoundFrontEnd(42)
        detachElementFromElement(self._object)
        setTimer(setElementCollisionsEnabled, 500, 1, self._bomb, true)
        setTimer(self._funcArmVWReconASFlare, 2500, 1, player, true)
      else
        vX, vY, vZ = getElementVelocity(self._object)
        x, y, z = getElementPosition(self._bomb)
        self._sabotZ = z
        -- detonate recon sabot
        destroyElement(self._bomb)
        blowVehicle(self._object, true)
        destroyElement(self._object)
        createExplosion(x, y, z, 4, true, 1.0, false)
        -- create recon flare
        -- maintain steady course with constant velocity over Z-axis
        createProjectile(player, 20, x, y, z, 0, nil, 0, 0, 0, vX, vY, 0)
        -- create mini-flares
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
      end
    end
end

function ObjClientVehicleWeapons:Tick()
  if (self._progressBars:getBarByID("PBarVehicleWeapons") ~= nil) then
    self._progressBars:TickByID("PBarVehicleWeapons")
  end
  if (self._turretDir ~= "" and self._turretSource ~= false) then
    self:rotateTurret(self._turretSource, self._turretDir)
  end
end

function ObjClientVehicleWeapons:setEventToggled(toggled)
  self._eventToggled = toggled
end

function ObjClientVehicleWeapons:getEventToggled()
  return self._eventToggled
end

function ObjClientVehicleWeapons:showBar(source)
  local campaign = getElementData(source, "type")
  local ammo = getElementData(source, "ammo")
  if (campaign ~= "ranger" and tonumber(ammo) > 0) then
    self._progressBars:setPositionByID("PBarVehicleWeapons", self:getReloadPosition(true))
    self._progressBars:showByID("PBarVehicleWeapons")
  else
    self:hideBar()
  end
end

function ObjClientVehicleWeapons:hideBar()
  self._progressBars:hideByID("PBarVehicleWeapons")
end

function ObjClientVehicleWeapons:getAmmo(vehicle)
  local ammo = getElementData(vehicle, "ammo")
  return tonumber(ammo)
end

function ObjClientVehicleWeapons:toggleBar(vehicle, offsetAmmo)
  local ammo = self:getAmmo(vehicle)
  if (vehicle == false) then
    return
  end
  if ((tonumber(ammo) - offsetAmmo) <= 0) then
    self:hideBar()
    self._textManager:createInstructDsp({"noammo", "reload", "blank"})
  else
    self:showBar(vehicle)
  end
end

function ObjClientVehicleWeapons:update(vehicle)
  local reloadPos = self:getReloadPosition(true)
  if (reloadPos ~= false) then
    reloadPos = tonumber(reloadPos)
    self._progressBars:setPositionByID("PBarVehicleWeapons", reloadPos)
    -- lower reload threshold...
    if (((reloadPos / 200) * 100) >= 100) then
      if (getElementData(vehicle, "type") ~= "ranger" and self:getAmmo(vehicle) > 0) then
        playSoundFrontEnd(46)
      end
      self._progressBars:setMaxByID("PBarVehicleWeapons", 1)
      self._progressBars:stepMaxByID("PBarVehicleWeapons")
      self._oldReloadPos = 200
    end
  end
  return reloadPos
end

function ObjClientVehicleWeapons:getReloadPosition(current)
  local reloadPos = getElementData(getPlayerOccupiedVehicle(self._clientPlayer:getSource()), "reload-pos")
  if (current) then
    if (reloadPos ~= false) then
      return reloadPos
    end
  else
    return self._oldReloadPos
  end
  return 0
end

function ObjClientVehicleWeapons:rotateTurret(source, dir)
  local vehicle = false
  local rot = 0
  local speed = 1.0
  if (source == nil or source == false) then
    return
  end
  if (isPlayerInVehicle(source)) then
    vehicle = getPlayerOccupiedVehicle(source)
    if (getVehicleID(vehicle) == 470) then
      rot = getElementData(vehicle, "turret-rot")
      if (rot ~= false) then
        rot = tonumber(rot)
        if (dir == "left") then
          if ((rot + speed) < 360) then
            rot = rot + speed
          else
            rot = 0
          end
        end
        if (dir == "right") then
          if ((rot - speed) > 0) then
            rot = rot - speed
          else
            rot = 360
          end
        end
        setElementData(vehicle, "turret-rot", rot)
        self._clientWarfactory:rotateAttachments(vehicle, tonumber(rot))
      end
    end
  end
end

-- NOTE: works with Patriots in assault mode
-- other vehicles are ignored...
function ObjClientVehicleWeapons:triggerTurret(source, dir, rotate)
  local campaign = getElementData(getPlayerOccupiedVehicle(source), "type")
  if (rotate and getVehicleID(getPlayerOccupiedVehicle(source)) == 470 and campaign == "assault") then
    self._turretSource = source
    self._turretDir = dir
  else
    self._turretSource = false
    self._turretDir = ""
  end
end

function ObjClientVehicleWeapons:getSabotZ()
  return self._sabotZ
end

function ObjClientVehicleWeapons:Process(source, x, y, z, explosionType)
  local campaign = false
  local player = self._clientPlayer:getSource()
  if (isPlayerInVehicle(source) and z >= 25.0) then
    campaign = getElementData(getPlayerOccupiedVehicle(source), "type")
    if (explosionType == 2 and source == player and
        (getVehicleID(getPlayerOccupiedVehicle(source)) == 470 or
        (getVehicleID(getPlayerOccupiedVehicle(source)) == 476 and self._sabotZ ~= -1 and (z > (self._sabotZ - 0.5) and z < (self._sabotZ + 0.5))))
        and campaign == "recon") then
      if (getPlayerWeapon(source) ~= 35 and getPlayerWeapon(source) ~= 36) then
        self._sabotZ = -1
        -- create mini-flares
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, math.random(2, 5) / 10, -(math.random(2, 5) / 10), math.random(1, 5) / 10)
        createProjectile(player, 21, x, y, z, 1.0, nil, 0, 0, 0, -(math.random(2, 5) / 10), math.random(2, 5) / 10, math.random(1, 5) / 10)
        self:destroyFlareArea()
        -- create a light pillar that highlights the spot directly beneath the flare
        self._flareArea = createMarker(x, y, -100, "checkpoint", 6.0, 222, 222, 222, 75)
        setElementData(self._flareArea, "id", "flare")
        triggerServerEvent("funcTriggerFlareArea", player, "funcTriggerFlareArea", {["posX"] = x, ["posY"] = y})
        self._eventToggled = false
      end
    end
  end
end

function ObjClientVehicleWeapons:destroyFlareArea()
  local id = false
  for k, v in ipairs(getElementsByType("marker")) do
    id = getElementData(v, "id")
    if (id == "flare") then
      destroyElement(v)
    end
  end
end

function ObjClientVehicleWeapons:ProcessVWBarrage()
  local vehicle = false
  local object = false
  local x, y, z = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  local vX, vY, vZ = 0, 0, 0
  local thrustZ = 0.5
  self._progressBars:stepMinByID("PBarVehicleWeapons")
  self._progressBars:setMaxByID("PBarVehicleWeapons", 200)
  if (isPlayerInVehicle(self._clientPlayer:getSource())) then
    vehicle = getPlayerOccupiedVehicle(self._clientPlayer:getSource())
    if (vehicle ~= false) then
      for k, v in ipairs(getAttachedElements(vehicle)) do
        -- get the last attached object...
        if (getElementType(v) == "object") then
          object = v
        end
      end
      if (object ~= false) then
        rotX, rotY, rotZ = getObjectRotation(object)
        x, y, z = getElementPosition(object)
        x = x - math.sin(math.rad(rotZ)) * 2.5
        y = y + math.cos(math.rad(rotZ)) * 2.5
        vX = math.sin (math.rad((rotZ))) * 1.2
        vY = math.cos(math.rad((rotZ))) * 1.2
        vZ = math.tan(math.rad(-(rotX)))
        createProjectile(self._clientPlayer:getSource(), 21, x, y, z + 3.5, 0, nil, 0, 0, 0, vX, vY, vZ + thrustZ)
        -- NOTE: explosions are not synced!
        createExplosion(x, y, z + 3.5, 10, true, 1.0, false)
      end
    end
  end
end

function ObjClientVehicleWeapons:ProcessVWReconFlare()
  local vehicle = false
  local object = false
  local x, y, z = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  local vX, vY, vZ = 0, 0, 0
  local thrustZ = 0.5
  self._progressBars:stepMinByID("PBarVehicleWeapons")
  self._progressBars:setMaxByID("PBarVehicleWeapons", 200)
  if (isPlayerInVehicle(self._clientPlayer:getSource())) then
    vehicle = getPlayerOccupiedVehicle(self._clientPlayer:getSource())
    if (vehicle ~= false) then
      for k, v in ipairs(getAttachedElements(vehicle)) do
        -- get the last attached object...
        if (getElementType(v) == "object") then
          object = v
        end
      end
      if (object ~= false) then
        rotX, rotY, rotZ = getObjectRotation(object)
        rotZ = rotZ + 90.0
        x, y, z = getElementPosition(object)
        x = x - math.sin(math.rad(rotZ)) * 1.8
        y = y + math.cos(math.rad(rotZ)) * 1.8
        vX = math.sin (math.rad((rotZ)))
        vY = math.cos(math.rad((rotZ)))
        vZ = math.tan(math.rad(-(rotX)))
        createProjectile(self._clientPlayer:getSource(), 19, x, y, z + 1.5, 0, nil, 0, 0, 0, vX, vY, vZ + thrustZ)
        -- NOTE: explosions are not synced!
        createExplosion(x, y, z + 1.5, 4, true, 1.0,  false)
        createExplosion(x, y, z + 1.5, 10, true, 1.0,  false)
      end
    end
  end
end

function ObjClientVehicleWeapons:ProcessVWBomb()
  local vehicle = false
  local campaign = false
  self._progressBars:stepMinByID("PBarVehicleWeapons")
  self._progressBars:setMaxByID("PBarVehicleWeapons", 200)
  if (isPlayerInVehicle(self._clientPlayer:getSource())) then
    vehicle = getPlayerOccupiedVehicle(self._clientPlayer:getSource())
    campaign = getElementData(vehicle, "type")
    if (vehicle ~= false and campaign ~= false) then
      -- attach model to rc vehicle and attach rc vehicle to vehicle
      for k, v in ipairs(self._data["attachments"]) do
        if (tonumber(v["vehicle-id"]) == getVehicleID(vehicle) and v["type"] == campaign) then
          if (self._bomb ~= nil and self._bomb ~= false) then
            -- destroy bomb
            destroyElement(self._bomb)
          end
          if (self._object ~= nil and self._object ~= false) then
            -- destroy object
            destroyElement(self._object)
          end
          -- create bomb model
          self._bomb = createObject(tonumber(v["model-id"]), 0, 0, 0, 0, 0, 0)
          setElementCollisionsEnabled(self._bomb, false)
          -- create rc vehicle
          self._object = createVehicle(441, 0, 0, 0)
          setElementAlpha(self._object, 0)
          -- attach bomb to rc vehicle
          attachElementToElement(self._bomb, self._object, 0, 0, 0, 0, 0, tonumber(v["rotZ"]))
          -- attach rc vehicle to vehicle
          attachElementToElement(self._object, vehicle, 0, 0, tonumber(v["posZ"]), 0, 0, 0)
          setTimer(self._funcArmVWBomb, 500, 1, self._clientPlayer:getSource(), false)
        end
      end
    end
  end
end

function ObjClientVehicleWeapons:ProcessVWReconASFlare(attachmentID)
  local vehicle = false
  local campaign = false
  local attachment = attachmentID
  local objectID = 1
  self._progressBars:stepMinByID("PBarVehicleWeapons")
  self._progressBars:setMaxByID("PBarVehicleWeapons", 200)
  if (isPlayerInVehicle(self._clientPlayer:getSource())) then
    vehicle = getPlayerOccupiedVehicle(self._clientPlayer:getSource())
    campaign = getElementData(vehicle, "type")
    if (vehicle ~= false and campaign ~= false) then
      if (tonumber(attachment) == nil) then
        attachment = -1
      end
      -- attach model to rc vehicle and attach rc vehicle to vehicle
      for k, v in ipairs(self._data["attachments"]) do
        if (tonumber(v["vehicle-id"]) == getVehicleID(vehicle) and v["type"] == campaign) then
          if (objectID == tonumber(attachment)) then
            if (self._bomb ~= nil and self._bomb ~= false) then
              -- destroy bomb
              destroyElement(self._bomb)
            end
            if (self._object ~= nil and self._object ~= false) then
              -- destroy object
              destroyElement(self._object)
            end
            -- create bomb model
            self._bomb = createObject(tonumber(v["model-id"]), 0, 0, 0, 0, 0, 0)
            setElementCollisionsEnabled(self._bomb, false)
            -- create rc vehicle
            self._object = createVehicle(441, 0, 0, 0)
            setElementAlpha(self._object, 0)
            -- attach bomb to rc vehicle
            attachElementToElement(self._bomb, self._object, 0, 0, 0, 0, 0, tonumber(v["rotZ"]))
            -- attach rc vehicle to vehicle
            attachElementToElement(self._object, vehicle, tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 0, 0, 0)
            setTimer(self._funcArmVWReconASFlare, 500, 1, self._clientPlayer:getSource(), false)
            break
          else
            objectID = objectID + 1
          end
        end
      end
    end
  end
end

-- Author: Ace_Gambit