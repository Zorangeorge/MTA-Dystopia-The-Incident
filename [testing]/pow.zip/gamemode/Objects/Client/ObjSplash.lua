-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSplash = {}
ObjSplash.__index = ObjSplash

function ObjSplash.create()
  local _objSplash = {}
  setmetatable(_objSplash, ObjSplash)
  _objSplash._splash = nil
  return _objSplash
end

-- init splash screen
function ObjSplash:init(screenX, screenY, splash)
  self._splash = guiCreateStaticImage(0, 0, screenX, screenY, splash, false)
  guiSetProperty(self._splash, "Disabled", "True")
end

function ObjSplash:show()
  guiSetVisible(self._splash, true)
end

function ObjSplash:hide()
  guiSetVisible(self._splash, false)
end

-- Author: Ace_Gambit