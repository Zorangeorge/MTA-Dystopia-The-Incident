-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientMarker = {}
ObjClientMarker.__index = ObjClientMarker

function ObjClientMarker.create(posX, posY, posZ, objType, size, r, g, b, a, autoHide, id)
  local _objClientMarker = {}
  setmetatable(_objClientMarker, ObjClientMarker)
  _objClientMarker._pulse = false
  _objClientMarker._marker = createMarker(posX, posY, posZ - 1.480003585815, objType, size, r, g, b, a)
  _objClientMarker._markerSize = size
  _objClientMarker._curSize = size
  _objClientMarker._pulseAmount = size - (size / 8)
  _objClientMarker._pulseDir = 0
  _objClientMarker._pulseSpeed = 0.002
  _objClientMarker._red = r
  _objClientMarker._green = g
  _objClientMarker._blue = b
  _objClientMarker._alpha = a
  _objClientMarker._curAlpha = a
  _objClientMarker._alphaAmount = a - (a / 5)
  _objClientMarker._alphaDir = 0
  _objClientMarker._alphaSpeed = 1.0
  if (objType == "cylinder") then
    _objClientMarker._colshape = ObjClientColshape.create():createTube(posX, posY, posZ, (size - 0.5), (size - 0.5) * 2, id)
  elseif (objType == "ring") then
    _objClientMarker._colshape = ObjClientColshape.create():createSphere(posX, posY, posZ, (size - 0.5), id)
  end
  _objClientMarker._lock = createObject(2992, posX, posY, posZ - 1.480003585815)
  _objClientMarker._autoHide = autoHide
  _objClientMarker._closed = false
  return _objClientMarker
end

-- init client marker
function ObjClientMarker:init()
  -- nah, don't need it...
end

function ObjClientMarker:Tick()
  -- soft pulse
  if (self._pulse) then
    self:pulse()
  end
end

function ObjClientMarker:setFacingTarget(posX, posY, posZ)
  setMarkerTarget(self._marker, posX, posY, posZ)
end

function ObjClientMarker:setClosed(closed)
  if (closed) then
    self._pulse = false
    setMarkerColor(self._marker, self._red, self._green, self._blue, 0)
  else
    setMarkerColor(self._marker, self._red, self._green, self._blue, self._curAlpha)
  end
  self._closed = closed
end

function ObjClientMarker:setSize()
  -- marker size
  if (self._curSize >= self._markerSize) then
    self._pulseDir = 0
  elseif (self._curSize <= self._pulseAmount) then
    self._pulseDir = 1
  end
  if (self._pulseDir == 0) then
    self._curSize = self._curSize - self._pulseSpeed
  elseif (self._pulseDir == 1) then
    self._curSize = self._curSize + self._pulseSpeed
  end
end

function ObjClientMarker:setAlpha()
  -- marker color
  if (self._curAlpha >= self._alpha) then
    self._alphaDir = 0
  elseif (self._curAlpha <= self._alphaAmount) then
    self._alphaDir = 1
  end
  if (self._alphaDir == 0) then
    self._curAlpha = self._curAlpha - self._alphaSpeed
  elseif (self._alphaDir == 1) then
    self._curAlpha = self._curAlpha + self._alphaSpeed
  end
end

function ObjClientMarker:pulse()
  self:setSize()
  self:setAlpha()
  setMarkerSize(self._marker, self._curSize)
  setMarkerColor(self._marker, self._red, self._green, self._blue, self._curAlpha)
end

function ObjClientMarker:triggerPulse(start)
  if (not self._closed) then
    self._pulse = start
    if (not self._pulse and self._autoHide) then
      setMarkerColor(self._marker, self._red, self._green, self._blue, 0)
    else
      setMarkerColor(self._marker, self._red, self._green, self._blue, self._curAlpha)
    end
  end
end

function ObjClientMarker:setPosition(posX, posY, posZ)
  posZ = posZ - 1.480003585815
  setElementPosition(self._marker, posX, posY, posZ)
  setElementPosition(self._colshape, posX, posY, posZ)
  setElementPosition(self._lock, posX, posY, posZ)
end

function ObjClientMarker:lockToMarker(source, locked)
  local offsetZ = getElementDistanceFromCentreOfMassToBaseOfModel(source)
  if (offsetZ ~= false) then
    if (locked) then
      attachElementToElement(source, self._lock, 0, 0, offsetZ)
    else
      detachElementFromElement(source)
    end
  end
end

-- Author: Ace_Gambit