-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjRepairMarkers = {}
ObjRepairMarkers.__index = ObjRepairMarkers

function ObjRepairMarkers.create()
  local _objRepairMarkers = {}
  setmetatable(_objRepairMarkers, ObjRepairMarkers)
  _objRepairMarkers._data = nil
  _objRepairMarkers._markers = {}
  return _objRepairMarkers
end

-- init repair markers
function ObjRepairMarkers:init(data)
  local color = nil
  self._data = data
  for k, v in pairs(self._data) do
    color = split(v["color"], string.byte(' '))
    self._markers[v["id"]] = ObjClientMarker.create(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), "cylinder", tonumber(v["radius"]), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]), false, v["id"])
  end
end

function ObjRepairMarkers:Tick()
  for k, v in pairs(self._markers) do
    self._markers[k]:Tick()
  end
end

-- trigger pulse of client marker by id
function ObjRepairMarkers:triggerPulse(id, start)
  self._markers[id .. ""]:triggerPulse(start)
end

-- Author: Ace_Gambit