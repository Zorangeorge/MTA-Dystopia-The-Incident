-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientCommands = {}
ObjClientCommands.__index = ObjClientCommands

function ObjClientCommands.create()
  local _objClientCommands = {}
  setmetatable(_objClientCommands, ObjClientCommands)
  _objClientCommands._source = nil
  _objClientCommands._loaded = false
  return _objClientCommands
end

-- init client commands
function ObjClientCommands:init(source)
  self._source = source
end

-- enables/disables client commands
function ObjClientCommands:setEnabled(state)
  self._loaded = state
end

function ObjClientCommands:commandHandler(commandName, arg)
  local posX = 0
  local posY = 0
  local posZ = 0
  local tmpTeam = getPlayerTeam(self._source:getSource())
  if (self._loaded) then
    if (string.lower(commandName) == "/kill") then
      triggerServerEvent("funcKillPlayer", self._source:getSource(), "funcKillPlayer", nil)
    end
  end
end

-- Author: Ace_Gambit