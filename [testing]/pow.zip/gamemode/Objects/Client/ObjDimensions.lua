-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjDimensions = {}
ObjDimensions.__index = ObjDimensions

function ObjDimensions.create()
  local _objDimensions = {}
  setmetatable(_objDimensions, ObjDimensions)
  _objDimensions._player = nil
  _objDimensions._elements = {}
  return _objDimensions
end

-- init dimensions
function ObjDimensions:init()
  -- nah, don't need it...
end

function ObjDimensions:setDimension(player, elements, id)
  self._player = player
  self._elements = elements
  setElementDimension(self._player, id)
  for k, v in pairs(self._elements) do
    for kc, vc in pairs(getElementsByType(self._elements[k])) do
      setElementDimension(vc, id)
    end
  end
end

function ObjDimensions:reset()
  setElementDimension(self._player, 0)
  for k, v in pairs(self._elements) do
    for kc, vc in pairs(getElementsByType(self._elements[k])) do
      setElementDimension(vc, 0)
    end
  end
end

-- Author: Ace_Gambit