-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientVehicle = {}
ObjClientVehicle.__index = ObjClientVehicle

function ObjClientVehicle.create(source, name, id, maxFuel, canRefuel, canRepair)
  local _objClientVehicle = {}
  setmetatable(_objClientVehicle, ObjClientVehicle)
  _objClientVehicle._source = source
  _objClientVehicle._name = name
  _objClientVehicle._id = id
  _objClientVehicle._maxFuel = maxFuel
  _objClientVehicle._canRefuel = canRefuel
  _objClientVehicle._canRepair = canRepair
  _objClientVehicle._blip = nil
  _objClientVehicle._colShape = nil
  return _objClientVehicle
end

-- init client vehicle
function ObjClientVehicle:init()
  -- nah, don't need it
end

function ObjClientVehicle:getSource()
  return self._source
end

function ObjClientVehicle:getId()
  return self._id
end

function ObjClientVehicle:getMaxFuel()
  return self._maxFuel
end

function ObjClientVehicle:getCanRefuel()
  return self._canRefuel
end

function ObjClientVehicle:setCanRefuel(canRefuel)
  self._canRefuel = canRefuel
end

function ObjClientVehicle:getCanRepair()
  return self._canRepair
end

function ObjClientVehicle:setCanRepair(canRepair)
  self._canRepair = canRepair
end

function ObjClientVehicle:getLockedFuel()
  return (getElementData(self._source, "locked-fuel") == "true")
end

function ObjClientVehicle:setBlip(blip)
  self._blip = blip
end

function ObjClientVehicle:getBlip(blip)
  return self._blip
end

function ObjClientVehicle:setColShape(colShape)
  self._colShape = colShape
end

function ObjClientVehicle:getColShape()
  return self._colShape
end

function ObjClientVehicle:getFlag()
  return getElementData(self._colShape, "flag")
end

function ObjClientVehicle:setFlag(flag)
  setElementData(self._colShape, "flag", flag)
end

-- Author: Ace_Gambit