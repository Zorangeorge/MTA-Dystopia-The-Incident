-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjClientVehicles = {}
ObjClientVehicles.__index = ObjClientVehicles

function ObjClientVehicles.create()
  local _objClientVehicles = {}
  setmetatable(_objClientVehicles, ObjClientVehicles)
  _objClientVehicles._data = nil
  _objClientVehicles._vehicles = {}
  return _objClientVehicles
end

-- init client vehicles
function ObjClientVehicles:init(data)
  local source = nil
  self._data = data
  for k, v in pairs(self._data) do
    source = getElementByID(self._data[k]["id"])
    if (source ~= false) then
      self._vehicles[k] = ObjClientVehicle.create(source, self._data[k]["name"], self._data[k]["id"], tonumber(self._data[k]["fuel"]), false, false)
    end
  end
end

function ObjClientVehicles:getMaxFuelByID(id)
  return self._vehicles[id]:getMaxFuel()
end

function ObjClientVehicles:getCanRefuelByID(id)
  return self._vehicles[id .. ""]:getCanRefuel()
end

function ObjClientVehicles:setCanRefuelByID(id, canRefuel)
  self._vehicles[id]:setCanRefuel(canRefuel)
end

function ObjClientVehicles:getCanRepairByID(id)
  return self._vehicles[id .. ""]:getCanRepair()
end

function ObjClientVehicles:setCanRepairByID(id, canRepair)
  self._vehicles[id]:setCanRepair(canRepair)
end

function ObjClientVehicles:getLockedFuelByID(id)
  return self._vehicles[id]:getLockedFuel()
end

function ObjClientVehicles:isVehicleOccupied(vehicle)
  local occupied = false
  local maxPassengers = getVehicleMaxPassengers(vehicle)
  local player = nil
  for i = 0, maxPassengers do
    player = getVehicleOccupant(vehicle, i)
    if (player ~= false) then
      occupied = true
    end
  end
  return occupied
end

-- NOTE: don't create blips until the player enters the colshape
-- creating many blips at once may cause system hangs
function ObjClientVehicles:createClientCols()
  local id = ""
  local x, y, z = 0, 0, 0
  for k, v in pairs(self._vehicles) do
    id = self._vehicles[k]:getId()
    x, y, z = getElementPosition(self._vehicles[k]:getSource())
    self._vehicles[k]:setColShape(ObjClientColshape.create():createTube(x, y, -100, 450, 10000, id))
  end
end

function ObjClientVehicles:triggerBlip(id, flag, blipAlpha)
  local tmpVehicle = self._vehicles[id .. ""]
  if (tmpVehicle ~= nil) then
    if (self:isVehicleOccupied(tmpVehicle:getSource())) then
      blipAlpha = 0
    end
    if (tmpVehicle:getBlip() == nil) then
      tmpVehicle:setBlip(createBlipAttachedTo(tmpVehicle:getSource(), 0, 1.5, 136, 136, 136, blipAlpha, -32768))
    else
      setBlipColor(tmpVehicle:getBlip(), 136, 136, 136, blipAlpha)
    end
    tmpVehicle:setFlag(flag)
  end
end

function ObjClientVehicles:reset()
  for k, v in pairs(self._vehicles) do
    setBlipColor(self._vehicles[k]:getBlip(), 136, 136, 136, 0)
  end
end

-- update colshape
function ObjClientVehicles:updateColShape(id)
  local tmpVehicle = self._vehicles[id .. ""]
  local x, y, z = 0, 0, 0
  if (tmpVehicle ~= nil) then
    x, y, z = getElementPosition(tmpVehicle:getSource())
    setElementPosition(tmpVehicle:getColShape(), x, y, -100)
  end
end

-- restore blips...
function ObjClientVehicles:update()
  local x, y, z = 0, 0, 0
  for k, v in pairs(self._vehicles) do
    x, y, z = getElementPosition(self._vehicles[k]:getSource())
    setElementPosition(self._vehicles[k]:getColShape(), x, y, -100)
    if (self._vehicles[k]:getFlag() == "1") then
      setBlipColor(self._vehicles[k]:getBlip(), 136, 136, 136, 255)
    end
  end
end

function ObjClientVehicles:hideBlipByVehicle(vehicle)
  local id = getElementData(vehicle, "id")
  local r, g, b, a = 0, 0, 0, 0
  local tmpVehicle = nil
  if (id ~= false) then
    tmpVehicle = self._vehicles[id .. ""]
    if (tmpVehicles ~= nil) then
      r, g, b, a = getBlipColor(tmpVehicle:getBlip())
      setBlipColor(tmpVehicle:getBlip(), r, g, b, 0)
    end
  end
end

function ObjClientVehicles:isPlayerController(player)
  if (player ~= false and isPlayerInVehicle(player) ~= false) then
    return (getVehicleController(getPlayerOccupiedVehicle(player)) == player)
  end
  return false
end

function ObjClientVehicles:getVehicleAmmo(vehicle)
  return tonumber(getElementData(vehicle, "ammo"))
end

function ObjClientVehicles:clean()
  local blips = nil
  for k, v in pairs(self._vehicles) do
    blips = getAttachedElements(self._vehicles[k]:getSource())
    for kc, vc in ipairs(blips) do
      if (getElementType(vc) == "blip") then
        destroyElement(vc)
      end
    end
  end
end

-- Author: Ace_Gambit