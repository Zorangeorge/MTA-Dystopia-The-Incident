-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjCameraManager = {}
ObjCameraManager.__index = ObjCameraManager

function ObjCameraManager.create()
  local _objCameraManager = {}
  setmetatable(_objCameraManager, ObjCameraManager)
  _objCameraManager._data = nil
  return _objCameraManager
end

-- init camera manager
function ObjCameraManager:init(data)
  self._data = data
end

function ObjCameraManager:intro(source)
  self:setMode(source, "fixed")
  triggerClientEvent(source, "init", source)
end

function ObjCameraManager:setMode(source, mode)
  setCameraMode(source, mode)
end

function ObjCameraManager:getMode(source)
  return getCameraMode(source)
end

-- Author: Ace_Gambit