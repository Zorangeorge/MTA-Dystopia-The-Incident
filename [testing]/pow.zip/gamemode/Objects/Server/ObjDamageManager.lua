-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjDamageManager = {}
ObjDamageManager.__index = ObjDamageManager

function ObjDamageManager.create()
  local _objDamageManager = {}
  setmetatable(_objDamageManager, ObjDamageManager)
  _objDamageManager._players = nil
  return _objDamageManager
end

-- init damage manager
function ObjDamageManager:init(players)
  self._players = players
end

function ObjDamageManager:Process(request, source, attacker, ...)
  if (request == "funcPlayerDamage") then
    -- store the last attacker that inflicted damage to this player
    -- just in case the player dies and there is no attacker
    -- credits go to the most recent attacker...
  end
  if (request == "funcPlayerWasted") then
    removePlayerFromVehicle(source)
    -- update kills stat
    if (attacker ~= false and attacker ~= nil) then
      if (getClientName(attacker) ~= getClientName(source) and attacker ~= source) then
        self._players:setKills(getClientName(attacker))
      end
    end
    -- update death stat
    self._players:setDeath(getClientName(source))
  end
  if (request == "funcRespawnPending") then
    if (source ~= nil and source ~= false) then
      triggerClientEvent(source, "funcRespawnPending", source, "funcRespawnPending", nil)
      arg[1]:setMode(source, "fixed")
    end
  end
end

-- Author: Ace_Gambit