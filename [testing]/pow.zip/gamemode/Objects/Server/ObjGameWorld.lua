-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjGameWorld = {}
ObjGameWorld.__index = ObjGameWorld

function ObjGameWorld.create()
  local _objGameWorld = {}
  setmetatable(_objGameWorld, ObjGameWorld)
  _objGameWorld._data = nil
  _objGameWorld._minutes = {
      ["weather"] = 0,
      ["waveheight"] = 0
                          }
  _objGameWorld._max = {
      ["weather"] = 0,
      ["waveheight"] = 0
                      }
  _objGameWorld._current = {
      ["weather"] = 1,
      ["waveheight"] = 1
                      }
  return _objGameWorld
end

-- init world settings
function ObjGameWorld:init(data)
  self._data = data
  resetSkyGradient()
  if (self._data["gradient"] ~= "") then
    tbl = split(self._data["gradient"], string.byte(' '))
    if (tonumber(tbl[1]) ~= 0 and tonumber(tbl[2]) ~= 0 and tonumber(tbl[3]) ~= 0 and
          tonumber(tbl[4]) ~= 0 and tonumber(tbl[5]) ~= 0 and tonumber(tbl[6]) ~= 0) then
      setSkyGradient(
        tonumber(tbl[1]),
        tonumber(tbl[2]),
        tonumber(tbl[3]),
        tonumber(tbl[4]),
        tonumber(tbl[5]),
        tonumber(tbl[6])
                    )
    end
  end
  if (self._data["time"] ~= "") then
    tbl = split(self._data["time"], string.byte(':'))
    setTime(
      tonumber(tbl[1]),
      tonumber(tbl[2])
          )
  end
  self:setCurrent("weather")
  self:setCurrent("waveheight")
end

function ObjGameWorld:createWaterBarrier(colshape)
  local pos = split(self._data["waterbarrier"]["pos"], string.byte(' '))
  local radius = tonumber(self._data["waterbarrier"]["radius"])
  local height = tonumber(self._data["waterbarrier"]["height"])
  colshape:createTube(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]), 0, radius, height, "10000")
end

function ObjGameWorld:Process(request, source)
  if (request == "funcWaterBarrierHit") then
    if (isPlayerInWater(source)) then
      triggerClientEvent(source, "funcWaterBarrier", source, "funcWaterBarrier", {["countdown"] = false})
    end
  end
  if (request == "funcWaterBarrierLeave") then
    if (isPlayerInWater(source)) then
      triggerClientEvent(source, "funcWaterBarrier", source, "funcWaterBarrier", {["countdown"] = true})
    end
  end
end

function ObjGameWorld:setCurrent(worldPhysic)
  local tbl = nil
  if (self._data[worldPhysic]["param"] ~= "") then
    tbl = split(self._data[worldPhysic]["param"], string.byte(' '))
    if (worldPhysic == "weather") then
      setWeather(tonumber(tbl[1]))
    elseif (worldPhysic == "waveheight") then
      setWaveHeight(tonumber(tbl[1]))
    end
    for k, v in ipairs(tbl) do
      self._max[worldPhysic] = self._max[worldPhysic] + 1
    end
  end
end

function ObjGameWorld:updateWorld(worldPhysic)
  local tbl = split(self._data[worldPhysic]["param"], string.byte(' '))
  if ((self._minutes[worldPhysic] / 60) >= tonumber(self._data[worldPhysic]["time"])) then
    if (self._current[worldPhysic] < self._max[worldPhysic]) then
      self._current[worldPhysic] = self._current[worldPhysic] + 1
    else
      self._current[worldPhysic] = 1
    end
    if (worldPhysic == "weather") then
      setWeatherBlended(tonumber(tbl[self._current[worldPhysic]]))
    elseif (worldPhysic == "waveheight") then
      setWaveHeight(tonumber(tbl[self._current[worldPhysic]]))
    end
    self._minutes[worldPhysic] = 0
  end
  self._minutes[worldPhysic] = self._minutes[worldPhysic] + 1
end

function ObjGameWorld:update()
  self:updateWorld("weather")
  self:updateWorld("waveheight")
end

-- Author: Ace_Gambit