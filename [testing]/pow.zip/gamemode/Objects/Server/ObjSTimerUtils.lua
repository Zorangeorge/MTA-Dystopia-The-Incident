-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSTimerUtils = {}
ObjSTimerUtils.__index = ObjSTimerUtils

function ObjSTimerUtils.create()
  local _objSTimerUtils = {}
  setmetatable(_objSTimerUtils, ObjSTimerUtils)
  _objSTimerUtils._timers = {}
  return _objSTimerUtils
end

-- init timer utils
function ObjSTimerUtils:init()
  -- nah, don't need it...
end

function ObjSTimerUtils:isRunning(timer)
  local timers = getTimers()
  for k, v in ipairs(timers) do
    if (v == timer) then
      return true
    end
  end
  return false
end

function ObjSTimerUtils:setTimerByID(id, timer)
  self._timers[id] = timer
end

function ObjSTimerUtils:getTimerByID(id)
  return self._timers[id]
end

function ObjSTimerUtils:killTimerByID(id)
  if (self:isRunning(self:getTimerByID(id))) then
    killTimer(self._timers[id])
  end
end

-- Author: Ace_Gambit