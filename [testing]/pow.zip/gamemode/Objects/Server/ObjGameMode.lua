-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjGameMode = {}
ObjGameMode.__index = ObjGameMode

function ObjGameMode.create()
  local _objGameMode = {}
  setmetatable(_objGameMode, ObjGameMode)
  _objGameMode._map = {
      ["map"] = nil,
      ["typedef"] = "map",
      ["index"] = 2
                      }
  _objGameMode._attribute = {
      ["param"] = "param",
      ["time"] = "time",
      ["name"] = "name",
      ["alias"] = "alias",
      ["color"] = "color",
      ["skin"] = "skin",
      ["posX"] = "posX",
      ["posY"] = "posY",
      ["posZ"] = "posZ",
      ["rotX"] = "rotX",
      ["rotY"] = "rotY",
      ["rotZ"] = "rotZ",
      ["targetX"] = "targetX",
      ["targetY"] = "targetY",
      ["targetZ"] = "targetZ",
      ["moverX"] = "moverX",
      ["moverY"] = "moverY",
      ["moverZ"] = "moverZ",
      ["markerX"] = "markerX",
      ["markerY"] = "markerY",
      ["markerZ"] = "markerZ",
      ["rot"] = "rot",
      ["pos"] = "pos",
      ["target"] = "target",
      ["team"] = "team",
      ["stealth"] = "stealth",
      ["health"] = "health",
      ["armor"] = "armor",
      ["id"] = "id",
      ["ammo"] = "ammo",
      ["current"] = "current",
      ["fuel"] = "fuel",
      ["respawn"] = "respawn",
      ["spawn"] = "spawn",
      ["idle"] = "idle",
      ["max-players"] = "max-players",
      ["z-offset"] = "z-offset",
      ["max-projectiles"] = "max-projectiles",
      ["force"] = "force",
      ["projectile-type"] = "projectile-type",
      ["creator-type"] = "creator-type",
      ["radius"] = "radius",
      ["height"] = "height",
      ["target-type"] = "target-type",
      ["model-id"] = "model-id",
      ["object-id"] = "object-id",
      ["vehicle-id"] = "vehicle-id",
      ["txd"] = "txd",
      ["dff"] = "dff",
      ["col"] = "col",
      ["sequence"] = "sequence",
      ["type"] = "type",
      ["trigger"] = "trigger",
      ["closed"] = "closed",
      ["repair"] = "repair",
      ["warfactory"] = "warfactory",
      ["attachment"] = "attachment",
      ["ammo"] = "ammo",
      ["turret-rot"] = "turret-rot",
      ["upgrade"] = "upgrade",
      ["upgrade-id"] = "upgrade-id",
      ["waterbarrier"] = "waterbarrier"
                          }
  _objGameMode._meta = {
      ["meta"] = nil,
      ["typedef"] = "meta",
      ["index"] = 1,
      ["data"] = {
      ["name"] = "",
      ["author"] = "",
      ["description"] = "",
      ["version"] = ""
                 }
                       }
  _objGameMode._deathmatch = {
      ["deathmatch"] = nil,
      ["typedef"] = "deathmatch",
      ["index"] = 1,
      ["data"] = {
      ["mode"] = "",
      ["teambalance"] = "",
      ["duration"] = "",
      ["spawn"] = ""
                 }
                             }
  _objGameMode._world = {
      ["world"] = nil,
      ["typedef"] = "world",
      ["index"] = 1,
      ["data"] = {
      ["gradient"] = "",
      ["time"] = "",
      ["weather"] = {
      ["time"] = "",
      ["param"] = ""
                    },
      ["waveheight"] = {
      ["time"] = "",
      ["param"] = ""
                      },
      ["waterbarrier"] = {
      ["pos"] = "",
      ["radius"] = "",
      ["height"] = ""
                        }
                }
                        }
  _objGameMode._cameras = {
      ["cameras"] = nil,
      ["typedef"] = "cameras",
      ["index"] = 1,
      ["data"] = {
      ["intro"] = {
      ["pos"] = "",
      ["target"] = ""
                  },
      ["allies"] = {
      ["pos"] = "",
      ["target"] = ""
                  },
      ["axis"] = {
      ["pos"] = "",
      ["target"] = ""
                },
      ["allies-alpha"] = {
      ["pos"] = "",
      ["target"] = ""
                        },
      ["allies-bravo"] = {
      ["pos"] = "",
      ["target"] = ""
                        },
      ["allies-charlie"] = {
      ["pos"] = "",
      ["target"] = ""
                          },
      ["allies-delta"] = {
      ["pos"] = "",
      ["target"] = ""
                        },
      ["axis-alpha"] = {
      ["pos"] = "",
      ["target"] = ""
                       },
      ["axis-bravo"] = {
      ["pos"] = "",
      ["target"] = ""
                       },
      ["axis-charlie"] = {
      ["pos"] = "",
      ["target"] = ""
                         },
      ["axis-delta"] = {
      ["pos"] = "",
      ["target"] = ""
                       },
      ["campaign"] = {
      ["pos"] = "",
      ["target"] = ""
                   }
                }
                        }
  _objGameMode._spawnpoints = {
      ["spawnpoints"] = {},
      ["typedef"] = "spawnpoints",
      ["data"] = {
      ["Allies"] = {
      ["alias"] = "",
      ["color"] = "",
      ["skin"] = "",
      ["spawn"] = {}
                   },
      ["Axis"] = {
      ["alias"] = "",
      ["color"] = "",
      ["skin"] = "",
      ["base"] = "",
      ["spawn"] = {}
                }
                }
                            }
  _objGameMode._squadroles = {
      ["squadroles"] = {},
      ["typedef"] = "squadroles",
      ["data"] = {
      ["Allies"] = {
      ["stealth"] = "",
      ["squadrole"] = {
      ["engineer"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["marksman"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["grenadier"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["medic"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     }
                      }
                   },
      ["Axis"] = {
      ["stealth"] = "",
      ["squadrole"] = {
      ["engineer"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["marksman"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["grenadier"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     },
      ["medic"] = {
      ["color"] = "",
      ["health"] = "",
      ["armor"] = ""
      --["weapons"] = {} -- NOT SAFE!
                     }
                      }
                 }
                }
                             }
  -- NOTE: Lua apparently restricts tables with a depth greater than six
  -- that's why we create a three-dimensional table to store weapon information
  _objGameMode._squadweapons = {
      ["Allies"] = {
      ["engineer"] = {},
      ["marksman"] = {},
      ["grenadier"] = {},
      ["medic"] = {}
                  },
      ["Axis"] = {
      ["engineer"] = {},
      ["marksman"] = {},
      ["grenadier"] = {},
      ["medic"] = {}
                }
                              }
  _objGameMode._vehicles = {
      ["vehicles"] = {},
      ["typedef"] = "vehicle",
      ["data"] = {}
                          }
  _objGameMode._projectiles = {
      ["projectiles"] = nil,
      ["typedef"] = "projectiles",
      ["index"] = 1,
      ["data"] = {
      ["projectile"] = {},
      ["trigger"] = {}
                }
                             }
  _objGameMode._engine = {
      ["engine"] = nil,
      ["typedef"] = "engine",
      ["index"] = 1,
      ["data"] = {
      ["model"] = {},
      ["collision"] = {}
                }
                        }
  _objGameMode._objectsequences = {
      ["object-sequence"] = {},
      ["typedef"] = "object-sequence",
      ["data"] = {
      ["loops"] = {},
      ["lifts"] = {}
                }
                                 }
  _objGameMode._refuelspots = {
      ["refuelspots"] = {},
      ["typedef"] = "refuel",
      ["data"] = {}
                          }
  _objGameMode._repairspots = {
      ["repairspots"] = {},
      ["typedef"] = "repair",
      ["data"] = {}
                             }
  _objGameMode._warfactories = {
      ["warfactories"] = nil,
      ["typedef"] = "warfactories",
      ["index"] = 1,
      ["data"] = {
      ["posX"] = "",
      ["posY"] = "",
      ["posZ"] = "",
      ["spots"] = {},
      ["attachments"] = {}
                }
                             }
  _objGameMode._ammodepots = {
      ["ammodepots"] = {},
      ["typedef"] = "ammodepot",
      ["data"] = {}
                             }
  _objGameMode._upgrades = {
      ["upgrades"] = {},
      ["typedef"] = "upgrades",
      ["data"] = {
      ["upgrades"] = {}
                }
                          }
  return _objGameMode
end

-- read map elements and initialize object params
function ObjGameMode:init(resRoot)
  local tmpElement = nil
  local tmpElements = nil
  local tbl = nil
  local tmpTbl = {}
  local tmpTeam = nil
  local tmpRole = nil
  local tmpWeaponTbl = {}
  local tmpType = nil
  local tmpTriggers = {}
  outputDebugString("* Initializing data...")
  self._map["map"] = getElementsByType(self._map["typedef"], resRoot)[self._map["index"]]
  -- get meta data
  self._meta["meta"] = getElementsByType(self._meta["typedef"], self._map["map"])[self._meta["index"]]
  if (self._meta["meta"]) then
    for k, v in pairs(self._meta["data"]) do
      tmpElement = getElementsByType(k, self._meta["meta"])[self._meta["index"]]
      if (tmpElement) then
        self._meta["data"][k] = getElementData(tmpElement, self._attribute["param"])
      end
    end
  end
  -- get deathmatch data
  self._deathmatch["deathmatch"] = getElementsByType(self._deathmatch["typedef"], self._map["map"])[self._deathmatch["index"]]
  if (self._deathmatch["deathmatch"]) then
    for k, v in pairs(self._deathmatch["data"]) do
      tmpElement = getElementsByType(k, self._deathmatch["deathmatch"])[self._deathmatch["index"]]
      if (tmpElement) then
        self._deathmatch["data"][k] = getElementData(tmpElement, self._attribute["param"])
      end
    end
  end
  -- get world data
  self._world["world"] = getElementsByType(self._world["typedef"], self._map["map"])[self._world["index"]]
  if (self._world["world"]) then
    for k, v in pairs(self._world["data"]) do
      tmpElement = getElementsByType(k, self._world["world"])[self._world["index"]]
      if (tmpElement) then
        if (k == "gradient" or k == "time") then
          self._world["data"][k] = getElementData(tmpElement, self._attribute["param"])
        elseif (k == "weather" or k == "waveheight") then
          self._world["data"][k][self._attribute["time"]] = getElementData(tmpElement, self._attribute["time"])
          self._world["data"][k][self._attribute["param"]] = getElementData(tmpElement, self._attribute["param"])
        elseif (k == "waterbarrier") then
          self._world["data"][k][self._attribute["pos"]] = getElementData(tmpElement, self._attribute["pos"])
          self._world["data"][k][self._attribute["radius"]] = getElementData(tmpElement, self._attribute["radius"])
          self._world["data"][k][self._attribute["height"]] = getElementData(tmpElement, self._attribute["height"])
        end
      end
    end
  end
  -- get cameras data
  self._cameras["cameras"] = getElementsByType(self._cameras["typedef"], self._map["map"])[self._cameras["index"]]
  if (self._cameras["cameras"]) then
    for k, v in pairs(self._cameras["data"]) do
      tmpElement = getElementsByType(k, self._cameras["cameras"])[self._cameras["index"]]
      if (tmpElement) then
        self._cameras["data"][k]["pos"] = getElementData(tmpElement, self._attribute["pos"])
        self._cameras["data"][k]["target"] = getElementData(tmpElement, self._attribute["target"])
      end
    end
  end
  -- get spawnpoints data
  self._spawnpoints["spawnpoints"] = getElementsByType(self._spawnpoints["typedef"], self._map["map"])
  if (self._spawnpoints["spawnpoints"]) then
    -- loop Allies and Axis base
    for k, v in ipairs(self._spawnpoints["spawnpoints"]) do
      tmpTeam = getElementData(v, self._attribute["name"])
      self._spawnpoints["data"][tmpTeam]["alias"] = getElementData(v, self._attribute["alias"])
      self._spawnpoints["data"][tmpTeam]["color"] = getElementData(v, self._attribute["color"])
      self._spawnpoints["data"][tmpTeam]["skin"] = getElementData(v, self._attribute["skin"])
      tbl = getElementChildren(v)
      -- loop spawnpoints for each team
      if (tbl) then
        for kc, vc in ipairs(tbl) do
          tmpTbl["posX"] = getElementData(vc, self._attribute["posX"])
          tmpTbl["posY"] = getElementData(vc, self._attribute["posY"])
          tmpTbl["posZ"] = getElementData(vc, self._attribute["posZ"])
          tmpTbl["rot"] = getElementData(vc, self._attribute["rot"])
          self._spawnpoints["data"][tmpTeam]["spawn"][kc] = tmpTbl
          tmpTbl = {}
        end
      end
    end
  end
  -- get squadroles data
  self._squadroles["squadroles"] = getElementsByType(self._squadroles["typedef"], self._map["map"])
  if (self._squadroles["squadroles"]) then
    -- loop Allies and Axis squads
    for k, v in ipairs(self._squadroles["squadroles"]) do
      tmpTeam = getElementData(v, self._attribute["team"])
      self._squadroles["data"][tmpTeam]["stealth"] = getElementData(v, self._attribute["stealth"])
      tbl = getElementChildren(v)
      if (tbl) then
        for kc, vc in ipairs(tbl) do
          tmpRole = getElementData(vc, self._attribute["name"])
          self._squadroles["data"][tmpTeam]["squadrole"][tmpRole]["color"] = getElementData(vc, self._attribute["color"])
          self._squadroles["data"][tmpTeam]["squadrole"][tmpRole]["health"] = getElementData(vc, self._attribute["health"])
          self._squadroles["data"][tmpTeam]["squadrole"][tmpRole]["armor"] = getElementData(vc, self._attribute["armor"])
          tmpWeaponTbl = getElementChildren(vc)
          if (tmpWeaponTbl) then
            for kwc, vwc in ipairs(tmpWeaponTbl) do
              tmpTbl["id"] = getElementData(vwc, self._attribute["id"])
              tmpTbl["ammo"] = getElementData(vwc, self._attribute["ammo"])
              tmpTbl["current"] = getElementData(vwc, self._attribute["current"])
              self._squadweapons[tmpTeam][tmpRole][kwc] = tmpTbl
              tmpTbl = {}
            end
          end
        end
      end
    end
  end
  -- get vehicles data
  self._vehicles["vehicles"] = getElementsByType(self._vehicles["typedef"], self._map["map"])
  for k, v in ipairs(self._vehicles["vehicles"]) do
    tmpTbl["name"] = getElementData(v, self._attribute["name"])
    tmpTbl["id"] = getElementData(v, self._attribute["id"])
    tmpTbl["team"] = getElementData(v, self._attribute["team"])
    tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
    tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
    tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
    tmpTbl["rotX"] = getElementData(v, self._attribute["rotX"])
    tmpTbl["rotY"] = getElementData(v, self._attribute["rotY"])
    tmpTbl["rotZ"] = getElementData(v, self._attribute["rotZ"])
    tmpTbl["fuel"] = getElementData(v, self._attribute["fuel"])
    tmpTbl["respawn"] = getElementData(v, self._attribute["respawn"])
    tmpTbl["spawn"] = getElementData(v, self._attribute["spawn"])
    tmpTbl["idle"] = getElementData(v, self._attribute["idle"])
    tmpTbl["repair"] = getElementData(v, self._attribute["repair"])
    tmpTbl["type"] = getElementData(v, self._attribute["type"])
    tmpTbl["ammo"] = getElementData(v, self._attribute["ammo"])
    tmpTbl["turret-rot"] = getElementData(v, self._attribute["turret-rot"])
    self._vehicles["data"][tmpTbl["id"]] = tmpTbl
    tmpTbl = {}
  end
  -- get projectiles data
  self._projectiles["projectiles"] = getElementsByType(self._projectiles["typedef"], self._map["map"])[self._projectiles["index"]]
  if (self._projectiles["projectiles"]) then
    for k, v in pairs(self._projectiles["data"]) do
      tmpElements = getElementsByType(k, self._projectiles["projectiles"])
      for kc, vc in ipairs(tmpElements) do
        if (k == "projectile") then
          tmpTbl["id"] = getElementData(vc, self._attribute["id"])
          tmpTbl["object-id"] = getElementData(vc, self._attribute["object-id"])
          tmpTbl["team"] = getElementData(vc, self._attribute["team"])
          tmpTbl["max-players"] = getElementData(vc, self._attribute["max-players"])
          tmpTbl["z-offset"] = getElementData(vc, self._attribute["z-offset"])
          tmpTbl["max-projectiles"] = getElementData(vc, self._attribute["max-projectiles"])
          tmpTbl["force"] = getElementData(vc, self._attribute["force"])
          tmpTbl["projectile-type"] = getElementData(vc, self._attribute["projectile-type"])
          tmpTbl["creator-type"] = getElementData(vc, self._attribute["creator-type"])
        end
        if (k == "trigger") then
          tmpTbl["id"] = getElementData(vc, self._attribute["id"])
          tmpTbl["pos"] = getElementData(vc, self._attribute["pos"])
          tmpTbl["radius"] = getElementData(vc, self._attribute["radius"])
          tmpTbl["height"] = getElementData(vc, self._attribute["height"])
          tmpTbl["target-type"] = getElementData(vc, self._attribute["target-type"])
        end
        self._projectiles["data"][k][tmpTbl["id"]] = tmpTbl
        tmpTbl = {}
      end
    end
  end
  -- get engine data
  self._engine["engine"] = getElementsByType(self._engine["typedef"], self._map["map"])[self._engine["index"]]
  if (self._engine["engine"]) then
    for k, v in pairs(self._engine["data"]) do
      tmpElements = getElementsByType(k, self._engine["engine"])
      for kc, vc in ipairs(tmpElements) do
        if (k == "model") then
          tmpTbl["model-id"] = getElementData(vc, self._attribute["model-id"])
          tmpTbl["txd"] = getElementData(vc, self._attribute["txd"])
          tmpTbl["dff"] = getElementData(vc, self._attribute["dff"])
        end
        if (k == "collision") then
          tmpTbl["model-id"] = getElementData(vc, self._attribute["model-id"])
          tmpTbl["col"] = getElementData(vc, self._attribute["col"])
        end
        table.insert(self._engine["data"][k], tmpTbl)
        tmpTbl = {}
      end
    end
  end
  -- get object sequences data
  self._objectsequences["object-sequence"] = getElementsByType(self._objectsequences["typedef"], self._map["map"])
  for k, v in ipairs(self._objectsequences["object-sequence"]) do
    tmpType = getElementData(v, self._attribute["type"])
    -- get loops
    if (tmpType == "loop") then
      -- get sequences
      tmpElements = getElementsByType(self._attribute["sequence"], v)
      for kc, vc in ipairs(tmpElements) do
        table.insert(tmpTbl, {getElementData(vc, self._attribute["time"]),
          getElementData(vc, self._attribute["targetX"]),
          getElementData(vc, self._attribute["targetY"]),
          getElementData(vc, self._attribute["targetZ"]),
          getElementData(vc, self._attribute["moverX"]),
          getElementData(vc, self._attribute["moverY"]),
          getElementData(vc, self._attribute["moverZ"])
            })
      end
      table.insert(self._objectsequences["data"]["loops"],
        {
          ["object-id"] = getElementData(v, "object-id"),
          ["sequences"] = tmpTbl
        }
      )
      tmpTbl = {}
    end
    -- get lifts
    if (tmpType == "lift") then
      -- get sequences
      tmpElements = getElementsByType(self._attribute["sequence"], v)
      for kc, vc in ipairs(tmpElements) do
        table.insert(tmpTbl, {getElementData(vc, self._attribute["time"]),
          getElementData(vc, self._attribute["targetX"]),
          getElementData(vc, self._attribute["targetY"]),
          getElementData(vc, self._attribute["targetZ"]),
          getElementData(vc, self._attribute["moverX"]),
          getElementData(vc, self._attribute["moverY"]),
          getElementData(vc, self._attribute["moverZ"])
            })
      end
      -- get triggers
      tmpElements = getElementsByType(self._attribute["trigger"], v)
      for kc, vc in ipairs(tmpElements) do
        table.insert(tmpTriggers, {getElementData(vc, self._attribute["id"]),
          getElementData(vc, self._attribute["posX"]),
          getElementData(vc, self._attribute["posY"]),
          getElementData(vc, self._attribute["posZ"]),
          getElementData(vc, self._attribute["radius"]),
          getElementData(vc, self._attribute["color"]),
          getElementData(vc, self._attribute["type"])
            })
      end
      table.insert(self._objectsequences["data"]["lifts"],
        {
          ["object-id"] = getElementData(v, "object-id"),
          ["sequences"] = tmpTbl,
          ["triggers"] = tmpTriggers
        }
      )
      tmpTbl = {}
      tmpTriggers = {}
    end
  end
  -- get refuel spots data
  self._refuelspots["refuelspots"] = getElementsByType(self._refuelspots["typedef"], self._map["map"])
  for k, v in ipairs(self._refuelspots["refuelspots"]) do
    tmpTbl["id"] = getElementData(v, self._attribute["id"])
    tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
    tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
    tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
    tmpTbl["radius"] = getElementData(v, self._attribute["radius"])
    tmpTbl["color"] = getElementData(v, self._attribute["color"])
    tmpTbl["closed"] = getElementData(v, self._attribute["closed"])
    self._refuelspots["data"][tmpTbl["id"]] = tmpTbl
    tmpTbl = {}
  end
  -- get repair spots data
  self._repairspots["repairspots"] = getElementsByType(self._repairspots["typedef"], self._map["map"])
  for k, v in ipairs(self._repairspots["repairspots"]) do
    tmpTbl["id"] = getElementData(v, self._attribute["id"])
    tmpTbl["team"] = getElementData(v, self._attribute["team"])
    tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
    tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
    tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
    tmpTbl["radius"] = getElementData(v, self._attribute["radius"])
    tmpTbl["color"] = getElementData(v, self._attribute["color"])
    tmpTbl["closed"] = getElementData(v, self._attribute["closed"])
    self._repairspots["data"][tmpTbl["id"]] = tmpTbl
    tmpTbl = {}
  end
  -- get warfactories data
  self._warfactories["warfactories"] = getElementsByType(self._warfactories["typedef"], self._map["map"])[self._warfactories["index"]]
  if (self._warfactories["warfactories"]) then
    self._warfactories["data"]["posX"] = getElementData(self._warfactories["warfactories"], self._attribute["posX"])
    self._warfactories["data"]["posY"] = getElementData(self._warfactories["warfactories"], self._attribute["posY"])
    self._warfactories["data"]["posZ"] = getElementData(self._warfactories["warfactories"], self._attribute["posZ"])
    self._warfactories["data"]["rotX"] = getElementData(self._warfactories["warfactories"], self._attribute["rotX"])
    self._warfactories["data"]["rotY"] = getElementData(self._warfactories["warfactories"], self._attribute["rotY"])
    self._warfactories["data"]["rotZ"] = getElementData(self._warfactories["warfactories"], self._attribute["rotZ"])
    self._warfactories["data"]["markerX"] = getElementData(self._warfactories["warfactories"], self._attribute["markerX"])
    self._warfactories["data"]["markerY"] = getElementData(self._warfactories["warfactories"], self._attribute["markerY"])
    self._warfactories["data"]["markerZ"] = getElementData(self._warfactories["warfactories"], self._attribute["markerZ"])
    self._warfactories["data"]["radius"] = getElementData(self._warfactories["warfactories"], self._attribute["radius"])
    self._warfactories["data"]["color"] = getElementData(self._warfactories["warfactories"], self._attribute["color"])
    tmpElements = getElementsByType(self._attribute["warfactory"], self._warfactories["warfactories"])
    for k, v in ipairs(tmpElements) do
      tmpTbl["id"] = getElementData(v, self._attribute["id"])
      tmpTbl["team"] = getElementData(v, self._attribute["team"])
      tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
      tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
      tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
      tmpTbl["radius"] = getElementData(v, self._attribute["radius"])
      tmpTbl["color"] = getElementData(v, self._attribute["color"])
      tmpTbl["closed"] = getElementData(v, self._attribute["closed"])
      self._warfactories["data"]["spots"][tmpTbl["id"]] = tmpTbl
      tmpTbl = {}
    end
    tmpElements = getElementsByType(self._attribute["attachment"], self._warfactories["warfactories"])
    for k, v in ipairs(tmpElements) do
      tmpTbl["vehicle-id"] = getElementData(v, self._attribute["vehicle-id"])
      tmpTbl["type"] = getElementData(v, self._attribute["type"])
      tmpTbl["model-id"] = getElementData(v, self._attribute["model-id"])
      tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
      tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
      tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
      tmpTbl["rotX"] = getElementData(v, self._attribute["rotX"])
      tmpTbl["rotY"] = getElementData(v, self._attribute["rotY"])
      tmpTbl["rotZ"] = getElementData(v, self._attribute["rotZ"])
      table.insert(self._warfactories["data"]["attachments"], tmpTbl)
      tmpTbl = {}
    end
  end
  -- get ammo depots data
  self._ammodepots["ammodepots"] = getElementsByType(self._ammodepots["typedef"], self._map["map"])
  for k, v in ipairs(self._ammodepots["ammodepots"]) do
    tmpTbl["id"] = getElementData(v, self._attribute["id"])
    tmpTbl["team"] = getElementData(v, self._attribute["team"])
    tmpTbl["posX"] = getElementData(v, self._attribute["posX"])
    tmpTbl["posY"] = getElementData(v, self._attribute["posY"])
    tmpTbl["posZ"] = getElementData(v, self._attribute["posZ"])
    tmpTbl["radius"] = getElementData(v, self._attribute["radius"])
    tmpTbl["type"] = getElementData(v, self._attribute["type"])
    tmpTbl["color"] = getElementData(v, self._attribute["color"])
    tmpTbl["closed"] = getElementData(v, self._attribute["closed"])
    self._ammodepots["data"][tmpTbl["id"]] = tmpTbl
    tmpTbl = {}
  end
  -- get upgrades data
  self._upgrades["upgrades"] = getElementsByType(self._upgrades["typedef"], self._map["map"])
  for k, v in ipairs(self._upgrades["upgrades"]) do
    tmpElements = getElementsByType(self._attribute["upgrade"], v)
    for kc, vc in ipairs(tmpElements) do
      table.insert(tmpTbl, {getElementData(vc, self._attribute["vehicle-id"]),
        getElementData(vc, self._attribute["upgrade-id"])
          })
    end
    table.insert(self._upgrades["data"]["upgrades"],
      {
        ["id"] = getElementData(v, self._attribute["id"]),
        ["posX"] = getElementData(v, self._attribute["posX"]),
        ["posY"] = getElementData(v, self._attribute["posY"]),
        ["posZ"] = getElementData(v, self._attribute["posZ"]),
        ["radius"] = getElementData(v, self._attribute["radius"]),
        ["list"] = tmpTbl
      }
    )
    tmpTbl = {}
  end
  outputDebugString("* Data initialized")
end

function ObjGameMode:getAllData()
  return {
      ["meta"] = self._meta["data"],
      ["world"] = self._world["data"],
      ["cameras"] = self._cameras["data"],
      ["spawnpoints"] = self._spawnpoints["data"],
      ["squadroles"] = self._squadroles["data"],
      ["squadweapons"] = self._squadweapons,
      ["vehicles"] = self._vehicles["data"],
      ["projectiles"] = self._projectiles["data"],
      ["engine"] = self._engine["data"],
      ["objectsequences"] = self._objectsequences["data"],
      ["refuelspots"] = self._refuelspots["data"],
      ["repairspots"] = self._repairspots["data"],
      ["warfactories"] = self._warfactories["data"],
      ["ammodepots"] = self._ammodepots["data"]
        }
end

function ObjGameMode:getMetaData()
  return self._meta["data"]
end

function ObjGameMode:getDeathmatchData()
  return self._deathmatch["data"]
end

function ObjGameMode:getWorldData()
  return self._world["data"]
end

function ObjGameMode:getCamerasData()
  return self._cameras["data"]
end

function ObjGameMode:getSpawnpointsData()
  return self._spawnpoints["data"]
end

function ObjGameMode:getSquadrolesData()
  return self._squadroles["data"]
end

function ObjGameMode:getSquadweaponsData()
  return self._squadweapons
end

function ObjGameMode:getVehiclesData()
  return self._vehicles["data"]
end

function ObjGameMode:getProjectilesData()
  return self._projectiles["data"]
end

function ObjGameMode:getObjectSequencesData()
  return self._objectsequences["data"]
end

function ObjGameMode:getRefuelspotsData()
  return self._refuelspots["data"]
end

function ObjGameMode:getRepairspotsData()
  return self._repairspots["data"]
end

function ObjGameMode:getWarfactoriesData()
  return self._warfactories["data"]
end

function ObjGameMode:getAmmodepotsData()
  return self._ammodepots["data"]
end

function ObjGameMode:getUpgradesData()
  return self._upgrades["data"]
end

-- Author: Ace_Gambit