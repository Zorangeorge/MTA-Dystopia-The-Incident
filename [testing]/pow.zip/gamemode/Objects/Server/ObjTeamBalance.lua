-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjTeamBalance = {}
ObjTeamBalance.__index = ObjTeamBalance

function ObjTeamBalance.create()
  local _objTeamBalance = {}
  setmetatable(_objTeamBalance, ObjTeamBalance)
  _objTeamBalance._data = nil
  _objTeamBalance._teams = nil
  _objTeamBalance._balance = true
  return _objTeamBalance
end

-- init team balance
function ObjTeamBalance:init(data, spawnpointsData, players)
  self._data = data
  self._teams = ObjTeams.create()
  self._teams:init(spawnpointsData, players)
  self._balance = (tonumber(self._data["teambalance"]) == 1)
end

function ObjTeamBalance:getTeams()
  return self._teams:getTeams()
end

function ObjTeamBalance:getUpdateTeams()
  return self._teams:getUpdateTeams()
end

function ObjTeamBalance:getUpdateSquads()
  return self._teams:getUpdateSquads()
end

function ObjTeamBalance:getUpdates(player)
  -- gather data and update client
  triggerClientEvent("funcUpdateTeams", player:getSource(), "funcUpdateTeams", self:getUpdateTeams())
  triggerClientEvent("funcUpdateSquads", player:getSource(), "funcUpdateSquads", self:getUpdateSquads())
end

function ObjTeamBalance:setPlayerTeam(player, team, role)
  if (player:getChangeTeam()) then
    self._teams:setPlayerTeam(player, team)
    player:setRole(role)
    -- update client
    self:getUpdates(player)
  end
end

function ObjTeamBalance:setPlayerSquad(player, squad)
  if (player:getChangeSquad()) then
    self._teams:setPlayerSquad(player, squad)
    -- update client
    self:getUpdates(player)
  end
end

function ObjTeamBalance:unsetPlayer(player)
  if (player:getUnsetPlayer()) then
    self._teams:unsetPlayer(player)
  end
end

-- Author: Ace_Gambit