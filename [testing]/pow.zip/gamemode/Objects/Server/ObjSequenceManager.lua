-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSequenceManager = {}
ObjSequenceManager.__index = ObjSequenceManager

function ObjSequenceManager.create()
  local _objSequenceManager = {}
  setmetatable(_objSequenceManager, ObjSequenceManager)
  _objSequenceManager._loops = {}
  _objSequenceManager._lifts = {}
  _objSequenceManager._stickyTriggers = {}
  return _objSequenceManager
end

-- init object sequence manager
function ObjSequenceManager:init(data)
  local tmpColShape = nil
  local count = 1
  -- get loops
  for k, v in ipairs(data["loops"]) do
    table.insert(self._loops, ObjSequence.create(v["object-id"]))
    self._loops[count]:init(v["sequences"])
    count = count + 1
  end
  for k, v in ipairs(self._loops) do
    v:setOldTick(getTickCount())
    -- DEBUG: uncomment for debug blip
    -- createBlip(v:getTargetX(), v:getTargetY(), v:getTargetZ(), 0, 2.0, 30, 112, 146, 255)
  end
  -- get lifts
  count = 1
  for k, v in ipairs(data["lifts"]) do
    table.insert(self._lifts, ObjSequence.create(v["object-id"]))
    self._lifts[count]:init(v["sequences"])
    -- create colshapes for each trigger
    for kc, vc in ipairs(v["triggers"]) do
      tmpColShape = ObjColshape.create():createTube(tonumber(vc[2]), tonumber(vc[3]), tonumber(vc[4]) - 0.7, 0.0, tonumber(vc[5]), (tonumber(vc[5]) / 2), tonumber(vc[1]))
      setElementData(tmpColShape, "type", vc[7])
      if (vc[7] == "vehicle") then -- sticky?
        table.insert(self._stickyTriggers, tmpColShape)
      end
    end
    count = count + 1
  end
  for k, v in ipairs(self._lifts) do
    v:setOldTick(1)
    -- DEBUG: uncomment for debug blip
    -- createBlip(v:getTargetX(), v:getTargetY(), v:getTargetZ(), 0, 2.0, 30, 112, 146, 255)
  end
end

function ObjSequenceManager:triggerByID(id)
  -- manage lifts
  for k, v in ipairs(self._lifts) do
    if (v:getObjectID() == "OBJ" .. id) then
      if (v:getOldTick() ~= 0 and ((getTickCount() - v:getOldTick()) >= v:getTime())) then
        if (v:getObject() ~= nil and v:getObject() ~= false) then
          moveObject(v:getObject(), v:getTime(), v:getTargetX(), v:getTargetY(), v:getTargetZ(), v:getMoverX(), v:getMoverY(), v:getMoverZ())
        end
        if (v:getSequence() < v:getMaxSequence()) then
          v:setSequence(v:getSequence() + 1)
        else
          v:setSequence(1)
        end
        v:setOldTick(getTickCount())
      end
    end
  end
end

function ObjSequenceManager:update()
  local id = nil
  local objectTrigger = nil
  local x, y, z = 0, 0, 0
  -- manage loops
  for k, v in ipairs(self._loops) do
    if (v:getOldTick() ~= 0 and ((getTickCount() - v:getOldTick()) >= v:getTime())) then
      if (v:getObject() ~= nil and v:getObject() ~= false) then
        moveObject(v:getObject(), v:getTime(), v:getTargetX(), v:getTargetY(), v:getTargetZ(), v:getMoverX(), v:getMoverY(), v:getMoverZ())
      end
      if (v:getSequence() < v:getMaxSequence()) then
        v:setSequence(v:getSequence() + 1)
      else
        v:setSequence(1)
      end
      v:setOldTick(getTickCount())
    end
  end
  -- manage sticky triggers
  for k, v in ipairs(self._stickyTriggers) do
    id = getElementData(v, "id")
    if (id ~= false) then
      objectTrigger = getElementByID("OBJ" .. id)
      if (objectTrigger ~= false) then
        x, y, z = getElementPosition(objectTrigger)
        setElementPosition(v, x, y, z)
      end
    end
  end
end

-- Author: Ace_Gambit