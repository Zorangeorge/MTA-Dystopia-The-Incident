-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjPlayer = {}
ObjPlayer.__index = ObjPlayer

function ObjPlayer.create(source, skin)
  local _objPlayer = {}
  setmetatable(_objPlayer, ObjPlayer)
  _objPlayer._source = source
  _objPlayer._location = "land" -- land/water
  -- stats
  _objPlayer._stats = {
      ["kills"] = 0,
      ["death"] = 0
                     }
  _objPlayer._name = ""
  _objPlayer._skin = skin
  _objPlayer._shadowBlip = nil
  _objPlayer._blip = nil
  -- NOTE: the following parameters are flags that should only be set by an admin user or the server script!
  _objPlayer._changeWeapons = true -- allow/deny player to change weapons
  _objPlayer._changeTeam = true -- allow/deny player to change team
  _objPlayer._changeSquad = true -- allow/deny player to change squad
  _objPlayer._unsetPlayer = true -- allow/deny player to unset team/squad position
  _objPlayer._spawn = true -- allow/deny player to spawn/respawn
  _objPlayer._changeSkin = true -- allow/deny player to change skin
  _objPlayer._changeCampaign = true -- allow/deny player to change campaign
  _objPlayer._canCreateExplosion = false -- allow/deny player to create explosions
  -- NOTE: health/armor flag does not apply to pickups!
  _objPlayer._setHealth = true -- allow/deny player to set health
  _objPlayer._setArmor = true -- allow/deny player to set armor
  return _objPlayer
end

-- init player
function ObjPlayer:init()
  self:setSkin(self._skin)
  self._name = getClientName(self._source)
  -- store the current state a player is in
  setElementData(self._source, "gamestate", "STNone")
  setElementData(self._source, "protected", "0") -- allow/deny damage to player
  setElementData(self._source, "squad", "alpha")
  setElementData(self._source, "role", "engineer")
  -- player stats
  setElementData(self._source, "stats", self._stats)
end

function ObjPlayer:clean()
  local blips = getAttachedElements(self._source)
  for k, v in ipairs(blips) do
    if (getElementType(v) == "blip") then
      destroyElement(v)
    end
  end
end

-- ########## stats ##########

function ObjPlayer:setKills(kills)
  self._stats["kills"] = kills
end

function ObjPlayer:getKills()
  return self._stats["kills"]
end

function ObjPlayer:setDeath(death)
  self._stats["death"] = death
end

function ObjPlayer:getDeath()
  return self._stats["death"]
end

-- we must update our stats in order to keep it synced!
function ObjPlayer:updateStats()
  setElementData(self._source, "stats", self._stats)
end

-- ########## stats ##########

function ObjPlayer:getName()
  return self._name
end

function ObjPlayer:getLocation()
  return self._location
end

function ObjPlayer:setLocation(location)
  self._location = string.lower(location)
end

function ObjPlayer:getSource()
  return self._source
end

function ObjPlayer:getChangeWeapons()
  return self._changeWeapons
end

function ObjPlayer:getSkin()
  return self._skin
end

function ObjPlayer:getGameState()
  return getElementData(self._source, "gamestate")
end

function ObjPlayer:setRole(role)
  setElementData(self._source, "role", role)
end

function ObjPlayer:getRole()
  return getElementData(self._source, "role")
end

function ObjPlayer:getChangeTeam()
  return self._changeTeam
end

function ObjPlayer:getChangeSquad()
  return self._changeSquad
end

function ObjPlayer:getChangeCampaign()
  return self._changeCampaign
end

function ObjPlayer:getCanCreateExplosion()
  return self._canCreateExplosion
end

function ObjPlayer:setCanCreateExplosion(canCreateExplosion)
  self._canCreateExplosion = canCreateExplosion
end

function ObjPlayer:getUnsetPlayer()
  return self._unsetPlayer
end

function ObjPlayer:getSpawn()
  return self._spawn
end

function ObjPlayer:setProtected(flag)
  setElementData(self._source, "protected", flag)
end

function ObjPlayer:getSquad()
  return getElementData(self._source, "squad")
end

function ObjPlayer:setSquad(squad)
  setElementData(self._source, "squad", squad)
end

function ObjPlayer:setSkin(skin)
  if (self._changeSkin) then
    self._skin = skin
    setPlayerSkin(self._source, self._skin)
  end
end

function ObjPlayer:setShadowBlip(blip)
  self._shadowBlip = blip
end

function ObjPlayer:getShadowBlip()
  return self._shadowBlip
end

function ObjPlayer:setBlip(blip)
  self._blip = blip
end

function ObjPlayer:getBlip()
  return self._blip
end

function ObjPlayer:spawnPlayer(posX, posY, posZ, rot)
  if (self._spawn) then
    spawnPlayer(self._source, posX, posY, posZ + 0.7)
    if (rot > 0) then
      setPlayerRotation(self._source, rot)
    end
  end
end

function ObjPlayer:setHealth(value)
  if (self._setHealth) then
    setElementHealth(self._source, value)
  end
end

function ObjPlayer:setArmor(value)
  if (self._setArmor) then
    setPlayerArmor(self._source, value)
  end
end

-- Author: Ace_Gambit