-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjVehicleWeapons = {}
ObjVehicleWeapons.__index = ObjVehicleWeapons

function ObjVehicleWeapons.create()
  local _objVehicleWeapons = {}
  setmetatable(_objVehicleWeapons, ObjVehicleWeapons)
  _objVehicleWeapons._players = nil
  _objVehicleWeapons._warfactoryManager = nil
  _objVehicleWeapons._blipManager = nil
  _objVehicleWeapons._flareAreas = {}
  _objVehicleWeapons._funcUpdateReloadPos = nil
  _objVehicleWeapons._funcNoRadarBlip = nil
  _objVehicleWeapons._funcDestroyFlare = nil
  return _objVehicleWeapons
end

-- init vehicle weapons
function ObjVehicleWeapons:init(players, warfactoryManager, blipManager)
  self._players = players
  self._warfactoryManager = warfactoryManager
  self._blipManager = blipManager
  self._funcUpdateReloadPos =
    function (vehicle)
      local reloadPos = getElementData(vehicle, "reload-pos")
      if (reloadPos ~= false) then
        reloadPos = tonumber(reloadPos)
        if (reloadPos < 200) then
          reloadPos = reloadPos + 1
          setElementData(vehicle, "reload-pos", reloadPos)
          setTimer(self._funcUpdateReloadPos, 50, 1, vehicle)
        end
      end
    end
  self._funcNoRadarBlip =
    function (player)
      self._blipManager:setBlipVisibleToAll(self._players:getPlayers()[getClientName(player)], true)
    end
  self._funcDestroyFlare =
    function (playerName, callback)
      local player = self._players:getPlayers()[playerName]:getSource()
      local creator = false
      for k, v in ipairs(getElementsByType("colshape")) do
        creator = getElementData(v, "creator")
        if (creator == playerName) then
          destroyElement(v)
        end
      end
      if (callback) then
        triggerClientEvent(player, "funcDestroyFlare", player, "funcDestroyFlare", nil)
      end
      self._blipManager:setBlipVisibleToAll(self._players:getPlayers()[playerName], true)
    end
end

function ObjVehicleWeapons:Process(source)
  local vehicle = false
  local campaign = ""
  local ammo = nil
  local reloadPos = false
  if (isPlayerInVehicle(source)) then
    vehicle = getPlayerOccupiedVehicle(source)
    campaign = getElementData(vehicle, "type")
    reloadPos = getElementData(vehicle, "reload-pos")
    if (campaign ~= false and reloadPos ~= false) then
      ammo = getElementData(vehicle, "ammo")
      reloadPos = tonumber(reloadPos)
      if (tonumber(ammo) ~= nil) then
        ammo = tonumber(ammo)
      else
        ammo = 0
      end
      if (ammo > 0 and reloadPos >= 200) then
        setElementData(vehicle, "reload-pos", 0)
        if (campaign == "assault") then
          if (getVehicleID(vehicle) == 470) then -- patriot
            triggerClientEvent(source, "funcCreateVWBarrage", source, "funcCreateVWBarrage", nil)
          end
          if (getVehicleID(vehicle) == 476) then -- rustler
            self._warfactoryManager:createVWBomb(vehicle, source)
            self._players:getPlayers()[getClientName(source)]:setCanCreateExplosion(true)
          end
        end
        if (campaign == "recon") then
          if (getVehicleID(vehicle) == 470) then -- patriot
            triggerClientEvent(source, "funcCreateVWReconFlare", source, "funcCreateVWReconFlare", nil)
          end
          if (getVehicleID(vehicle) == 476) then -- rustler
            self._warfactoryManager:createVWReconASFlare(vehicle, source)
          end
        end
        ammo = ammo - 1
        setElementData(vehicle, "ammo", ammo)
        self._funcUpdateReloadPos(vehicle)
        -- make player icon visible
        self._blipManager:setBlipVisibleToAll(self._players:getPlayers()[getClientName(source)], false)
        setTimer(self._funcNoRadarBlip, 5000, 1, source)
        return true
      elseif (ammo <= 0) then
        playSoundFrontEnd(source, 42)
      end
    end
  end
  return false
end

function ObjVehicleWeapons:resetAmmo(vehicle)
  local ammo = getElementData(vehicle, "ammo")
  local campaign = getElementData(vehicle, "type")
  if (ammo ~= false and tonumber(ammo) ~= nil and campaign ~= "ranger") then
    ammo = tonumber(ammo)
    if (ammo <= 0) then
      setElementData(vehicle, "ammo", self._warfactoryManager:getAmmoByVehicle(vehicle))
      self._warfactoryManager:updateAttachments(vehicle, campaign)
      playSoundFrontEnd(getVehicleController(vehicle), 46)
      triggerClientEvent(getVehicleController(vehicle), "funcToggleVWBar", getVehicleController(vehicle), "funcToggleVWBar", nil)
      return true
    end
  end
  return false
end

function ObjVehicleWeapons:createFlareArea(player, posX, posY)
  local teamName = ""
  if (getPlayerTeam(player:getSource()) ~= false) then
    self._funcDestroyFlare(player:getName(), false)
    self._flareAreas[player:getName()] = ObjColshape.create():createTube(0, 0, -100, 0, 200.0, 1000, 20000)
    setElementPosition(self._flareAreas[player:getName()], tonumber(posX), tonumber(posY), -100)
    setElementData(self._flareAreas[player:getName()], "team", getTeamName(getPlayerTeam(player:getSource())))
    setElementData(self._flareAreas[player:getName()], "creator", player:getName())
    setTimer(self._funcDestroyFlare, 15000, 1, player:getName(), true)
  end
end

function ObjVehicleWeapons:createExplosion(player, posX, posY, posZ)
  createExplosion(posX, posY, posZ, 10, player:getSource())
  self._players:getPlayers()[getClientName(player:getSource())]:setCanCreateExplosion(false)
end

-- Author: Ace_Gambit