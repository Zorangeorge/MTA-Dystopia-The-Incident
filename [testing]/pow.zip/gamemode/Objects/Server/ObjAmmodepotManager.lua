-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjAmmodepotManager = {}
ObjAmmodepotManager.__index = ObjAmmodepotManager

function ObjAmmodepotManager.create()
  local _objAmmodepotManager = {}
  setmetatable(_objAmmodepotManager, ObjAmmodepotManager)
  _objAmmodepotManager._root = nil
  _objAmmodepotManager._data = nil
  _objAmmodepotManager._players = {}
  _objAmmodepotManager._ammodepotSpots = {}
  _objAmmodepotManager._blips = {}
  return _objAmmodepotManager
end

-- init ammo depot manager
function ObjAmmodepotManager:init(data, root, players)
  local color = nil
  self._root = root
  self._data = data
  self._players = players
  for k, v in pairs(self._data) do
    color = split(v["color"], string.byte(' '))
    self._ammodepotSpots[v["id"]] = {v["team"], ObjColshape.create():createSphere(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 1.480003585815, tonumber(v["radius"]), k)}
    setElementData(self._ammodepotSpots[v["id"]][2], "closed", v["closed"])
    self._blips[v["id"]] = createBlip(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 0, 2.0, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]))
    setElementVisibleTo(self._blips[v["id"]], self._root, false)
  end
end

function ObjAmmodepotManager:updateRadar()
  local tmpTeam = false
  local tmpVehicle = false
  local tmpAmmo = false
  local tmpCampaign = false
  for k, v in pairs(self._ammodepotSpots) do
    setElementVisibleTo(self._blips[k], self._root, false)
    for kc, vc in pairs(self._players) do
      tmpTeam = getPlayerTeam(vc:getSource())
      tmpVehicle = getPlayerOccupiedVehicle(vc:getSource())
      if (tmpTeam ~= false and tmpVehicle ~= false) then
        tmpAmmo = getElementData(tmpVehicle, "ammo")
        tmpCampaign = getElementData(tmpVehicle, "type")
        if (vc:getSource() == getVehicleController(tmpVehicle) and tmpAmmo ~= false and tmpCampaign ~= false) then
          setElementVisibleTo(self._blips[k], vc:getSource(), (getTeamName(tmpTeam) == v[1] and tonumber(tmpAmmo) <= 0 and tmpCampaign ~= "ranger"))
        else
          setElementVisibleTo(self._blips[k], vc:getSource(), false)
        end
      else
        setElementVisibleTo(self._blips[k], vc:getSource(), false)
      end
    end
  end
end

function ObjAmmodepotManager:getTeamByID(id)
  return self._ammodepotSpots[id .. ""][1]
end

function ObjAmmodepotManager:isVehicleAllowed(player, id)
  if (isPlayerInVehicle(player)) then
    return (self:getTeamByID(id) == getElementData(getPlayerOccupiedVehicle(player), "team"))
  end
  return false
end

-- Author: Ace_Gambit