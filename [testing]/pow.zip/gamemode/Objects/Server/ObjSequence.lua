-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSequence = {}
ObjSequence.__index = ObjSequence

function ObjSequence.create(id)
  local _objSequence = {}
  setmetatable(_objSequence, ObjSequence)
  _objSequence._objectID = id
  _objSequence._object = nil
  _objSequence._sequences = {}
  _objSequence._sequence = 1
  _objSequence._maxSequence = 1
  _objSequence._oldTick = 0
  return _objSequence
end

-- init object sequence
function ObjSequence:init(sequences)
  self._object = getElementByID(self._objectID)
  for k, v in ipairs(sequences) do
    table.insert(self._sequences, {tonumber(v[1]), tonumber(v[2]), tonumber(v[3]), tonumber(v[4]), tonumber(v[5]), tonumber(v[6]), tonumber(v[7])})
    self._maxSequence = self._maxSequence + 1
  end
  self._maxSequence = self._maxSequence - 1
end

function ObjSequence:getObjectID()
  return self._objectID
end

function ObjSequence:getTime()
  return self._sequences[self._sequence][1]
end

function ObjSequence:getTargetX()
  return self._sequences[self._sequence][2]
end

function ObjSequence:getTargetY()
  return self._sequences[self._sequence][3]
end

function ObjSequence:getTargetZ()
  return self._sequences[self._sequence][4]
end

function ObjSequence:getMoverX()
  return self._sequences[self._sequence][5]
end

function ObjSequence:getMoverY()
  return self._sequences[self._sequence][6]
end

function ObjSequence:getMoverZ()
  return self._sequences[self._sequence][7]
end

function ObjSequence:getObject()
  return self._object
end

function ObjSequence:setSequence(value)
  self._sequence = value
end

function ObjSequence:getSequence()
  return self._sequence
end

function ObjSequence:getMaxSequence()
  return self._maxSequence
end

function ObjSequence:setOldTick(value)
  self._oldTick = value
end

function ObjSequence:getOldTick()
  return self._oldTick
end

-- Author: Ace_Gambit