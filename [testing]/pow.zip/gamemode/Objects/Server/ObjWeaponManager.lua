-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjWeaponManager = {}
ObjWeaponManager.__index = ObjWeaponManager

function ObjWeaponManager.create()
  local _objWeaponManager = {}
  setmetatable(_objWeaponManager, ObjWeaponManager)
  _objWeaponManager._data = nil
  return _objWeaponManager
end

-- init weapon manager
function ObjWeaponManager:init(data)
  self._data = data
end

function ObjWeaponManager:setSquadweapons(player, team, role)
  local id = nil
  local ammo = nil
  local current = nil
  if (player:getChangeWeapons()) then
    for k, v in ipairs(self._data[team][role]) do
      id = tonumber(self._data[team][role][k]["id"])
      ammo = tonumber(self._data[team][role][k]["ammo"])
      current = (tonumber(self._data[team][role][k]["current"]) == 1)
      giveWeapon(player:getSource(), id, ammo, current)
    end
  end
end

-- Author: Ace_Gambit