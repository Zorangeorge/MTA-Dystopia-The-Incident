-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjVehicleManager = {}
ObjVehicleManager.__index = ObjVehicleManager

function ObjVehicleManager.create()
  local _objVehicleManager = {}
  setmetatable(_objVehicleManager, ObjVehicleManager)
  _objVehicleManager._data = nil
  _objVehicleManager._refuelManager = nil
  _objVehicleManager._repairManager = nil
  _objVehicleManager._timerUtils = nil
  _objVehicleManager._blipManager = nil
  return _objVehicleManager
end

-- init vehicle manager
function ObjVehicleManager:init(data, refuelManager, repairManager, timerUtils, blipManager)
  local vehicle = false
  self._data = data
  self._refuelManager = refuelManager
  self._repairManager = repairManager
  self._timerUtils = timerUtils
  self._blipManager = blipManager
  for k, v in pairs(self._data) do
    vehicle = getElementByID(v["id"])
    self:setData(vehicle, v)
  end
end

function ObjVehicleManager:setData(vehicle, node)
  if (vehicle ~= false) then
    toggleVehicleRespawn(vehicle, (node["respawn"] == "true"))
    setVehicleIdleRespawnDelay(vehicle, tonumber(node["idle"]))
    setVehicleRespawnDelay(vehicle, tonumber(node["spawn"]))
    setVehicleRespawnPosition(vehicle, tonumber(node["posX"]), tonumber(node["posY"]), tonumber(node["posZ"]), tonumber(node["rotX"]), tonumber(node["rotY"]), tonumber(node["rotZ"]))
    setElementData(vehicle, "max-fuel", node["fuel"])
    setElementData(vehicle, "locked-fuel", "false")
    setElementData(vehicle, "locked-repair", "false")
    setElementData(vehicle, "reload-pos", 200) -- does not apply to ranger campaign
  end
end

function ObjVehicleManager:resetData(vehicle)
  local id = getElementData(vehicle, "id")
  if (id ~= false) then
    self:setData(vehicle, self._data[id])
  end
end

function ObjVehicleManager:Process(request, vehicle, player, seat, ...)
  local tmpTeamName = getElementData(vehicle, "team")
  if (request == "funcVehicleEnter") then
    if (tmpTeamName ~= false) then
      if (tmpTeamName ~= getTeamName(getPlayerTeam(player:getSource()))) then
        self._blipManager:setBlipVisibleToAll(player, false)
      else
        self._blipManager:setBlipVisibleToAll(player, true)
      end
    end
    -- was player jacked?
    if (arg[1] ~= nil and arg[1] ~= false) then
      triggerClientEvent(arg[1], "funcVehicleNoHud", arg[1], "funcVehicleNoHud", nil)
    end
    if (player:getGameState() == "STCampaignSelection") then
      warpPlayerIntoVehicle(player:getSource(), vehicle, seat)
    end
  end
  if (request == "funcVehicleStartExit") then
    self._blipManager:setBlipVisibleToAll(player, true)
  end
end

function ObjVehicleManager:updateFuel(vehicle)
  local fuel = false
  local id = getElementData(vehicle, "id")
  local maxFuel = getElementData(vehicle, "max-fuel")
  local closed = true
  local speed = 4.0
  local vX, vY, vZ = 0, 0, 0
  if (vehicle ~= nil and vehicle ~= false and id ~= false and maxFuel ~= false) then
    fuel = getElementData(vehicle, "fuel")
    if (fuel ~= false) then
      fuel = tonumber(fuel)
      maxFuel = tonumber(maxFuel)
      if (fuel > 0 and fuel <= maxFuel) then
        closed = self._refuelManager:getSpotClosedByID(tonumber(id) + 3000)
        if (not closed and self:getLockedFuel(vehicle)) then
          fuel = self._refuelManager:getRefuel(fuel, maxFuel, speed)
        elseif (not self:getLockedFuel(vehicle)) then
          vX, vY, vZ = getElementVelocity(vehicle)
          if (vX ~= 0 or vY ~= 0 or vZ ~= 0) then
            fuel = fuel - 1
          end
        end
        setElementData(vehicle, "fuel", fuel)
        -- lower fuel threshold...
        if (((fuel / maxFuel) * 100) <= 75) then
          self._refuelManager:triggerSpotByID(tonumber(id) + 3000, true)
        -- upper fuel threshold...
        elseif ((((fuel / maxFuel) * 100) + (speed * 2)) >= 100) then
          self._refuelManager:triggerSpotByID(tonumber(id) + 3000, false)
        end
      elseif (fuel <= 0) then
        setElementData(vehicle, "fuel", 0)
        setVehicleEngineState(vehicle, false)
        self._timerUtils:killTimerByID("TVehicleFuel" .. id)
      end
      return id
    end
  end
  return 0
end

function ObjVehicleManager:updateDamage(vehicle)
  local health = getElementHealth(vehicle) - 250
  local id = getElementData(vehicle, "id")
  local speed = 2.0
  if (vehicle ~= false and health ~= false and id ~= false) then
    -- lower damage threshold...
    if (((health / (1000 - 250)) * 100) <= 75 and not self:getNeedRepair(vehicle)) then
      self:setNeedRepair(vehicle, true)
    -- upper fuel threshold...
    elseif ((((health / (1000 - 250)) * 100) + (speed * 2)) >= 100) then
      self:setNeedRepair(vehicle, false)
      fixVehicle(vehicle)
    end
    if (self:getNeedRepair(vehicle)) then
      health = self._repairManager:getRepair(health, (1000 - 250), speed)
      setElementHealth(vehicle, health + 250)
      return id
    end
  end
  return 0
end

function ObjVehicleManager:getNeedRepair(vehicle)
  return (getElementData(vehicle, "repair") == "yes")
end

function ObjVehicleManager:setNeedRepair(vehicle, repair)
  if (repair) then
    setElementData(vehicle, "repair", "yes")
  else
    setElementData(vehicle, "repair", "no")
  end
end

function ObjVehicleManager:getFuel(vehicle)
  if (vehicle ~= nil and vehicle ~= false) then
    return tonumber(getElementData(vehicle, "fuel"))
  else
    return 0
  end
end

function ObjVehicleManager:getLockedFuel(vehicle)
  return (getElementData(vehicle, "locked-fuel") == "true")
end

function ObjVehicleManager:setLockedFuel(vehicle, locked)
  if (locked) then
    setElementData(vehicle, "locked-fuel", "true")
  else
    setElementData(vehicle, "locked-fuel", "false")
  end
end

function ObjVehicleManager:getLockedRepair(vehicle)
  return (getElementData(vehicle, "locked-repair") == "true")
end

function ObjVehicleManager:setLockedRepair(vehicle, locked)
  if (locked) then
    setElementData(vehicle, "locked-repair", "true")
  else
    setElementData(vehicle, "locked-repair", "false")
  end
end

function ObjVehicleManager:warpVehicleToSpawn(vehicle, lock)
  local id = getElementData(vehicle, "id")
  local posX, posY, posZ = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  if (id ~= false) then
    posX = tonumber(self._data[id]["posX"])
    posY = tonumber(self._data[id]["posY"])
    posZ = tonumber(self._data[id]["posZ"])
    rotX = tonumber(self._data[id]["rotX"])
    rotY = tonumber(self._data[id]["rotY"])
    rotZ = tonumber(self._data[id]["rotZ"])
    setElementPosition(vehicle, posX, posY, posZ)
    setVehicleRotation(vehicle, rotX, rotY, rotZ)
    setElementVelocity(vehicle, 0, 0, 0)
    if (lock) then
      setVehicleFrozen(vehicle, true)
    end
  end
end

function ObjVehicleManager:warpVehicleToPosition(vehicle, x, y, z, lock)
  local id = getElementData(vehicle, "id")
  if (id ~= false) then
    setElementPosition(vehicle, x, y, z)
    setVehicleRotation(vehicle, 0, 0, 0)
    setElementVelocity(vehicle, 0, 0, 0)
    setVehicleFrozen(vehicle, lock)
  end
end

function ObjVehicleManager:unfreezeVehicle(vehicle)
  setVehicleFrozen(vehicle, false)
end

function ObjVehicleManager:isPlayerController(player)
  if (player ~= false) then
    return (getPlayerOccupiedVehicleSeat(player) == 0)
  end
  return false
end

function ObjVehicleManager:toggleAllControlsForPassengers(player, toggle)
  local vehicle = getPlayerOccupiedVehicle(player)
  for i = 0, getVehicleMaxPassengers(vehicle) do
    if (getVehicleOccupant(vehicle, i) ~= false) then
      toggleAllControls(getVehicleOccupant(vehicle, i), toggle)
    end
  end
end

function ObjVehicleManager:triggerRefuel(source)
  triggerClientEvent(source, "funcRefuel", source, "funcRefuel", nil)
end

function ObjVehicleManager:triggerRepair(source)
  triggerClientEvent(source, "funcRepair", source, "funcRepair", nil)
end

-- Author: Ace_Gambit