-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjRefuelManager = {}
ObjRefuelManager.__index = ObjRefuelManager

function ObjRefuelManager.create()
  local _objRefuelManager = {}
  setmetatable(_objRefuelManager, ObjRefuelManager)
  _objRefuelManager._data = nil
  _objRefuelManager._refuelSpots = {}
  return _objRefuelManager
end

-- init refuel manager
function ObjRefuelManager:init(data)
  self._data = data
  for k, v in pairs(self._data) do
    self._refuelSpots[v["id"]] = ObjColshape.create():createTube(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 1.480003585815, tonumber(v["radius"]), tonumber(v["radius"]) * 3.0, k)
    setElementData(self._refuelSpots[v["id"]], "closed", v["closed"])
  end
end

function ObjRefuelManager:triggerSpotByID(id, acceptVehicles)
  local closed = (getElementData(self._refuelSpots[id .. ""], "closed") == "true")
  if (acceptVehicles and closed) then
    setElementData(self._refuelSpots[id .. ""], "closed", "false")
  elseif (not acceptVehicles and not closed) then
    setElementData(self._refuelSpots[id .. ""], "closed", "true")
  end
end

function ObjRefuelManager:getSpotClosedByID(id)
  return (getElementData(self._refuelSpots[id .. ""], "closed") == "true") 
end

function ObjRefuelManager:getRefuel(fuel, maxFuel, speed)
  if ((fuel + speed) <= maxFuel) then
    return fuel + speed
  else
    return maxFuel
  end
end

-- Author: Ace_Gambit