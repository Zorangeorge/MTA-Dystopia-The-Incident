-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjTeams = {}
ObjTeams.__index = ObjTeams

function ObjTeams.create()
  local _objTeams = {}
  setmetatable(_objTeams, ObjTeams)
  _objTeams._data = nil
  _objTeams._players = nil
  _objTeams._max = 16 -- NOTE: this is a hard coded value
  _objTeams._teams = {}
  _objTeams._squads = {
      ["Allies"] = {
      ["alpha"] = 0,
      ["bravo"] = 0,
      ["charlie"] = 0,
      ["delta"] = 0
                  },
      ["Axis"] = {
      ["alpha"] = 0,
      ["bravo"] = 0,
      ["charlie"] = 0,
      ["delta"] = 0
                }
                     }
  return _objTeams
end

-- init teams
function ObjTeams:init(data, players)
  self._data = data
  self._players = players
  local color = nil
  for k, v in pairs(self._data) do
    color = split(self._data[k]["color"], string.byte(' '))
    self._teams[k] = createTeam(k, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]))
    setElementData(self._teams[k], "alias", self._data[k]["alias"])
    setElementData(self._teams[k], "max", self._max)
  end
end

function ObjTeams:getTeams()
  return self._teams
end

-- returns the amount of players in each team
function ObjTeams:getUpdateTeams()
  return {["Allies"] = countPlayersInTeam(self._teams["Allies"]), ["Axis"] = countPlayersInTeam(self._teams["Axis"])}
end

-- returns the amount of players in each squad
function ObjTeams:getUpdateSquads()
  local player = nil
  local tmpTeam = nil -- the team a player is part of
  local tmpSquad = nil -- the squad a player is part of
  for k, v in pairs(self._squads) do
    for kc, vc in pairs(self._squads[k]) do
      self._squads[k][kc] = 0
    end
  end
  for k, v in pairs(self._players:getPlayers()) do
    player = self._players:getPlayers()[k]
    tmpTeam = getPlayerTeam(player:getSource())
    -- is player part of a team?
    if (tmpTeam ~= false) then
      -- is player part of a squad?
      tmpSquad = player:getSquad()
      if (tmpSquad ~= "") then
        -- increment squad count
        self._squads[getTeamName(tmpTeam)][tmpSquad] = self._squads[getTeamName(tmpTeam)][tmpSquad] + 1
      end
    end
  end
  return self._squads
end

function ObjTeams:setPlayerTeam(player, team)
  setPlayerTeam(player:getSource(), self._teams[team])
end

function ObjTeams:setPlayerSquad(player, squad)
  player:setSquad(squad)
end

function ObjTeams:unsetPlayer(player)
  setPlayerTeam(player:getSource(), nil)
  player:setSquad("")
end

-- Author: Ace_Gambit