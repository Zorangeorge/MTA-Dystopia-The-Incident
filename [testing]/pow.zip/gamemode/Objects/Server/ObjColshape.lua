-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjColshape = {}
ObjColshape.__index = ObjColshape

function ObjColshape.create()
  local _objColshape = {}
  setmetatable(_objColshape, ObjColshape)
  return _objColshape
end

-- init colshape
function ObjColshape:init()
  -- nah, don't need it...
end

function ObjColshape:createTube(posX, posY, posZ, offsetZ, radius, height, id)
  -- TODO: check for unique id?
  local colshape = createColTube(posX, posY, posZ - offsetZ, radius, height)
  setElementData(colshape, "id", id)
  return colshape
end

function ObjColshape:createSphere(posX, posY, posZ, offsetZ, radius, id)
  -- TODO: check for unique id?
  local colshape = createColSphere(posX, posY, posZ - offsetZ, radius)
  setElementData(colshape, "id", id)
  return colshape
end

-- Author: Ace_Gambit