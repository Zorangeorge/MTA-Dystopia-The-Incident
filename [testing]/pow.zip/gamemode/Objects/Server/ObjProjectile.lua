-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjProjectile = {}
ObjProjectile.__index = ObjProjectile

function ObjProjectile.create(id, objectID, team, maxPlayers, maxProjectiles, creatorType)
  local _objProjectile = {}
  setmetatable(_objProjectile, ObjProjectile)
  _objProjectile._id = id
  _objProjectile._objectID = objectID
  _objProjectile._team = team
  _objProjectile._maxPlayers = maxPlayers
  _objProjectile._numPlayers = 0
  _objProjectile._creatorPlayers = {}
  _objProjectile._maxProjectiles = maxProjectiles
  _objProjectile._creatorType = creatorType
  _objProjectile._colShapes = {}
  return _objProjectile
end

-- init projectile
function ObjProjectile:init()
  -- nah, don't need it...
end

function ObjProjectile:update()
  local tmpSource = getElementByID(self._objectID)
  local x, y, z = 0, 0, 0
  local cX, cY, cZ = 0, 0, 0
  local rotX, rotY, rotZ = 0, 0, 0
  if (tmpSource ~= false) then
    x, y, z = getElementPosition(tmpSource)
    rotX, rotY, rotZ = getObjectRotation(tmpSource)
    for k, v in ipairs(self._colShapes) do
      cX, cY, cZ = getElementPosition(v[1])
      x = x - math.sin(math.rad(rotZ)) * (v[2] / 2)
      y = y + math.cos(math.rad(rotZ)) * (v[2] / 2)
      setElementPosition(v[1], x, y, cZ)
    end
  end
end

function ObjProjectile:toggle()
  for k, v in ipairs(self._colShapes) do
    cX, cY, cZ = getElementPosition(v[1])
    if (cX == 0 and cY == 0) then
      setElementPosition(v[1], v[3], v[4], v[5])
    else
      setElementPosition(v[1], 0, 0, v[5])
    end
  end
end

function ObjProjectile:getTeam()
  return self._team
end

function ObjProjectile:getMaxPlayers()
  return self._maxPlayers
end

function ObjProjectile:getMaxProjectiles()
  return self._maxProjectiles
end

function ObjProjectile:getCreatorType()
  return self._creatorType
end

function ObjProjectile:getNumPlayers()
  return self._numPlayers
end

function ObjProjectile:setNumPlayers(num)
  self._numPlayers = num
end

function ObjProjectile:isCreatorPlayer(playerName)
  if (self._creatorPlayers[playerName] ~= nil) then
    return (self._creatorPlayers[playerName])
  end
  return false
end

function ObjProjectile:setCreatorPlayer(playerName)
  self._creatorPlayers[playerName] = true
end

function ObjProjectile:freeCreatorPlayer(playerName)
  self._creatorPlayers[playerName] = false
end

function ObjProjectile:freeProjectile(playerName, id)
  if (self._numPlayers > 0) then
    self._numPlayers = self._numPlayers - 1
  end
  self:freeCreatorPlayer(playerName)
end

function ObjProjectile:createColShape(x, y, z, radius, height, id)
  local colShape = ObjColshape.create():createTube(x, y, z, 1.480003585815, radius, height, id)
  table.insert(self._colShapes, {colShape, radius, x, y, z})
  return colShape
end

function ObjProjectile:createClusterArea(x, y)
  local swap = {1, -1}
  return x + (math.random(1, 20) * swap[math.random(1, 2)]), y + (math.random(1, 20) * swap[math.random(1, 2)])
end

function ObjProjectile:createTargetsByPlayer(player, maxProjectiles)
  local x, y, z = getElementPosition(player)
  local target = false
  for i = 1, maxProjectiles do
    x, y = self:createClusterArea(x, y)
    target = getElementByID("target" .. getClientName(player) .. self._id .. i)
    if (target == false or target ~= nil) then
      if (setElementID(createObject(2992, x, y, z), "target" .. getClientName(player) .. self._id .. i) == false) then
        return false
      end
    else
      setElementPosition(target, x, y, z)
    end
  end
  return true
end

-- Author: Ace_Gambit