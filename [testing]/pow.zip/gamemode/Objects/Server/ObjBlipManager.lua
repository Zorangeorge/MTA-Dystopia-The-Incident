-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjBlipManager = {}
ObjBlipManager.__index = ObjBlipManager

function ObjBlipManager.create()
  local _objBlipManager = {}
  setmetatable(_objBlipManager, ObjBlipManager)
  _objBlipManager._root = nil
  _objBlipManager._players = nil
  _objBlipManager._squadRoles = nil
  return _objBlipManager
end

-- init blip manager
function ObjBlipManager:init(root, players, squadRoles)
  self._root = root
  self._players = players
  self._squadRoles = squadRoles
end

function ObjBlipManager:setBlip(player)
  local tmpTeam = getPlayerTeam(player:getSource())
  local tmpTeamName = ""
  local tmpSquad = player:getSquad()
  local tmpRole = player:getRole()
  local color = ""
  local stealth = false
  if (tmpTeam == false or tmpSquad == "") then
    -- create idle player blip
    if (player:getShadowBlip() == nil) then
      player:setShadowBlip(createBlipAttachedTo(player:getSource(), 0, 4, 0, 0, 0, 255, 32767))
    else
      setBlipColor(player:getShadowBlip(), 0, 0, 0, 255)
    end
    if (player:getBlip() == nil) then
      player:setBlip(createBlipAttachedTo(player:getSource(), 0, 3, 249, 175, 24, 255, -32768))
    else
      setBlipColor(player:getBlip(), 249, 175, 24, 255)
    end
    setElementVisibleTo(player:getShadowBlip(), self._root, false)
    setElementVisibleTo(player:getBlip(), self._root, false)
    for k, v in pairs(self._players) do
      if (v:getSource() ~= player:getSource()) then
        setElementVisibleTo(player:getBlip(), v:getSource(), true)
      end
    end
  elseif (tmpTeam ~= false and tmpSquad ~= "") then
    -- create joined player blip
    color = split(self._squadRoles[getTeamName(tmpTeam)]["squadrole"][tmpRole]["color"], string.byte(' '))
    stealth = (self._squadRoles[getTeamName(tmpTeam)]["stealth"] == "1")
    if (player:getShadowBlip() == nil) then
      player:setShadowBlip(createBlipAttachedTo(player:getSource(), 0, 3, 0, 0, 0, 255, 32767))
    end
    if (player:getBlip() == nil) then
      player:setBlip(createBlipAttachedTo(player:getSource(), 0, 3, tonumber(colorBlip[1]), tonumber(colorBlip[2]), tonumber(colorBlip[3]), 255, -32768))
    else
      setBlipColor(player:getBlip(), tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), 255)
    end
    setElementVisibleTo(player:getShadowBlip(), self._root, false)
    setElementVisibleTo(player:getBlip(), self._root, false)
    for k, v in pairs(self._players) do
      if (v:getSource() ~= player:getSource()) then
        if (getPlayerTeam(v:getSource()) ~= false) then
          tmpTeamName = getTeamName(getPlayerTeam(v:getSource()))
        else
          tmpTeamName = ""
        end
        if ((not stealth) or (stealth and (getTeamName(tmpTeam) == tmpTeamName))) then
          -- TODO: blip ordering not working?!
          -- setElementVisibleTo(player:getShadowBlip(), v:getSource(), getPlayerTeam(v:getSource()) ~= getPlayerTeam(player:getSource()))
          setElementVisibleTo(player:getBlip(), v:getSource(), true)
        else
          -- TODO: blip ordering not working?!
          -- setElementVisibleTo(player:getShadowBlip(), v:getSource(), getPlayerTeam(v:getSource()) ~= getPlayerTeam(player:getSource()))
          setElementVisibleTo(player:getBlip(), v:getSource(), false)
        end
      end
    end
  end
end

function ObjBlipManager:setBlipVisibleToAll(player, restore)
  if (not restore) then
    setElementVisibleTo(player:getBlip(), self._root, false)
    for k, v in pairs(self._players) do
      if (v:getSource() ~= player:getSource()) then
        -- TODO: blip ordering not working?!
        -- setElementVisibleTo(player:getShadowBlip(), v:getSource(), getPlayerTeam(v:getSource()) ~= getPlayerTeam(player:getSource()))
        setElementVisibleTo(player:getBlip(), v:getSource(), true)
      end
    end
  else
    self:setBlip(player)
  end
end

-- Author: Ace_Gambit