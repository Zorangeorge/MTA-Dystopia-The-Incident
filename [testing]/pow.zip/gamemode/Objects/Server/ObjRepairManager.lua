-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjRepairManager = {}
ObjRepairManager.__index = ObjRepairManager

function ObjRepairManager.create()
  local _objRepairManager = {}
  setmetatable(_objRepairManager, ObjRepairManager)
  _objRepairManager._root = nil
  _objRepairManager._data = nil
  _objRepairManager._players = {}
  _objRepairManager._repairSpots = {}
  _objRepairManager._blips = {}
  return _objRepairManager
end

-- init repair manager
function ObjRepairManager:init(data, root, players)
  self._root = root
  self._data = data
  self._players = players
  for k, v in pairs(self._data) do
    self._repairSpots[v["id"]] = {v["team"], ObjColshape.create():createTube(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 1.480003585815, tonumber(v["radius"]), tonumber(v["radius"]) * 3.0, k)}
    setElementData(self._repairSpots[v["id"]][2], "closed", v["closed"])
    self._blips[v["id"]] = createBlip(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 63, 2)
    setElementVisibleTo(self._blips[v["id"]], self._root, false)
  end
end

function ObjRepairManager:isElementWithinColShape(source)
  for k, v in pairs(self._repairSpots) do
    if (isElementWithinColShape(source, v[2])) then
      return true
    end
  end
  return false
end

function ObjRepairManager:updateRadar()
  local tmpTeam = false
  for k, v in pairs(self._repairSpots) do
    setElementVisibleTo(self._blips[k], self._root, false)
    for kc, vc in pairs(self._players) do
      tmpTeam = getPlayerTeam(vc:getSource())
      if (tmpTeam ~= false) then
        setElementVisibleTo(self._blips[k], vc:getSource(), (getTeamName(tmpTeam) == v[1]))
      end
    end
  end
end

function ObjRepairManager:getRepair(health, maxHealth, speed)
  if ((health + speed) <= maxHealth) then
    return health + speed
  else
    return maxHealth
  end
end

function ObjRepairManager:getTeamByID(id)
  return self._repairSpots[id .. ""][1]
end

function ObjRepairManager:isVehicleAllowed(player, spotID)
  if (isPlayerInVehicle(player)) then
    return (getElementData(getPlayerOccupiedVehicle(player), "team") == self:getTeamByID(spotID))
  end
  return false
end

-- Author: Ace_Gambit