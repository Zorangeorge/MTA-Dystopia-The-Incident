-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjPlayers = {}
ObjPlayers.__index = ObjPlayers

function ObjPlayers.create()
  local _objPlayers = {}
  setmetatable(_objPlayers, ObjPlayers)
  _objPlayers._root = nil
  _objPlayers._players = {}
  return _objPlayers
end

-- init players
function ObjPlayers:init(source)
  self._root = source
end

-- add new player to the list and set default skin
function ObjPlayers:createPlayer(source, skin, x, y, z, rot)
  self._players[getClientName(source)] = ObjPlayer.create(source, skin)
  self._players[getClientName(source)]:init()
  self._players[getClientName(source)]:spawnPlayer(x, y, z, rot)
  outputChatBox("* " .. getClientName(source) .. " is pending...", self._root, 255, 100, 100)
end

-- remove player from the list
function ObjPlayers:destroyPlayer(name)
  for k, v in pairs(self._players) do
    if (string.lower(self._players[k]:getName()) == string.lower(name)) then
      self._players[k]:clean()
      self._players[k] = nil
      break
    end
  end
end

-- remove nullified players
function ObjPlayers:update()
  for k, v in pairs(self._players) do
    if (self._players[k]:getSource() == nil) then
      self._players[k]:clean()
      self._players[k] = nil
    end
  end
end

function ObjPlayers:getPlayers()
  return self._players
end

function ObjPlayers:setKills(playerName)
  local player = self._players[playerName]
  player:setKills(player:getKills() + 1)
  player:updateStats()
end

function ObjPlayers:setDeath(playerName)
  local player = self._players[playerName]
  player:setDeath(player:getDeath() + 1)
  player:updateStats()
end

function ObjPlayers:getLocation(source)
  return self._players[getClientName(source)]:getLocation()
end

function ObjPlayers:setLocation(source, location)
  self._players[getClientName(source)]:setLocation(location)
end

function ObjPlayers:isPlayerInTeam(player, teamName)
  if (getPlayerTeam(player) ~= false) then
    return (string.lower(getTeamName(getPlayerTeam(player))) == string.lower(teamName))
  end
  return false
end

-- Author: Ace_Gambit