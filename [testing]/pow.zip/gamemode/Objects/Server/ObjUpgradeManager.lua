-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjUpgradeManager = {}
ObjUpgradeManager.__index = ObjUpgradeManager

function ObjUpgradeManager.create()
  local _objUpgradeManager = {}
  setmetatable(_objUpgradeManager, ObjUpgradeManager)
  _objUpgradeManager._data = nil
  _objUpgradeManager._upgradeSpots = {}
  return _objUpgradeManager
end

-- init upgrade manager
function ObjUpgradeManager:init(data)
  self._data = data
  for k, v in ipairs(self._data["upgrades"]) do
    table.insert(self._upgradeSpots, ObjColshape.create():createTube(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 1.480003585815, tonumber(v["radius"]), 10.0, v["id"]))
  end
end

function ObjUpgradeManager:Process(id, vehicle)
  for k, v in ipairs(self._data["upgrades"]) do
    if (id == v["id"]) then
      for kc, vc in ipairs(v["list"]) do
        if (getVehicleID(vehicle) == tonumber(vc[1])) then
          addVehicleUpgrade(vehicle, tonumber(vc[2]))
        end
      end
    end
  end
end

-- Author: Ace_Gambit