-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjWarfactoryManager = {}
ObjWarfactoryManager.__index = ObjWarfactoryManager

function ObjWarfactoryManager.create()
  local _objWarfactoryManager = {}
  setmetatable(_objWarfactoryManager, ObjWarfactoryManager)
  _objWarfactoryManager._root = nil
  _objWarfactoryManager._data = nil
  _objWarfactoryManager._players = {}
  _objWarfactoryManager._vehicleManager = nil
  _objWarfactoryManager._cameraManager = nil
  _objWarfactoryManager._warfactorySpots = {}
  _objWarfactoryManager._blips = {}
  -- bombs
  _objWarfactoryManager._bombs = {}
  _objWarfactoryManager._objects = {}
  _objWarfactoryManager._funcArmVWBomb = nil
  return _objWarfactoryManager
end

-- init warfactory manager
function ObjWarfactoryManager:init(data, root, players, vehicleManager, cameraManager)
  local color = nil
  self._root = root
  self._data = data
  self._players = players
  self._vehicleManager = vehicleManager
  self._cameraManager = cameraManager
  for k, v in pairs(self._data["spots"]) do
    color = split(v["color"], string.byte(' '))
    self._warfactorySpots[v["id"]] = {v["team"], ObjColshape.create():createTube(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 1.480003585815, tonumber(v["radius"]), tonumber(v["radius"]) * 3.0, k)}
    setElementData(self._warfactorySpots[v["id"]][2], "closed", v["closed"])
    self._blips[v["id"]] = createBlip(tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), 0, 2.0, tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), tonumber(color[4]))
    setElementVisibleTo(self._blips[v["id"]], self._root, false)
  end
end

function ObjWarfactoryManager:isValidVehicle(vehicle)
  return (getVehicleID(vehicle) == 470 or getVehicleID(vehicle) == 476)
end

function ObjWarfactoryManager:getTeamByID(id)
  return self._warfactorySpots[id .. ""][1]
end

function ObjWarfactoryManager:isVehicleInSpot(player)
  local vehicle = false
  if (isPlayerInVehicle(player)) then
    vehicle = getPlayerOccupiedVehicle(player)
    for k, v in pairs(self._warfactorySpots) do
      if (isElementWithinColShape(vehicle, v[2])) then
        if (v[1] == getElementData(vehicle, "team")) then
          return true
        end
      end
    end
  end
  return false
end

function ObjWarfactoryManager:isVehicleAllowed(player, id)
  if (isPlayerInVehicle(player)) then
    return (self:getTeamByID(id) == getElementData(getPlayerOccupiedVehicle(player), "team"))
  end
  return false
end

function ObjWarfactoryManager:Process(request, vehicle, ...)
  local x, y, z = 0, 0, 0
  if (request == "funcWaitingTransfer") then
    if (not self:isValidVehicle(vehicle)) then
      setElementVelocity(vehicle, 0, 0, 0)
      self._vehicleManager:warpVehicleToSpawn(vehicle, false)
    end
  end
  if (request == "funcStartTransfer") then
    if (self:isValidVehicle(vehicle) and tonumber(getElementData(vehicle, "ammo")) <= 0) then
      self._vehicleManager:toggleAllControlsForPassengers(arg[1], false)
      setVehicleDamageProof(vehicle, true)
      setElementVelocity(vehicle, 0, 0, 0)
      x = tonumber(self._data["posX"])
      y = tonumber(self._data["posY"])
      z = tonumber(self._data["posZ"])
      self._vehicleManager:warpVehicleToPosition(vehicle, x, y, z, true)
      self._cameraManager:setMode(arg[1], "fixed")
      triggerClientEvent(arg[1], "funcCampaignSelection", arg[1], "funcCampaignSelection", nil)
    end
  end
  if (request == "funcSetAttachments") then
    if (self:isValidVehicle(vehicle)) then
      if (arg[1]:getChangeCampaign()) then
        self:updateAttachments(vehicle, arg[2])
      end
    end
  end
  if (request == "funcStartCampaign") then
    if (self:isValidVehicle(vehicle)) then
      if (arg[1]:getChangeCampaign()) then
        self._vehicleManager:warpVehicleToSpawn(vehicle, true)
        self._cameraManager:setMode(arg[1]:getSource(), "player")
        triggerClientEvent(arg[1]:getSource(), "funcStartCampaign", arg[1]:getSource(), "funcStartCampaign", nil)
        self._vehicleManager:toggleAllControlsForPassengers(arg[1]:getSource(), true)
        setTimer(setVehicleDamageProof, 2500, 1, vehicle, false)
      end
    end
  end
  if (request == "funcCancelCampaign") then
    if (self:isValidVehicle(vehicle)) then
      if (arg[1]:getChangeCampaign()) then
        setElementData(vehicle, "type", "ranger")
        setElementData(vehicle, "ammo", 0)
        setElementData(vehicle, "turret-rot", 0)
        self:destroyAttachments(vehicle)
        self:Process("funcStartCampaign", vehicle, arg[1])
      end
    end
  end
  if (request == "funcUnfreezeTransfer") then
    if (self:isValidVehicle(vehicle)) then
      self._vehicleManager:unfreezeVehicle(vehicle)
    end
  end
end

function ObjWarfactoryManager:updateRadar()
  local tmpTeam = false
  for k, v in pairs(self._warfactorySpots) do
    setElementVisibleTo(self._blips[k], self._root, false)
    for kc, vc in pairs(self._players) do
      tmpTeam = getPlayerTeam(vc:getSource())
      if (tmpTeam ~= false) then
        setElementVisibleTo(self._blips[k], vc:getSource(), (getTeamName(tmpTeam) == v[1]))
      end
    end
  end
end

function ObjWarfactoryManager:getAmmoByVehicle(vehicle)
  local campaign = getElementData(vehicle, "type")
  local ammo = 0
  if (campaign ~= false) then
    if (campaign == "assault") then
      if (getVehicleID(vehicle) == 470) then -- patriot
        ammo = 4
      end
      if (getVehicleID(vehicle) == 476) then -- rustler
        ammo = 1
      end
    elseif (campaign == "recon") then
      if (getVehicleID(vehicle) == 470) then -- patriot
        ammo = 8
      end
      if (getVehicleID(vehicle) == 476) then -- rustler
        ammo = 4
      end
    end
  end
  return ammo
end

function ObjWarfactoryManager:updateAttachments(vehicle, campaign)
  -- detach
  for k, v in ipairs(getAttachedElements(vehicle)) do
    detachElementFromElement(v)
    destroyElement(v)
  end
  for k, v in ipairs(self._data["attachments"]) do
    if (tonumber(v["vehicle-id"]) == getVehicleID(vehicle) and v["type"] == campaign) then
      attachElementToElement(createObject(tonumber(v["model-id"]), 0, 0, 0, 0, 0, 0), vehicle, tonumber(v["posX"]), tonumber(v["posY"]), tonumber(v["posZ"]), tonumber(v["rotX"]), tonumber(v["rotY"]), tonumber(v["rotZ"]))
    end
  end
  for k, v in ipairs(getAttachedElements(vehicle)) do
    setElementData(v, "attachment", k)
  end
  setElementData(vehicle, "type", string.lower(campaign))
  setElementData(vehicle, "ammo", self:getAmmoByVehicle(vehicle))
  setElementData(vehicle, "turret-rot", 0)
  -- NOTE: server-side object creation sometimes fails due to MTA bugs
  -- create a client-side "shadow copy" when object creation fails
  if (getVehicleController(vehicle) ~= false) then
    triggerClientEvent(getVehicleController(vehicle), "funcTestAttachments", getVehicleController(vehicle), "funcTestAttachments", nil)
  end
end

function ObjWarfactoryManager:resetAttachments(vehicle)
  local campaign = getElementData(vehicle, "type")
  if (campaign ~= false) then
    self:updateAttachments(vehicle, campaign)
  end
end

function ObjWarfactoryManager:destroyAttachments(vehicle)
  for k, v in ipairs(getAttachedElements(vehicle)) do
    detachElementFromElement(v)
    destroyElement(v)
  end
end

function ObjWarfactoryManager:createVWBomb(vehicle, source)
  -- destroy attachments
  for k, v in ipairs(getAttachedElements(vehicle)) do
    detachElementFromElement(v)
    destroyElement(v)
  end
  triggerClientEvent(source, "funcCreateVWBomb", source, "funcCreateVWBomb", nil)
end

function ObjWarfactoryManager:createVWReconASFlare(vehicle, source)
  local attachmentID = false
  -- destroy attachments
  for k, v in ipairs(getAttachedElements(vehicle)) do
    attachmentID = getElementData(v, "attachment")
    -- destroy the first attached object
    if (getElementType(v) == "object" and attachmentID ~= false) then
      detachElementFromElement(v)
      destroyElement(v)
      break
    end
  end
  if (attachmentID == false) then
    attachmentID = -1
  end
  triggerClientEvent(source, "funcCreateVWReconASFlare", source, "funcCreateVWReconASFlare", {["attachment"] = attachmentID})
end

-- Author: Ace_Gambit