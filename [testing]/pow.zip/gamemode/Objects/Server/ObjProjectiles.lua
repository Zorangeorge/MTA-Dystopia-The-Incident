-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible
-- ###########################
-- This is a note of warning concerning the projectile system. When using sam or barrage projectile
-- systems you should be aware of the fact that placing many vehicles in range of the trigger
-- areas may cause lag. I tried everything in my power to bring back the possible lag caused by
-- rapidly repeating call backs. However be advised to place a sam source ABOVE areas with
-- many vehicles and barrage sources BELOW areas that may contain fast amounts of vehicles.
-- ###########################

ObjProjectiles = {}
ObjProjectiles.__index = ObjProjectiles

function ObjProjectiles.create()
  local _objProjectiles = {}
  setmetatable(_objProjectiles, ObjProjectiles)
  _objProjectiles._data = nil
  _objProjectiles._projectiles = {}
  _objProjectiles._colShapes = {}
  _objProjectiles._tick = 0
  return _objProjectiles
end

-- init projectiles
function ObjProjectiles:init(data)
  local id = ""
  local pos = nil
  local radius = 0
  local height = 0
  local tmpColShape = nil
  self._data = data
  -- create projectiles
  for k, v in pairs(self._data["projectile"]) do
    id = self._data["projectile"][k]["id"]
    self._projectiles[id] = ObjProjectile.create(
      id,
      self._data["projectile"][k]["object-id"],
      self._data["projectile"][k]["team"],
      tonumber(self._data["projectile"][k]["max-players"]),
      tonumber(self._data["projectile"][k]["max-projectiles"]),
      self._data["projectile"][k]["creator-type"]
      )
  end
  -- create trigger colshapes
  for k, v in pairs(self._data["trigger"]) do
    id = self._data["trigger"][k]["id"]
    pos = split(self._data["trigger"][k]["pos"], string.byte(' '))
    radius = tonumber(self._data["trigger"][k]["radius"])
    height = tonumber(self._data["trigger"][k]["height"])
    tmpColShape = self._projectiles[id]:createColShape(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]), radius, height, id)
    setElementData(tmpColShape, "target-type", self._data["trigger"][k]["target-type"])
    -- DEBUG: uncomment for debug blip
    -- createBlip(tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]), 0, 2.0, 30, 112, 146, 255)
  end
end

function ObjProjectiles:update()
  for k, v in pairs(self._projectiles) do
    if (self._projectiles[k]:getCreatorType() == "sam" or -- surface-to-air missile
        self._projectiles[k]:getCreatorType() == "barrage") then -- barrage shells
      self._projectiles[k]:update()
    elseif (self._projectiles[k]:getCreatorType() == "ssm" and self._tick >= 10) then -- surface-to-surface missile
      self._projectiles[k]:toggle()
      self._tick = 0
    end
  end
  self._tick = self._tick + 1
end

function ObjProjectiles:getProjectileByID(id)
  return self._projectiles[id]
end

function ObjProjectiles:Process(source, colShape, id)
  local tmpTeam = getPlayerTeam(source)
  local tmpProjectile = self:getProjectileByID(id)
  local tmpTargetType = getElementData(colShape, "target-type")
  local tmpVehicle = nil
  if (tmpTeam ~= false and tmpTargetType ~= false) then
    -- is player from the opposite team?
    if (getTeamName(tmpTeam) ~= tmpProjectile:getTeam()) then
      -- check for airtracking
      if (tmpTargetType == "airtrack") then
        tmpVehicle = getPlayerOccupiedVehicle(source)
        if (tmpVehicle == false) then
          return
        elseif (getVehicleLandingGearDown(tmpVehicle) == nil) then
          return
        end
      end
      -- check for landtracking
      if (tmpTargetType == "landtrack") then
        tmpVehicle = getPlayerOccupiedVehicle(source)
        if (tmpVehicle ~= false) then
          if (getVehicleLandingGearDown(tmpVehicle) ~= nil) then
            return
          end
        end
      end
      if (tmpProjectile:getNumPlayers() <= tmpProjectile:getMaxPlayers() and not tmpProjectile:isCreatorPlayer(getClientName(source))) then
        tmpProjectile:setNumPlayers(tmpProjectile:getNumPlayers() + 1)
        tmpProjectile:setCreatorPlayer(getClientName(source))
        -- trigger client-side projectiles
        if (tmpProjectile:getCreatorType() ~= "ssm") then
          triggerClientEvent(source, "funcProjectile", source, "funcProjectile", {["id"] = id})
        elseif (tmpProjectile:getCreatorType() == "ssm") then -- surface-to-surface missile
          if (tmpProjectile:createTargetsByPlayer(source, tmpProjectile:getMaxProjectiles())) then
            setTimer(triggerClientEvent, 500, 1, source, "funcProjectile", source, "funcProjectile", {["id"] = id})
          end
        end
        if (tmpProjectile:getCreatorType() == "barrage" or tmpProjectile:getCreatorType() == "ssm") then
          for k, v in ipairs(getElementsByType("player")) do
            if (v ~= source) then
              -- trigger client-side explosions
              triggerClientEvent(v, "funcProjectile", v, "funcProjectile", {["id"] = id, ["flag"] = "1"})
            end
          end
        end
      end
    end
  end
end

function ObjProjectiles:freeProjectileByID(source, id)
  self:getProjectileByID(id):freeProjectile(getClientName(source))
end

-- Author: Ace_Gambit