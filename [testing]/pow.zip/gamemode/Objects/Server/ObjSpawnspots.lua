-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSpawnspots = {}
ObjSpawnspots.__index = ObjSpawnspots

function ObjSpawnspots.create()
  local _objSpawnspots = {}
  setmetatable(_objSpawnspots, ObjSpawnspots)
  _objSpawnspots._spots = {}
  return _objSpawnspots
end

-- init spawnspots
function ObjSpawnspots:init(spawnpointsData)
  local count = 1
  local posX, posY, posZ = 0, 0, 0
  for k, v in pairs(spawnpointsData) do
    for kc, vc in ipairs(spawnpointsData[k]["spawn"]) do
      posX = tonumber(vc["posX"])
      posY = tonumber(vc["posY"])
      posZ = tonumber(vc["posZ"])
      table.insert(self._spots, ObjColshape.create():createTube(posX, posY, posZ, 1.480003585815, 1.5, (1.5 * 2), count))
      count = count + 1
    end
  end
end

-- Author: Ace_Gambit