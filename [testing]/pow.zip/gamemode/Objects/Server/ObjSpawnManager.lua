-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

ObjSpawnManager = {}
ObjSpawnManager.__index = ObjSpawnManager

function ObjSpawnManager.create()
  local _objSpawnManager = {}
  setmetatable(_objSpawnManager, ObjSpawnManager)
  _objSpawnManager._data = nil
  _objSpawnManager._teams = nil
  _objSpawnManager._cameraManager = nil
  _objSpawnManager._squadRolesData = nil
  _objSpawnManager._squadWeaponManager = nil
  _objSpawnManager._players = nil
  return _objSpawnManager
end

-- init spawn manager
function ObjSpawnManager:init(data, teamBalance, cameraManager, squadRolesData, squadWeaponManager, players)
  self._data = data
  self._teams = teamBalance:getTeams()
  self._cameraManager = cameraManager
  self._squadRolesData = squadRolesData
  self._squadWeaponManager = squadWeaponManager
  self._players = players
end

-- randomly divide all players over the thirty-two spawn points
function ObjSpawnManager:spawnPlayers()
  local players = nil -- players in team
  local player = nil -- player object
  local posX = nil
  local posY = nil
  local posZ = nil
  local rot = nil  
  local tblSize = {["Allies"] = 16, ["Axis"] = 16}
  local tmpTbl = {["Allies"] = {}, ["Axis"] = {}}
  local randNum = nil
  -- create copy of spawnpoint data in temporary buffer
  for k, v in pairs(self._data) do
    for kc, vc in ipairs(self._data[k]["spawn"]) do
      tmpTbl[k][kc] = self._data[k]["spawn"][kc]
    end
  end
  -- loop teams
  for k, v in pairs(self._teams) do
    -- get all players in this team
    players = getPlayersInTeam(self._teams[k])
    -- loop players
    for kc, vc in ipairs(players) do
      player = self._players:getPlayers()[getClientName(players[kc])]
      -- does this player even exist?
      if (player ~= nil) then
        -- does this player have a squad?
        if (player:getSquad() ~= "") then
          -- get random number
          randNum = randInt(1, tblSize[k])
          posX = tonumber(tmpTbl[k][randNum]["posX"])
          posY = tonumber(tmpTbl[k][randNum]["posY"])
          posZ = tonumber(tmpTbl[k][randNum]["posZ"])
          rot = tonumber(tmpTbl[k][randNum]["rot"])
          player:spawnPlayer(posX, posY, posZ, rot)
          self._cameraManager:setMode(players[kc], "player")
          self._squadWeaponManager:setSquadweapons(player, k, player:getRole())
          player:setSkin(player:getSkin())
          player:setHealth(tonumber(self._squadRolesData[k]["squadrole"][player:getRole()]["health"]))
          player:setArmor(tonumber(self._squadRolesData[k]["squadrole"][player:getRole()]["armor"]))
          triggerClientEvent(player:getSource(), "funcSpawnPlayer", player:getSource(), "funcSpawnPlayer", {["team"] = k, ["spot"] = randNum})
          -- remove buffer element
          table.remove(tmpTbl[k], randNum)
          tblSize[k] = tblSize[k] - 1
        end
      end
    end
  end
end

-- respawn...
function ObjSpawnManager:spawnPlayer(player)
  local tmpTeam = getPlayerTeam(player:getSource())
  local teamName = nil
  local posX = nil
  local posY = nil
  local posZ = nil
  local rot = nil  
  local tblSize = {["Allies"] = 16, ["Axis"] = 16}
  local tmpTbl = {["Allies"] = {}, ["Axis"] = {}}
  local randNum = nil
  -- create copy of spawnpoint data in temporary buffer
  for k, v in pairs(self._data) do
    for kc, vc in ipairs(self._data[k]["spawn"]) do
      tmpTbl[k][kc] = self._data[k]["spawn"][kc]
    end
  end
  if (tmpTeam ~= false) then
    teamName = getTeamName(tmpTeam)
    -- is this player allowed to spawn?
    if (player:getSpawn()) then
      -- get random number
      randNum = randInt(1, tblSize[getTeamName(tmpTeam)])
      posX = tonumber(tmpTbl[teamName][randNum]["posX"])
      posY = tonumber(tmpTbl[teamName][randNum]["posY"])
      posZ = tonumber(tmpTbl[teamName][randNum]["posZ"])
      rot = tonumber(tmpTbl[teamName][randNum]["rot"])
      player:spawnPlayer(posX, posY, posZ, rot)
      self._cameraManager:setMode(player:getSource(), "player")
      self._squadWeaponManager:setSquadweapons(player, teamName, player:getRole())
      player:setSkin(player:getSkin())
      player:setHealth(tonumber(self._squadRolesData[teamName]["squadrole"][player:getRole()]["health"]))
      player:setArmor(tonumber(self._squadRolesData[teamName]["squadrole"][player:getRole()]["armor"]))
      triggerClientEvent(player:getSource(), "funcSpawnPlayer", player:getSource(), "funcSpawnPlayer", {["team"] = teamName, ["spot"] = randNum})
    end
  end
end

-- Author: Ace_Gambit