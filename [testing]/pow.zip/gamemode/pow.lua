-- server script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

local objGameMode = ObjGameMode.create()
local objGameWorld = ObjGameWorld.create()
local objSTimerUtils = ObjSTimerUtils.create()
local objPlayers = ObjPlayers.create()
local objSpawnspots = ObjSpawnspots.create()
local objCameraManager = ObjCameraManager.create()
local objWeaponManager = ObjWeaponManager.create()
local objTeamBalance = ObjTeamBalance.create()
local objSpawnManager = ObjSpawnManager.create()
local objBlipManager = ObjBlipManager.create()
local objProjectiles = ObjProjectiles.create()
local objDamageManager = ObjDamageManager.create()
local objSequenceManager = ObjSequenceManager.create()
local objRefuelManager = ObjRefuelManager.create()
local objRepairManager = ObjRepairManager.create()
local objVehicleManager = ObjVehicleManager.create()
local objWarfactoryManager = ObjWarfactoryManager.create()
local objVehicleWeapons = ObjVehicleWeapons.create()
local objAmmodepotManager = ObjAmmodepotManager.create()
local objUpgradeManager = ObjUpgradeManager.create()

-- just some variables...
local root = getRootElement()

-- internal timer
function callbackTimer(request, ...)
  local id = nil
  if (request == "funcMain") then
    objGameWorld:update()
    objSequenceManager:update()
    objProjectiles:update()
    objSTimerUtils:setTimerByID("TMain", setTimer(callbackTimer, 1000, 1, "funcMain"))
  end
  if (request == "funcVehicleFuel") then
    id = objVehicleManager:updateFuel(arg[1])
    if (objVehicleManager:getFuel(arg[1]) > 0) then
      objSTimerUtils:setTimerByID("TVehicleFuel" .. id, setTimer(callbackTimer, 50, 1, "funcVehicleFuel", arg[1]))
    elseif (objVehicleManager:getFuel(arg[1]) <= 0) then
      objVehicleManager:updateFuel(arg[1])
    end
  end
  if (request == "funcVehicleRepair") then
    id = objVehicleManager:updateDamage(arg[1])
    if (tonumber(id) > 0) then
      objSTimerUtils:setTimerByID("TVehicleRepair" .. id, setTimer(callbackTimer, 50, 1, "funcVehicleRepair", arg[1]))
    end
  end
end

-- init gamemode settings
function main(source)
  objGameMode:init(getResourceRootElement(source))
  objGameWorld:init(objGameMode:getWorldData())
  objPlayers:init(root)
  objSpawnspots:init(objGameMode:getSpawnpointsData())
  objCameraManager:init(objGameMode:getCamerasData())
  objWeaponManager:init(objGameMode:getSquadweaponsData())
  objTeamBalance:init(objGameMode:getDeathmatchData(), objGameMode:getSpawnpointsData(), objPlayers)
  objSpawnManager:init(objGameMode:getSpawnpointsData(), objTeamBalance, objCameraManager, objGameMode:getSquadrolesData(), objWeaponManager, objPlayers)
  objBlipManager:init(root, objPlayers:getPlayers(), objGameMode:getSquadrolesData())
  objProjectiles:init(objGameMode:getProjectilesData())
  objDamageManager:init(objPlayers)
  objSTimerUtils:setTimerByID("TMain", setTimer(callbackTimer, 1000, 1, "funcMain"))
  objSequenceManager:init(objGameMode:getObjectSequencesData())
  objRefuelManager:init(objGameMode:getRefuelspotsData())
  objRepairManager:init(objGameMode:getRepairspotsData(), root, objPlayers:getPlayers())
  objVehicleManager:init(objGameMode:getVehiclesData(), objRefuelManager, objRepairManager, objSTimerUtils, objBlipManager)
  objWarfactoryManager:init(objGameMode:getWarfactoriesData(), root, objPlayers:getPlayers(), objVehicleManager, objCameraManager)
  objVehicleWeapons:init(objPlayers, objWarfactoryManager, objBlipManager)
  objAmmodepotManager:init(objGameMode:getAmmodepotsData(), root, objPlayers:getPlayers())
  objUpgradeManager:init(objGameMode:getUpgradesData())
  objGameWorld:createWaterBarrier(ObjColshape.create())
end

-- callbacks
function callbackClient()
  -- client player spawned successfully
  -- DEBUG: comment the following lines for free movement
  triggerClientEvent(source, "main", source, objGameMode:getAllData())
  -- player got kicked?
  if (objPlayers:getPlayers()[getClientName(source)] == nil) then
    -- update list
    objPlayers:update()
  else
    -- ok, proceed...
    objTeamBalance:getUpdates(objPlayers:getPlayers()[getClientName(source)])
    objCameraManager:intro(source)
  end
end

function callbackFunc(request, params)
  local restore = false
  local player = nil
  if (source ~= nil) then
    player = objPlayers:getPlayers()[getClientName(source)]
  end
  if (player ~= nil or params["source"] ~= nil) then
    -- NOTE: timers are sometimes wrongly terminated!
    if (request == "funcKeepTimersAlive") then
      if (not objSTimerUtils:isRunning(objSTimerUtils:getTimerByID("TMain"))) then
        callbackTimer("funcMain", nil)
      end
      if (objVehicleManager:isPlayerController(params["source"])) then
        if (not objSTimerUtils:isRunning(objSTimerUtils:getTimerByID("TVehicleFuel" .. getElementData(getPlayerOccupiedVehicle(params["source"]), "id")))) then
          callbackTimer("funcVehicleFuel", getPlayerOccupiedVehicle(params["source"]))
        end
        if (not objSTimerUtils:isRunning(objSTimerUtils:getTimerByID("TVehicleRepair" .. getElementData(getPlayerOccupiedVehicle(params["source"]), "id")))) then
          if (objVehicleManager:getLockedRepair(getPlayerOccupiedVehicle(params["source"]))) then
            callbackTimer("funcVehicleRepair", getPlayerOccupiedVehicle(params["source"]))
          end
        end
      end
    end
    if (request == "funcVehicleKillTimers") then
      objSTimerUtils:killTimerByID("TVehicleFuel" .. params["id"])
      objSTimerUtils:killTimerByID("TVehicleRepair" .. params["id"])
      if (params["source"] ~= nil) then
        callbackFunc("funcKeepTimersAlive", {["source"] = params["source"]})
      end
    end
    if (request == "funcSwitchWeapons") then
      objWeaponManager:setSquadweapons(player, params["team"], params["squadrole"])
    end
    if (request == "funcSetPlayerTeam") then
      objTeamBalance:setPlayerTeam(player, params["team"], params["squadrole"])
      objRepairManager:updateRadar()
      objWarfactoryManager:updateRadar()
      objAmmodepotManager:updateRadar()
    end
    if (request == "funcSetPlayerSquad") then
      -- request spawn after squad selection
      objTeamBalance:setPlayerSquad(player, params["squad"])
      objSpawnManager:spawnPlayer(player)
    end
    if (request == "funcUnsetPlayer") then
      objTeamBalance:unsetPlayer(player)
    end
    if (request == "funcSpawnPlayer") then
      if (player:getSpawn()) then
        restore = (objCameraManager:getMode(source) == "fixed")
        objCameraManager:setMode(source, "player")
        player:spawnPlayer(params["posX"], params["posY"], params["posZ"], params["rot"])
        if (restore) then
          objCameraManager:setMode(source, "fixed")
        end
      end
    end
    if (request == "funcSetPlayerSkin") then
      player:setSkin(params["skin"])
    end
    if (request == "funcAttachBlip") then
      objBlipManager:setBlip(player)
    end
    if (request == "funcKillPlayer") then
      killPlayer(source)
    end
    if (request == "funcRespawnPlayer") then
      objAmmodepotManager:updateRadar()
      objSpawnManager:spawnPlayer(player)
    end
    if (request == "funcRespawnPending") then
      objDamageManager:Process("funcRespawnPending", params["source"], nil, objCameraManager)
    end
    if (player ~= nil) then
      if (objWarfactoryManager:isVehicleInSpot(player:getSource())) then
        if (request == "funcStartTransfer") then
          if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
            objWarfactoryManager:Process("funcStartTransfer", getPlayerOccupiedVehicle(player:getSource()), player:getSource())
          end
        end
      end
      if (player:getGameState() == "STCampaignSelection") then
        if (request == "funcSetAttachments") then
          if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
            objWarfactoryManager:Process("funcSetAttachments", getPlayerOccupiedVehicle(player:getSource()), player, params["campaign"])
          end
        end
        if (request == "funcStartCampaign") then
          if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
            objWarfactoryManager:Process("funcStartCampaign", getPlayerOccupiedVehicle(player:getSource()), player)
          end
        end
        if (request == "funcCancelCampaign") then
          if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
            objWarfactoryManager:Process("funcCancelCampaign", getPlayerOccupiedVehicle(player:getSource()), player)
            objAmmodepotManager:updateRadar()
          end
        end
      end
    end
    if (request == "funcUnfreezeTransfer") then
      if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
        objWarfactoryManager:Process("funcUnfreezeTransfer", getPlayerOccupiedVehicle(player:getSource()))
      end
    end
    if (request == "funcTriggerFlareArea") then
      if (objVehicleManager:isPlayerController(player:getSource()) ~= false) then
        objVehicleWeapons:createFlareArea(player, params["posX"], params["posY"])
      end
    end
    if (request == "funcCreateExplosion") then
      if (objVehicleManager:isPlayerController(player:getSource()) ~= false and player:getCanCreateExplosion()) then
        objVehicleWeapons:createExplosion(player, params["posX"], params["posY"], params["posZ"])
      end
    end
    if (request == "funcFreeProjectile") then
      objProjectiles:freeProjectileByID(player:getSource(), params["id"])
    end
  end
end

function callbackHit(theColShape, matchingDimension)
  local id = getElementData(theColShape, "id")
  local triggerType = false
  if (getElementType(source) == "vehicle" and getVehicleController(source) == false) then
    cancelEvent()
    return
  end
  if (getElementType(source) == "player") then
    objProjectiles:Process(source, theColShape, id)
    if (tonumber(id) ~= nil and getClientName(source) ~= nil) then
      if (tonumber(id) <= 100) then
        objPlayers:getPlayers()[getClientName(source)]:setProtected("1")
      end
    end
    if (id == "10000" and objPlayers:getPlayers()[getClientName(source)]:getGameState() == "STRoundStarted") then
      objGameWorld:Process("funcWaterBarrierHit", source)
    end
  end
  if (tonumber(id) ~= nil) then
    if (tonumber(id) >= 2000 and tonumber(id) <= 3000) then
      triggerType = getElementData(theColShape, "type")
      if (triggerType ~= false and (triggerType == getElementType(source))) then
        objSequenceManager:triggerByID(id)
      end
    end
    if (tonumber(id) >= 3001 and tonumber(id) <= 3499) then
      if (not objRefuelManager:getSpotClosedByID(id)) then
        if (getElementType(source) == "player") then
          if (objVehicleManager:isPlayerController(source) ~= false) then
            if (not objSTimerUtils:isRunning(objSTimerUtils:getTimerByID("TVehicleFuel" .. getElementData(getPlayerOccupiedVehicle(source), "id")))) then
              callbackTimer("funcVehicleRepair", getPlayerOccupiedVehicle(source))
            end
            if (tonumber(id) == (tonumber(getElementData(getPlayerOccupiedVehicle(source), "id")) + 3000)) then
              objVehicleManager:setLockedFuel(getPlayerOccupiedVehicle(source), true)
              objVehicleManager:triggerRefuel(source)
              setVehicleDamageProof(getPlayerOccupiedVehicle(source), true)
              setVehicleLocked(getPlayerOccupiedVehicle(source), true)
            end
          end
        end
      end
    end
    if (tonumber(id) >= 3500 and tonumber(id) <= 3999) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source) ~= false and objRepairManager:isVehicleAllowed(source, id)) then
          objVehicleManager:setLockedRepair(getPlayerOccupiedVehicle(source), true)
          callbackTimer("funcVehicleRepair", getPlayerOccupiedVehicle(source))
          setVehicleDamageProof(getPlayerOccupiedVehicle(source), true)
          setVehicleLocked(getPlayerOccupiedVehicle(source), true)
          if (objVehicleManager:getNeedRepair(getPlayerOccupiedVehicle(source))) then
            objVehicleManager:triggerRepair(source)
          end
        end
      end
    end
    if (tonumber(id) >= 4000 and tonumber(id) <= 4100) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source) ~= false and objWarfactoryManager:isVehicleAllowed(source, id)) then
          objWarfactoryManager:Process("funcWaitingTransfer", getPlayerOccupiedVehicle(source))
          setVehicleLocked(getPlayerOccupiedVehicle(source), true)
        end
      end
    end
    if (tonumber(id) >= 4101 and tonumber(id) <= 4199) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source) ~= false and objAmmodepotManager:isVehicleAllowed(source, id) and
              objWarfactoryManager:isValidVehicle(getPlayerOccupiedVehicle(source))) then
          if (objVehicleWeapons:resetAmmo(getPlayerOccupiedVehicle(source))) then
            objAmmodepotManager:updateRadar()
          end
        end
      end
    end
    if (tonumber(id) >= 4200 and tonumber(id) <= 4300) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source)) then
          objUpgradeManager:Process(id, getPlayerOccupiedVehicle(source))
        end
      end
    end
    -- flare areas
    if (tonumber(id) == 20000) then
      if (getElementType(source) == "player") then
        if (getElementData(theColShape, "team") ~= false) then
          if (not objPlayers:isPlayerInTeam(source, getElementData(theColShape, "team"))) then
            objBlipManager:setBlipVisibleToAll(objPlayers:getPlayers()[getClientName(source)], false)
          end
        end
      end
    end
  end
end

function callbackLeave(theColShape, matchingDimension)
  local id = getElementData(theColShape, "id")
  if (getElementType(source) == "vehicle" and getVehicleController(source) == false) then
    cancelEvent()
    return
  end
  if (getElementType(source) == "player") then
    if (tonumber(id) ~= nil and getClientName(source) ~= nil) then
      if (tonumber(id) <= 100) then
        objPlayers:getPlayers()[getClientName(source)]:setProtected("0")
      end
    end
    if (id == "10000" and objPlayers:getPlayers()[getClientName(source)]:getGameState() == "STRoundStarted") then
      objGameWorld:Process("funcWaterBarrierLeave", source)
    end
  end
  if (tonumber(id) ~= nil) then
    if (tonumber(id) >= 3001 and tonumber(id) <= 3499) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source) ~= false) then
          objVehicleManager:setLockedFuel(getPlayerOccupiedVehicle(source), false)
          setVehicleDamageProof(getPlayerOccupiedVehicle(source), false)
          setVehicleLocked(getPlayerOccupiedVehicle(source), false)
        end
      end
    end
    if (tonumber(id) >= 3500 and tonumber(id) <= 3999) then
      if (getElementType(source) == "vehicle") then
        if (getElementData(source, "id") ~= false and objVehicleManager:isPlayerController(getVehicleController(source)) ~= false) then
          objVehicleManager:setLockedRepair(source, false)
          objSTimerUtils:killTimerByID("TVehicleRepair" .. getElementData(source, "id"))
          setVehicleDamageProof(source, false)
          setVehicleLocked(source, false)
          callbackFunc("funcKeepTimersAlive", {["source"] = getVehicleController(source)})
        end
      end
    end
    if (tonumber(id) >= 4000 and tonumber(id) <= 4100) then
      if (getElementType(source) == "player") then
        if (objVehicleManager:isPlayerController(source) ~= false) then
          setVehicleLocked(getPlayerOccupiedVehicle(source), false)
        end
      end
    end
    -- flare areas
    if (tonumber(id) == 20000) then
      if (getElementType(source) == "player") then
        objBlipManager:setBlipVisibleToAll(objPlayers:getPlayers()[getClientName(source)], true)
      end
    end
  end
end

function callbackVehicleEnter(player, seat, jacked)
  local controller = false
  if (player ~= nil and player ~= false) then
    controller = player
  end
  if (controller ~= false) then
    if (seat == 0) then
      callbackTimer("funcVehicleFuel", source)
    end
  end
  setVehicleFrozen(source, false)
  if (objRepairManager:isElementWithinColShape(source) and seat == 0) then
    callbackTimer("funcVehicleRepair", source)
  end
  setPlayerWeaponSlot(controller, 0)
  objVehicleManager:Process("funcVehicleEnter", source, objPlayers:getPlayers()[getClientName(player)], seat, jacked)
  objAmmodepotManager:updateRadar()
end

function callbackVehicleStartExit(exitingPlayer, seat, jacker)
  local id = getElementData(source, "id")
  if (id ~= false and seat == 0) then
    callbackFunc("funcVehicleKillTimers", {["source"] = getVehicleController(source), ["id"] = id})
  end
  objVehicleManager:Process("funcVehicleStartExit", source, objPlayers:getPlayers()[getClientName(exitingPlayer)], seat, jacker)
  setVehicleLocked(source, false)
end

function callbackVehicleExit(player, seat, jacker)
  objAmmodepotManager:updateRadar()
end

function callbackVehicleExplode()
  local id = getElementData(source, "id")
  local occupant = false
  if (id ~= false) then
    objWarfactoryManager:destroyAttachments(source)
    for i = 0, getVehicleMaxPassengers(source) do
      occupant = getVehicleOccupant(source, i)
      if (occupant ~= false) then
        removePlayerFromVehicle(occupant)
      end
    end
    callbackFunc("funcVehicleKillTimers", {["source"] = nil, ["id"] = id})
  end
end

function callbackVehicleRespawn(exploded)
  objVehicleManager:resetData(source)
  objWarfactoryManager:resetAttachments(source)
end

-- key controls
function keyFunc(source, key, keyState)
  local x, y, z = 0, 0, 0
  if (objVehicleManager:isPlayerController(source) ~= false) then
    if (key == "lshift") then
      if (objVehicleWeapons:Process(source)) then
        objAmmodepotManager:updateRadar()
      end
    end
  end
  if (key == "F6") then
    objSpawnManager:spawnPlayers()
  end
  if (key == "F7") then
    x, y, z = getElementPosition(source)
    outputDebugString("* Player X: " .. x)
    outputDebugString("* Player Y: " .. y)
    outputDebugString("* Player Z: " .. z)
  end
end

-- does exactly like the function says...
function createPlayer()
  -- notify we have contact...
  outputChatBox(objGameMode:getMetaData()["name"] .. " by " .. objGameMode:getMetaData()["author"], source, 249, 175, 24)
  outputChatBox(objGameMode:getMetaData()["description"], source, 249, 175, 24)
  outputChatBox("Version " .. objGameMode:getMetaData()["version"], source, 249, 175, 24)
  -- DEBUG: uncomment the following line for free movement
  -- fadeCamera(source, true)
  -- create and spawn idle player
  if (source ~= nil) then
    objPlayers:createPlayer(source, tonumber(objGameMode:getSpawnpointsData()["Allies"]["skin"]), 0, 0, 4.0, 0)
  end
  -- wait for client response...
  bindKey(source, "lshift", "down", keyFunc)
  bindKey(source, "F6", "down", keyFunc)
  bindKey(source, "F7", "down", keyFunc)
end

-- doh...
function destroyPlayer()
  if (objPlayers:getPlayers()[getClientName(source)]:getGameState() == "STCampaignSelection") then
    if (objVehicleManager:isPlayerController(source)) then
      -- quick and dirty solution...
      blowVehicle(getPlayerOccupiedVehicle(source), true)
    end
  end
  objCameraManager:setMode(source, "player")
  -- make sure the player object is destroyed as well
  objPlayers:destroyPlayer(getClientName(source))
end

-- player damage control
function playerDamage(attacker, attackerweapon, bodypart, loss)
  objDamageManager:Process("funcPlayerDamage", source, attacker, attackerweapon, bodypart, loss)
end

function playerWasted(ammo, attacker, weapon, bodypart)
  objDamageManager:Process("funcPlayerWasted", source, attacker, ammo, weapon, bodypart)
  objSTimerUtils:setTimerByID("TRespawnPending", setTimer(callbackFunc, 5000, 1, "funcRespawnPending", {["source"] = source}))
end

-- game mode related events
addEventHandler("onGamemodeMapStart", root, main)
-- player related events
addEventHandler("onPlayerJoin", root, createPlayer)
addEventHandler("onPlayerQuit", root, destroyPlayer)
addEventHandler("onPlayerWasted", root, playerWasted)
-- colshape related events
addEventHandler("onElementColShapeHit", root, callbackHit)
addEventHandler("onElementColShapeLeave", root, callbackLeave)
-- vehicle related events
addEventHandler("onVehicleEnter", root, callbackVehicleEnter)
addEventHandler("onVehicleStartExit", root, callbackVehicleStartExit)
addEventHandler("onVehicleExit", root, callbackVehicleExit)
addEventHandler("onVehicleExplode", root, callbackVehicleExplode)
addEventHandler("onVehicleRespawn", root, callbackVehicleRespawn)
-- custom events
addEvent("callbackClient", true)
addEventHandler("callbackClient", root, callbackClient)
addEvent("funcSwitchWeapons", true)
addEventHandler("funcSwitchWeapons", root, callbackFunc)
addEvent("funcSetPlayerTeam", true)
addEventHandler("funcSetPlayerTeam", root, callbackFunc)
addEvent("funcSetPlayerSquad", true)
addEventHandler("funcSetPlayerSquad", root, callbackFunc)
addEvent("funcUnsetPlayer", true)
addEventHandler("funcUnsetPlayer", root, callbackFunc)
addEvent("funcSpawnPlayer", true)
addEventHandler("funcSpawnPlayer", root, callbackFunc)
addEvent("funcSetPlayerSkin", true)
addEventHandler("funcSetPlayerSkin", root, callbackFunc)
addEvent("funcAttachBlip", true)
addEventHandler("funcAttachBlip", root, callbackFunc)
addEvent("funcKillPlayer", true)
addEventHandler("funcKillPlayer", root, callbackFunc)
addEvent("funcRespawnPlayer", true)
addEventHandler("funcRespawnPlayer", root, callbackFunc)
addEvent("funcStartTransfer", true)
addEventHandler("funcStartTransfer", root, callbackFunc)
addEvent("funcStartCampaign", true)
addEventHandler("funcStartCampaign", root, callbackFunc)
addEvent("funcCancelCampaign", true)
addEventHandler("funcCancelCampaign", root, callbackFunc)
addEvent("funcSetAttachments", true)
addEventHandler("funcSetAttachments", root, callbackFunc)
addEvent("funcUnfreezeTransfer", true)
addEventHandler("funcUnfreezeTransfer", root, callbackFunc)
addEvent("funcTriggerFlareArea", true)
addEventHandler("funcTriggerFlareArea", root, callbackFunc)
addEvent("funcCreateExplosion", true)
addEventHandler("funcCreateExplosion", root, callbackFunc)
addEvent("funcFreeProjectile", true)
addEventHandler("funcFreeProjectile", root, callbackFunc)

-- Author: Ace_Gambit