-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

local objDataManager = ObjDataManager.create()
local objTimerUtils = ObjTimerUtils.create()
local objFontUtils = ObjFontUtils.create()
local objCineManager = ObjCineManager.create(5.0)
local objTextManager = ObjTextManager.create()
local objClientPlayer = ObjClientPlayer.create()
local objTeamSelection = ObjTeamSelection.create()
local objSquadSelection = ObjSquadSelection.create()
local objDimensions = ObjDimensions.create()
local objSpawnpoints = ObjSpawnpoints.create()
local objProgressBars = ObjProgressBars.create()
local objScoreBoard = ObjScoreBoard.create()
local objSplash = ObjSplash.create()
local objSpectator = ObjSpectator.create()
local objClientCommands = ObjClientCommands.create()
local objClientVehicles = ObjClientVehicles.create()
local objVehicleDamage = ObjVehicleDamage.create()
local objLiftMarkers = ObjLiftMarkers.create()
local objRefuelMarkers = ObjRefuelMarkers.create()
local objRepairMarkers = ObjRepairMarkers.create()
local objWarfactoryMarkers = ObjWarfactoryMarkers.create()
local objAmmodepotMarkers = ObjAmmodepotMarkers.create()
local objVehicleFuel = ObjVehicleFuel.create()
local objClientProjectiles = ObjClientProjectiles.create()
local objEngine = ObjEngine.create()
local objKillMessages = ObjKillMessages.create(650, 150)
local objWaterBarrier = ObjWaterBarrier.create()
local objClientWarfactory = ObjClientWarfactory.create()
local objClientVehicleWeapons = ObjClientVehicleWeapons.create()

-- client settings
local player = getLocalPlayer()
local screenX, screenY = guiGetScreenSize()
local startTick, endTick = 0, 0

-- just some variables...
local root = getRootElement()

function callbackTimer(request, ...)
  local x, y, z = 0, 0, 0
  local cX, cY, cZ = 0, 0, 0
  if (request == "funcUpdateRespawnTime") then
    objSpectator:update()
  end
  if (request == "funcWaterBarrier") then
    objWaterBarrier:step()
    if (objTimerUtils:getCounterByID("CWaterBarrier") >= 200) then
      objClientCommands:commandHandler("/kill", nil)
    end
    if (objTimerUtils:getCounterByID("CWaterBarrier") < 200 and
              objTimerUtils:getCounterByID("CWaterBarrier") > 0) then
      objTimerUtils:setTimerByID("TWaterBarrier", setTimer(callbackTimer, 50, 1, "funcWaterBarrier"))
    else
      objWaterBarrier:step()
    end
  end
  if (request == "funcUnlockControls") then
    objTimerUtils:setLocked(false)
  end
  if (request == "funcVehicleDamage") then
    if (objVehicleDamage:update(getPlayerOccupiedVehicle(player))) then
      objTimerUtils:setTimerByID("TVehicleDamage", setTimer(callbackTimer, 50, 1, "funcVehicleDamage"))
    end
  end
  if (request == "funcVehicleFuel") then
    if (objVehicleFuel:update(getPlayerOccupiedVehicle(player)) > 0) then
      objTimerUtils:setTimerByID("TVehicleFuel", setTimer(callbackTimer, 50, 1, "funcVehicleFuel"))
    end
  end
  if (request == "funcVehicleReload") then
    if (objClientVehicleWeapons:update(arg[1]) < 200) then
      objTimerUtils:setTimerByID("TVehicleReload", setTimer(callbackTimer, 50, 1, "funcVehicleReload", arg[1]))
    end
  end
  if (request == "funcUnfreezeTransfer") then
    x, y, z = getElementPosition(player)
    cX, cY, cZ = getCameraPosition()
    if (getCameraPosition() ~= false) then
      if (getDistanceBetweenPoints3D(x, y, z, cX, cY, cZ) <= 100) then
        objClientWarfactory:Process("funcUnfreezeTransfer", nil)
        objClientVehicleWeapons:showBar(getPlayerOccupiedVehicle(player))
      else
        objTimerUtils:setTimerByID("TUnfreezeTransfer", setTimer(callbackTimer, 50, 1, "funcUnfreezeTransfer"))
      end
    end
  end
end

function main(data)
  objDataManager:init(data)
  -- TODO: limit characters
  -- use font utils instead
  CMissionText["name"]["value"] = objDataManager:getMetaData()["name"] .. " " .. objDataManager:getMetaData()["version"]
  objCineManager:init(player)
  objTimerUtils:setNumFrames(objTextManager:init(objFontUtils, {CMissionText, CMissionFW, CInstructText, CInstructFW, CRoleText, CRoleFW}, screenX, screenY))
  startTick = getTickCount()
  objTextManager:createText()
  -- set current game state
  objClientPlayer:setGameState("STTeamSelection")
  -- hide hud components
  objClientPlayer:hudHide()
  objSpawnpoints:init(objDataManager:getSpawnpointsData())
  objTeamSelection:init(objClientPlayer, objDataManager:getCamerasData(), objCineManager, objDataManager:getSpawnpointsData(), objTextManager)
  objSquadSelection:init(objClientPlayer, objDataManager:getCamerasData(), objCineManager, objTextManager)
  objScoreBoard:init(screenX, screenY)
  objSplash:init(screenX, screenY, "data/generic/splash.png")
  objSpectator:init(player, objCineManager, objDataManager:getCamerasData(), objDataManager:getSpawnpointsData(), objScoreBoard)
  objClientCommands:init(objClientPlayer)
  objClientVehicles:init(objDataManager:getVehiclesData())
  objClientProjectiles:init(player, objDataManager:getProjectilesData())
  objEngine:init(objDataManager:getEngineData())
  objKillMessages:init(objDataManager:getSquadrolesData())
  objWaterBarrier:init(objProgressBars, objTimerUtils, objTextManager, screenX, screenY)
  objVehicleDamage:init(objClientPlayer, objClientVehicles, objProgressBars, objTextManager, screenX, screenY)
  objLiftMarkers:init(objDataManager:getObjectSequencesData())
  objRefuelMarkers:init(objDataManager:getRefuelspotsData())
  objRepairMarkers:init(objDataManager:getRepairspotsData())
  objWarfactoryMarkers:init(objDataManager:getWarfactoriesData())
  objAmmodepotMarkers:init(objDataManager:getAmmodepotsData())
  objVehicleFuel:init(objClientPlayer, objClientVehicles, objProgressBars, objTextManager, objRefuelMarkers, screenX, screenY)
  objClientWarfactory:init(objDataManager:getWarfactoriesData(), objClientPlayer, objTextManager, objCineManager, objDataManager:getCamerasData())
  objClientVehicleWeapons:init(objDataManager:getWarfactoriesData(), objTextManager, objClientWarfactory, objClientPlayer, objProgressBars)
  objProgressBars:createBar("PBarMain", 168, 13, 0, objTimerUtils:getNumFrames(), 0, "gray", 20, screenY - 40, false)
  objSplash:show()
  objProgressBars:showByID("PBarMain")
end

function clientSpawn()
  if (source == player) then
    if (objClientPlayer:getFirstSpawn()) then
      objClientPlayer:setSource(player)
      -- client player has spawned
      objClientPlayer:callback()
      objClientPlayer:setFirstSpawn(false)
      -- wait for response
    end
    objWarfactoryMarkers:updateClosed(player)
    objAmmodepotMarkers:updateClosed(player, 1)
    objDimensions:setDimension(player, {"object", "vehicle", "marker", "colshape"}, math.random(1, 65536))
    -- TODO: buggy...
    -- objEngine:replaceEngine()
  end
  objClientPlayer:getBlip()
end

-- client render event
function clientTick()
  if (not objTimerUtils:getLoaded() and objTimerUtils:getCounterByID("CFrames") <= objTimerUtils:getNumFrames() and objTimerUtils:getNumFrames() ~= 0) then
    if (objProgressBars:getBarByID("PBarMain") ~= nil) then
      objProgressBars:stepByID("PBarMain")
    end
    objTimerUtils:counterByID("CFrames", 1)
  elseif (not objTimerUtils:getLoaded() and objTimerUtils:getCounterByID("CFrames") >= objTimerUtils:getNumFrames() and objTimerUtils:getNumFrames() ~= 0) then
    objProgressBars:hideByID("PBarMain")
    objTimerUtils:setLoaded(true)
    -- welcome!
    endTick = getTickCount()
    outputChatBox("* Client script loaded (" .. (endTick - startTick) .. " ms)...", 255, 100, 100)
  end
  objCineManager:Tick()
  objTextManager:Tick()
  objSpawnpoints:Tick()
  if (objProgressBars:getBarByID("PBarMain") ~= nil) then
    objProgressBars:TickByID("PBarMain")
  end
  objKillMessages:Tick()
  objWaterBarrier:Tick()
  objLiftMarkers:Tick()
  objRefuelMarkers:Tick()
  objRepairMarkers:Tick()
  objWarfactoryMarkers:Tick()
  objAmmodepotMarkers:Tick()
  objVehicleDamage:Tick()
  objVehicleFuel:Tick()
  objClientVehicleWeapons:Tick()
end

-- callbacks
function callbackFunc(request, params)
  local cooldownPeriod = 0
  if (not objTimerUtils:getLoaded()) then
    return
  end
  if (request == "funcTeamSelection") then
    objClientCommands:setEnabled(false)
    objSplash:show()
    objClientPlayer:hudHide()
    toggleAllControls(false)
    objTeamSelection:triggerSelection(false)
    bindKey("arrow_l", "down", keyFunc)
    bindKey("arrow_r", "down", keyFunc)
    bindKey("arrow_u", "down", keyFunc)
    bindKey("arrow_d", "down", keyFunc)
    bindKey("space", "down", keyFunc)
    bindKey("enter", "down", keyFunc)
    unbindKey("F1", "down")
    objTimerUtils:setSpawned(true)
  end
  if (request == "funcSpawnPlayer") then
    objClientPlayer:setGameState("STRoundStarted")
    -- unlock just in case we are still stuck...
    objSpawnpoints:unlockFromMarkers(player)
    objSplash:hide()
    objClientVehicles:update()
    objTextManager:killAll()
    unbindKey("arrow_l", "down")
    unbindKey("arrow_r", "down")
    unbindKey("arrow_u", "down")
    unbindKey("arrow_d", "down")
    unbindKey("space", "down")
    unbindKey("enter", "down")
    unbindKey("F1", "down")
    toggleAllControls(true)
    objCineManager:triggerTrack(false, nil, nil, nil, nil, nil, nil, nil, nil)
    objClientPlayer:hudShow()
    objTextManager:triggerMissionText(string.lower(params["team"]) .. "-start")
    objTextManager:triggerRoleText(string.lower(params["team"]))
    objTextManager:clearScreen(5000)
    objDimensions:reset()
    objSpawnpoints:setPositionByTeam(params["team"], params["spot"])
    objClientCommands:setEnabled(true)
  end
  -- only needed once...
  if (request == "funcFadeout") then
    fadeCamera(false, 2.5)
    objCineManager:setFadedIn(false)
  end
  if (request == "funcFadein") then
    fadeCamera(true, 2.5)
    objCineManager:setFadedIn(true)
  end
  if (request == "funcUpdateTeams") then
    objTeamSelection:updateTeams(params)
  end
  if (request == "funcUpdateSquads") then
    objSquadSelection:updateSquads(params)
  end
  if (request == "funcRespawnPending") then
    fadeCamera(false, 0.5)
    bindKey("F1", "down", keyFunc)
    objClientVehicles:reset()
    objTextManager:killAll()
    objClientCommands:setEnabled(false)
    objSpectator:killedMode()
    if (objTimerUtils:isRunning(objTimerUtils:getTimerByID("TUpdateRespawnTime"))) then
      objTimerUtils:killTimerByID("TUpdateRespawnTime")
    end
    objTimerUtils:setTimerByID("TUpdateRespawnTime", setTimer(callbackTimer, 1000, 11, "funcUpdateRespawnTime"))
    objTextManager:createInstructDsp({"switchteam", "blank"})
  end
  if (request == "funcProjectile") then
    if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID(params["id"]))) then
      if (objClientProjectiles:getCreatorTypeByID(params["id"]) == "sam") then
        cooldownPeriod = math.random(2500, 3000)
      elseif (objClientProjectiles:getCreatorTypeByID(params["id"]) == "barrage") then
        cooldownPeriod = math.random(1000, 1500)
      elseif (objClientProjectiles:getCreatorTypeByID(params["id"]) == "ssm") then
        cooldownPeriod = math.random(500, 1500)
      end
      if (params["flag"] ~= nil) then -- turret explosions
        if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TProcessExplosion" .. params["id"]))) then
          objTimerUtils:setTimerByID("TProcessExplosion" .. params["id"], setTimer(callbackFunc, cooldownPeriod, objClientProjectiles:getMaxProjectiles(params["id"]), "funcProcessExplosion", params))
        end
      else
        objClientProjectiles:resetTotalFiredByID(params["id"])
        objTimerUtils:setTimerByID(params["id"], setTimer(callbackFunc, cooldownPeriod, objClientProjectiles:getMaxProjectiles(params["id"]), "funcProcessProjectile", params))
      end
    end
  end
  if (request == "funcProcessProjectile") then
    objClientProjectiles:Process(params["id"])
  end
  if (request == "funcProcessExplosion") then
    objClientProjectiles:ProcessExplosion(params["id"])
  end
  if (request == "funcWaterBarrier") then
    objWaterBarrier:setRunning(params["countdown"])
    if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TWaterBarrier"))) then
      callbackTimer("funcWaterBarrier")
    end
  end
  if (request == "funcRefuel") then
    objVehicleFuel:showRefuelBar(getPlayerOccupiedVehicle(player))
  end
  if (request == "funcRepair") then
    objVehicleDamage:showRepairBar(getPlayerOccupiedVehicle(player))
  end
  if (request == "funcCampaignSelection") then
    objClientPlayer:setGameState("STCampaignSelection")
    objClientWarfactory:Process("funcCampaignSelection", nil)
    objClientCommands:setEnabled(false)
    objClientPlayer:hudHide()
    bindKey("arrow_l", "down", keyFunc)
    bindKey("arrow_r", "down", keyFunc)
    bindKey("enter", "down", keyFunc)
  end
  if (request == "funcTestAttachments") then
    objClientWarfactory:Process("funcTestAttachments", getPlayerOccupiedVehicle(player))
  end
  if (request == "funcStartCampaign") then
    if (objTimerUtils:isRunning(objTimerUtils:getTimerByID("TUnfreezeTransfer"))) then
      objTimerUtils:killTimerByID("TUnfreezeTransfer")
    end
    objTimerUtils:setTimerByID("TUnfreezeTransfer", setTimer(callbackTimer, 50, 1, "funcUnfreezeTransfer"))
    objClientPlayer:setGameState("STRoundStarted")
    objClientVehicles:update()
    if (objClientVehicles:isPlayerController(player)) then
      objClientVehicleWeapons:showBar(getPlayerOccupiedVehicle(player))
    end
    objTextManager:killAll()
    unbindKey("arrow_l", "down")
    unbindKey("arrow_r", "down")
    unbindKey("space", "down")
    unbindKey("enter", "down")
    objCineManager:triggerTrack(false, nil, nil, nil, nil, nil, nil, nil, nil)
    objClientPlayer:hudShow()
    objTextManager:clearScreen(5000)
    objClientCommands:setEnabled(true)
    callbackFunc("funcDestroyFlare", nil)
    callbackFunc("funcFadein", nil)
  end
  if (objClientVehicleWeapons:getReloadPosition(false) >= 200) then
    if (request == "funcProcessVWBarrage") then
      objClientVehicleWeapons:ProcessVWBarrage()
    end
    if (request == "funcCreateVWBarrage") then
      if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TVWBarrage"))) then
        callbackFunc("funcProcessVWBarrage", nil)
        callbackTimer("funcVehicleReload", getPlayerOccupiedVehicle(player))
        objClientVehicleWeapons:toggleBar(getPlayerOccupiedVehicle(player), 1)
        objAmmodepotMarkers:updateClosed(player, 1)
        objTimerUtils:setTimerByID("TVWBarrage", setTimer(callbackFunc, 500, 3, "funcProcessVWBarrage", nil))
      end
    end
    if (request == "funcCreateVWReconFlare") then
      if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TVWReconFlare"))) then
        -- NOTE: this event is toggled to keep the amount of callbacks to a minimum
        addEventHandler("onClientExplosion", root, callbackExplosion)
        objClientVehicleWeapons:setEventToggled(true)
        objClientVehicleWeapons:ProcessVWReconFlare()
        callbackTimer("funcVehicleReload", getPlayerOccupiedVehicle(player))
        objClientVehicleWeapons:toggleBar(getPlayerOccupiedVehicle(player), 1)
        objAmmodepotMarkers:updateClosed(player, 1)
        objTimerUtils:setTimerByID("TVWReconFlare", setTimer(callbackFunc, 2500, 3, "", nil))
      end
    end
    if (request == "funcCreateVWBomb") then
      if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TVWBomb"))) then
        objClientVehicleWeapons:ProcessVWBomb()
        callbackTimer("funcVehicleReload", getPlayerOccupiedVehicle(player))
        objClientVehicleWeapons:toggleBar(getPlayerOccupiedVehicle(player), 1)
        objAmmodepotMarkers:updateClosed(player, 1)
        objTimerUtils:setTimerByID("TVWBomb", setTimer(callbackFunc, 2500, 1, "", nil))
      end
    end
    if (request == "funcCreateVWReconASFlare") then
      if (not objTimerUtils:isRunning(objTimerUtils:getTimerByID("TVWReconASFlare"))) then
        -- NOTE: this event is toggled to keep the amount of callbacks to a minimum
        addEventHandler("onClientExplosion", root, callbackExplosion)
        objClientVehicleWeapons:setEventToggled(true)
        objClientVehicleWeapons:ProcessVWReconASFlare(params["attachment"])
        callbackTimer("funcVehicleReload", getPlayerOccupiedVehicle(player))
        objClientVehicleWeapons:toggleBar(getPlayerOccupiedVehicle(player), 1)
        objAmmodepotMarkers:updateClosed(player, 1)
        objTimerUtils:setTimerByID("TVWReconASFlare", setTimer(callbackFunc, 2500, 1, "", nil))
      end
    end
  end
  if (request == "funcToggleVWBar") then
    objClientVehicleWeapons:toggleBar(getPlayerOccupiedVehicle(player), 0)
    objAmmodepotMarkers:updateClosed(player, 0)
  end
  if (request == "funcDestroyFlare") then
    objClientVehicleWeapons:destroyFlareArea()
  end
  if (request == "funcVehicleNoHud") then
    objVehicleDamage:hideBar()
    objVehicleDamage:hideRepairBar()
    objTimerUtils:killTimerByID("TVehicleDamage")
    objVehicleFuel:hideBar()
    objVehicleFuel:hideRefuelBar()
    objTimerUtils:killTimerByID("TVehicleFuel")
    objClientVehicleWeapons:hideBar()
    objTextManager:killAll()
  end
end

function callbackHit(theShape, matchingDimension)
  local id = ""
  if (objTimerUtils:getSpawned() and getElementType(source) == "player" and source == player) then
    id = tonumber(getElementData(theShape, "id"))
    if (id <= 100) then
      objSpawnpoints:triggerPulse(id, true)
      objClientPlayer:setProtected(true)
      if (objClientPlayer:getGameState() == "STRoundStarted") then
        objSpawnpoints:lockToMarkerByID(objClientPlayer, id, true)
        objSpawnpoints:setSpawnpointID(id)
        bindKey("enter", "down", keyFunc)
      end
    end
    if (id >= 101 and id <= 499) then
      objClientVehicles:triggerBlip(id, "1", 255)
    end
    if (id >= 500 and id <= 699) then
      objLiftMarkers:triggerPulse(id, true)
      if (objClientPlayer:getGameState() == "STRoundStarted") then
        objLiftMarkers:lockToMarkerByID(objClientPlayer, id, true)
        bindKey("enter", "down", keyFunc)
      end
    end
    if (id >= 3001 and id <= 3499) then
      objRefuelMarkers:triggerPulse(id, true)
    end
    if (id >= 3500 and id <= 3999) then
      if (getPlayerOccupiedVehicle(source) ~= false) then
        if (getElementData(getPlayerOccupiedVehicle(source), "id") ~= false) then
          if (not objClientVehicles:getCanRepairByID(getElementData(getPlayerOccupiedVehicle(source), "id"))) then
            objTextManager:createInstructDsp({"closerepair", "blank"})
          end
        end
      end
      objRepairMarkers:triggerPulse(id, true)
    end
    if (id >= 4000 and id <= 4100) then
      objWarfactoryMarkers:triggerPulse(id, true)
      if (objClientVehicles:isPlayerController(source) ~= false and objWarfactoryMarkers:isVehicleAllowed(source, id)) then
        objClientWarfactory:Process("funcWaitingTransfer", getPlayerOccupiedVehicle(source))
        bindKey("space", "down", keyFunc)
      end
    end
    if (id >= 4101 and id <= 4199) then
      objAmmodepotMarkers:triggerPulse(id, true)
    end
  end
end

function callbackLeave(theShape, matchingDimension)
  local id = ""
  if (objTimerUtils:getSpawned() and getElementType(source) == "player" and source == player) then
    id = tonumber(getElementData(theShape, "id"))
    if (id <= 100) then
      objSpawnpoints:triggerPulse(id, false)
      objClientPlayer:setProtected(false)
      if (objClientPlayer:getGameState() == "STTeamSelection" or
            objClientPlayer:getGameState() == "STSquadSelection") then
        objSpawnpoints:lockToMarkerByID(objClientPlayer, id, true)
        objSpawnpoints:setSpawnpointID(-1)
      end
    end
    if (id >= 101 and id <= 499) then
      objClientVehicles:triggerBlip(id, "0", 0)
    end
    if (id >= 500 and id <= 600) then
      objLiftMarkers:triggerPulse(id, false)
    end
    if (id >= 3001 and id <= 3499) then
      objRefuelMarkers:triggerPulse(id, false)
      if (not objClientVehicles:getCanRefuelByID(id - 3000)) then
        objRefuelMarkers:toggleRefuelSpotByID(id, false)
      end
      objVehicleFuel:hideRefuelBar()
    end
    if (id >= 3500 and id <= 3999) then
      objRepairMarkers:triggerPulse(id, false)
      objVehicleDamage:hideRepairBar()
    end
    if (id >= 4000 and id <= 4100) then
      objWarfactoryMarkers:triggerPulse(id, false)
      if (objClientVehicles:isPlayerController(source) ~= false) then
        objClientWarfactory:Process("funcCancelTransfer", nil)
      end
    end
    if (id >= 4101 and id <= 4199) then
      objAmmodepotMarkers:triggerPulse(id, false)
    end
  end
end

function callbackGUIFunc(button, state, absoluteX, absoluteY)
  objScoreBoard:Process(source)
  objSpectator:Process(source)
end

function callbackVehicleEnter(thePlayer, seat)
  local id = getElementData(source, "id")
  objClientVehicles:triggerBlip(id, "0", 0)
  -- vehicle bars...
  if (thePlayer == player) then
    objVehicleDamage:showBar(source)
    objTimerUtils:setTimerByID("TVehicleDamage", setTimer(callbackTimer, 50, 1, "funcVehicleDamage"))
    objVehicleFuel:showBar(source)
    objTimerUtils:setTimerByID("TVehicleFuel", setTimer(callbackTimer, 50, 1, "funcVehicleFuel"))
    objClientVehicleWeapons:showBar(source)
    if (objClientVehicles:getCanRefuelByID(id)) then
      objRefuelMarkers:toggleRefuelSpotByID(tonumber(id) + 3000, true)
      if (objVehicleFuel:getRefuelBusy() and objClientVehicles:getLockedFuelByID(id) and objClientVehicles:isPlayerController(thePlayer) ~= false) then
        objVehicleFuel:showRefuelBar(getPlayerOccupiedVehicle(thePlayer))
      end
    end
    objAmmodepotMarkers:updateClosed(thePlayer, 0)
  end
end

function callbackVehicleExit(thePlayer, seat)
  local id = getElementData(source, "id")
  objClientVehicles:updateColShape(id)
  objClientVehicles:triggerBlip(id, "1", 255)
  -- vehicle bars...
  if (thePlayer == player) then
    callbackFunc("funcVehicleNoHud")
    objRefuelMarkers:toggleRefuelSpotByID(tonumber(id) + 3000, false)
    if (objClientVehicles:isPlayerController(thePlayer) ~= false) then
      setVehicleEngineState(source, false)
    end
    objAmmodepotMarkers:updateClosed(thePlayer, 0)
  end
end

function callbackVehicleRespawn()
  local id = getElementData(source, "id")
  objClientVehicles:updateColShape(id)
  objClientVehicles:triggerBlip(id, "1", 255)
end

function callbackStreamOut()
  if (getElementType(source) == "vehicle") then
    objClientVehicles:hideBlipByVehicle(source)
  end
end

function callbackExplosion(x, y, z, explosionType)
  if (not objClientVehicleWeapons:getEventToggled()) then
    removeEventHandler("onClientExplosion", root, callbackExplosion)
    cancelEvent()
  end
  objClientVehicleWeapons:Process(source, x, y, z, explosionType)
end

-- key controls
function keyFunc(key, keyState)
  local keyTbl = {["arrow_r"] = 1, ["arrow_l"] = 0}
  local switchTeam = false
  local team = nil
  if ((key == "arrow_l" or key == "arrow_r") and not objTimerUtils:getLocked()) then
    if (objClientPlayer:getGameState() == "STTeamSelection") then
      objTeamSelection:switch()
    elseif (objClientPlayer:getGameState() == "STSquadSelection") then
      objSquadSelection:switch(keyTbl[key])
    elseif (objClientPlayer:getGameState() == "STCampaignSelection" and objClientVehicles:isPlayerController(player)) then
      objClientWarfactory:switch()
      objClientVehicleWeapons:showBar(getPlayerOccupiedVehicle(player))
    end
    objTimerUtils:setLocked(true)
    objTimerUtils:setTimerByID("TLockControls", setTimer(callbackTimer, 1500, 1, "funcUnlockControls"))
  end
  if (key == "arrow_u" and not objTimerUtils:getLocked()) then
    if (objClientPlayer:getGameState() == "STTeamSelection") then
      objTeamSelection:switchRole(1)
    end
    objTimerUtils:setLocked(true)
    objTimerUtils:setTimerByID("TLockControls", setTimer(callbackTimer, 500, 1, "funcUnlockControls"))
  end
  if (key == "arrow_d" and not objTimerUtils:getLocked()) then
    if (objClientPlayer:getGameState() == "STTeamSelection") then
      objTeamSelection:switchRole(0)
    end
    objTimerUtils:setLocked(true)
    objTimerUtils:setTimerByID("TLockControls", setTimer(callbackTimer, 500, 1, "funcUnlockControls"))
  end
  if (key == "space" and not objTimerUtils:getLocked()) then
    if (objClientPlayer:getGameState() == "STTeamSelection") then
      switchTeam, team = objTeamSelection:setPlayerTeam()
      if (switchTeam) then
        fadeCamera(false, 0.5)
        objTextManager:killAll()
        objSquadSelection:triggerSelection(team)
      end
      objClientPlayer:setGameState("STSquadSelection")
    elseif (objClientPlayer:getGameState() == "STSquadSelection") then
      -- request spawn after squad selection
      objSquadSelection:setPlayerSquad()
    elseif (objClientPlayer:getGameState() == "STRoundStarted") then
      if (objClientVehicles:isPlayerController(player)) then
        if (objClientVehicles:getVehicleAmmo(getPlayerOccupiedVehicle(player)) <= 0) then
          objClientWarfactory:Process("funcStartTransfer", getPlayerOccupiedVehicle(player))
          if (objTimerUtils:isRunning(objTimerUtils:getTimerByID("TUnfreezeTransfer"))) then
            objTimerUtils:killTimerByID("TUnfreezeTransfer")
          end
          objTimerUtils:setTimerByID("TUnfreezeTransfer", setTimer(callbackTimer, 50, 1, "funcUnfreezeTransfer"))
        end
      end
    elseif (objClientPlayer:getGameState() == "STCampaignSelection" and objClientVehicles:isPlayerController(player)) then
      objClientWarfactory:Process("funcStartCampaign", nil)
    end
    objTimerUtils:setLocked(true)
    objTimerUtils:setTimerByID("TLockControls", setTimer(callbackTimer, 1500, 1, "funcUnlockControls"))
  end
  if (key == "enter") then
    if (objClientPlayer:getGameState() == "STSquadSelection" and not objTimerUtils:getLocked()) then
      fadeCamera(false, 0.5)
      objTeamSelection:triggerSelection(true)
      objClientPlayer:setGameState("STTeamSelection")
      objTimerUtils:setLocked(true)
      objTimerUtils:setTimerByID("TLockControls", setTimer(callbackTimer, 1500, 1, "funcUnlockControls"))
    end
    if (objClientPlayer:getGameState() == "STRoundStarted") then
      objSpawnpoints:unlockFromMarkers(player)
      objLiftMarkers:unlockFromMarkers(player)
      unbindKey("enter", "down")
    end
    if (objClientPlayer:getGameState() == "STCampaignSelection") then
      objClientWarfactory:Process("funcCancelCampaign", nil)
    end
  end
  if (key == "tab") then
    objScoreBoard:trigger(keyState == "down")
  end
  if (key == "F1") then
    objScoreBoard:trigger(false)
    objSpectator:reset()
    if (objTimerUtils:isRunning(objTimerUtils:getTimerByID("TUpdateRespawnTime"))) then
      objTimerUtils:killTimerByID("TUpdateRespawnTime")
    end
    callbackFunc("funcTeamSelection", nil)
    objClientPlayer:setGameState("STTeamSelection")
  end
  if (objClientVehicles:isPlayerController(player) ~= false) then
    if (key == "mouse1" and keyState == "down") then
      objClientVehicleWeapons:triggerTurret(player, "left", true)
    elseif (key == "mouse1" and keyState == "up") then
      objClientVehicleWeapons:triggerTurret(false, "", false)
    end
    if (key == "mouse2" and keyState == "down") then
      objClientVehicleWeapons:triggerTurret(player, "right", true)
    elseif (key == "mouse2" and keyState == "up") then
      objClientVehicleWeapons:triggerTurret(false, "", false)
    end
  end
end

-- client commands
function commandHandler(commandName, ...)
  objClientCommands:commandHandler(commandName, arg)
  if (commandName == "/test") then
    --
  end
end

-- init
function init()
  local pos = nil
  local target = nil
  if (objTimerUtils:getLoaded()) then
    pos = split(objDataManager:getCamerasData()["intro"]["pos"], string.byte(' '))
    target = split(objDataManager:getCamerasData()["intro"]["target"], string.byte(' '))
    if (objTimerUtils:getCounterByID("CMain") == 0) then
      fadeCamera(true, 5.0)
      objCineManager:triggerTrack(true, 1, 360, 0.65, 25.0, 5.0, tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]))
    end
    if (objTimerUtils:getCounterByID("CMain") >= 10) then
      objCineManager:setCameraPos(false, tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]), tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
      objTextManager:triggerMissionText("name") -- map name + version
      -- request team selection screen after five seconds
      objTimerUtils:setTimerByID("TTeamSelection", setTimer(callbackFunc, 5000, 1, "funcTeamSelection", nil))
      objTimerUtils:setTimerByID("TFadeout", setTimer(callbackFunc, 2500, 1, "funcFadeout", nil))
      -- bind scoreboard keys...
      bindKey("tab", "down", keyFunc)
      bindKey("tab", "up", keyFunc)
      -- turret control...
      bindKey("mouse1", "down", keyFunc)
      bindKey("mouse1", "up", keyFunc)
      bindKey("mouse2", "down", keyFunc)
      bindKey("mouse2", "up", keyFunc)
      -- create radar colshapes
      objClientVehicles:createClientCols()
    else
      objTimerUtils:setTimerByID("TInit", setTimer(init, 1000, 1))
    end
    objCineManager:setCameraPos(false, tonumber(pos[1]), tonumber(pos[2]), tonumber(pos[3]), tonumber(target[1]), tonumber(target[2]), tonumber(target[3]))
    objTimerUtils:counterByID("CMain", 1)
  else
    objTimerUtils:setTimerByID("TInit", setTimer(init, 2500, 1))
  end
end

-- player damage control
function playerDamage(attacker, weapon, bodypart)
  if (objClientPlayer:getProtected()) then
    cancelEvent()
  end
end

function playerWasted(killer, weapon, bodypart)
  local killerWeapon = weapon
  if (source == player) then
    callbackFunc("funcVehicleNoHud")
  end
  if (objTimerUtils:getLoaded()) then
    if ((killerWeapon == false or killerWeapon == nil) and objWaterBarrier:getRunning()) then
      killerWeapon = 1002
    end
    objKillMessages:Process(source, killer, killerWeapon)
  end
end

-- destroy objects
function clean()
  if (source == player) then
    objTextManager = nil
    objProgressBar = nil
    objSplash = nil
    objClientVehicles:clean()
  else
    if (objTimerUtils:getLoaded()) then
      -- player left
      objKillMessages:Process(source, nil, 1003)
    end
  end
end

-- client related events
addEventHandler("onClientRender", root, clientTick)
-- player related events
addEventHandler("onClientPlayerSpawn", root, clientSpawn)
addEventHandler("onClientPlayerQuit", root, clean)
addEventHandler("onClientPlayerDamage", root, playerDamage)
addEventHandler("onClientPlayerWasted", root, playerWasted)
-- colshape related events
addEventHandler("onClientElementColShapeHit", root, callbackHit)
addEventHandler("onClientElementColShapeLeave", root, callbackLeave)
addEventHandler("onClientElementStreamOut", root, callbackStreamOut)
-- gui related events
addEventHandler("onClientGUIClick", root, callbackGUIFunc)
-- vehicle related events
addEventHandler("onClientVehicleEnter", root, callbackVehicleEnter)
addEventHandler("onClientVehicleExit", root, callbackVehicleExit)
addEventHandler("onClientVehicleRespawn", root, callbackVehicleRespawn)
-- custom events
addEvent("main", true)
addEventHandler("main", root, main)
addEvent("init", true)
addEventHandler("init", root, init)
addEvent("funcSpawnPlayer", true)
addEventHandler("funcSpawnPlayer", root, callbackFunc)
addEvent("funcUpdateTeams", true)
addEventHandler("funcUpdateTeams", root, callbackFunc)
addEvent("funcUpdateSquads", true)
addEventHandler("funcUpdateSquads", root, callbackFunc)
addEvent("funcRespawnPending", true)
addEventHandler("funcRespawnPending", root, callbackFunc)
addEvent("funcProjectile", true)
addEventHandler("funcProjectile", root, callbackFunc)
addEvent("funcWaterBarrier", true)
addEventHandler("funcWaterBarrier", root, callbackFunc)
addEvent("funcRefuel", true)
addEventHandler("funcRefuel", root, callbackFunc)
addEvent("funcRepair", true)
addEventHandler("funcRepair", root, callbackFunc)
addEvent("funcCampaignSelection", true)
addEventHandler("funcCampaignSelection", root, callbackFunc)
addEvent("funcTestAttachments", true)
addEventHandler("funcTestAttachments", root, callbackFunc)
addEvent("funcStartCampaign", true)
addEventHandler("funcStartCampaign", root, callbackFunc)
addEvent("funcCreateVWBarrage", true)
addEventHandler("funcCreateVWBarrage", root, callbackFunc)
addEvent("funcCreateVWReconFlare", true)
addEventHandler("funcCreateVWReconFlare", root, callbackFunc)
addEvent("funcCreateVWBomb", true)
addEventHandler("funcCreateVWBomb", root, callbackFunc)
addEvent("funcCreateVWReconASFlare", true)
addEventHandler("funcCreateVWReconASFlare", root, callbackFunc)
addEvent("funcToggleVWBar", true)
addEventHandler("funcToggleVWBar", root, callbackFunc)
addEvent("funcDestroyFlare", true)
addEventHandler("funcDestroyFlare", root, callbackFunc)
addEvent("funcVehicleNoHud", true)
addEventHandler("funcVehicleNoHud", root, callbackFunc)
-- client commands...
addCommandHandler("/kill", commandHandler)
addCommandHandler("/test", commandHandler)

-- Author: Ace_Gambit