-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

CMissionText = {
      ["name"] = {
      ["value"] = "", -- map name + version
      ["fontname"] = "priceorange",
      ["scale"] = 1.0,
      ["fadetime"] = 5000
                },
      ["blank"] = {
      ["value"] = " ",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 5000
                  },
      ["allies"] = {
      ["value"] = "<Allies>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                  },
      ["axis"] = {
      ["value"] = "<Axis>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["allies-start"] = {
      ["value"] = "Deploy!",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 5000
                },
      ["axis-start"] = {
      ["value"] = "Deploy!",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 5000
                },
      ["allies-alpha"] = {
      ["value"] = "<Alpha>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["allies-bravo"] = {
      ["value"] = "<Bravo>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["allies-charlie"] = {
      ["value"] = "<Charlie>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["allies-delta"] = {
      ["value"] = "<Delta>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["axis-alpha"] = {
      ["value"] = "<Alpha>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["axis-bravo"] = {
      ["value"] = "<Bravo>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["axis-charlie"] = {
      ["value"] = "<Charlie>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["axis-delta"] = {
      ["value"] = "<Delta>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                },
      ["allies-recon"] = {
      ["value"] = "<Recon>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                        },
      ["allies-assault"] = {
      ["value"] = "<Assault>",
      ["fontname"] = "pricegreen",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                          },
      ["axis-recon"] = {
      ["value"] = "<Recon>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                        },
      ["axis-assault"] = {
      ["value"] = "<Assault>",
      ["fontname"] = "pricered",
      ["scale"] = 1.0,
      ["fadetime"] = 3600000
                        }
               }

CMissionFW = {
      ["0032"] = 23,
      ["0033"] = 24,
      ["0036"] = 46,
      ["0046"] = 24,
      ["0048"] = 46,
      ["0049"] = 24,
      ["0050"] = 46,
      ["0051"] = 46,
      ["0052"] = 51,
      ["0053"] = 46,
      ["0054"] = 46,
      ["0055"] = 46,
      ["0056"] = 46,
      ["0057"] = 46,
      ["0060"] = 32,
      ["0062"] = 32,
      ["0063"] = 46,
      ["0064"] = 50,
      ["0065"] = 46,
      ["0066"] = 46,
      ["0067"] = 46,
      ["0068"] = 46,
      ["0069"] = 37,
      ["0070"] = 41,
      ["0071"] = 46,
      ["0072"] = 46,
      ["0073"] = 24,
      ["0074"] = 46,
      ["0075"] = 48,
      ["0076"] = 24,
      ["0077"] = 68,
      ["0078"] = 46,
      ["0079"] = 46,
      ["0080"] = 46,
      ["0081"] = 46,
      ["0082"] = 46,
      ["0083"] = 46,
      ["0084"] = 51,
      ["0085"] = 46,
      ["0086"] = 51,
      ["0087"] = 77,
      ["0088"] = 46,
      ["0089"] = 46,
      ["0090"] = 46,
      ["0097"] = 46,
      ["0098"] = 46,
      ["0099"] = 46,
      ["0100"] = 46,
      ["0101"] = 46,
      ["0102"] = 41,
      ["0103"] = 46,
      ["0104"] = 46,
      ["0105"] = 24,
      ["0106"] = 46,
      ["0107"] = 48,
      ["0108"] = 36,
      ["0109"] = 68,
      ["0110"] = 46,
      ["0111"] = 46,
      ["0112"] = 46,
      ["0113"] = 46,
      ["0114"] = 46,
      ["0115"] = 46,
      ["0116"] = 51,
      ["0117"] = 46,
      ["0118"] = 51,
      ["0119"] = 77,
      ["0120"] = 46,
      ["0121"] = 46,
      ["0122"] = 46
             }

-- Author: Ace_Gambit