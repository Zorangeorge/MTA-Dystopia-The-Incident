-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

CInstructText = {
      ["blank"] = {
      ["value"] = " ",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["navteam"] = {
      ["value"] = "Use LEFT and RIGHT arrow keys to switch team.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["navrole"] = {
      ["value"] = "Use UP and DOWN arrow keys to select squad role.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["jointeam"] = {
      ["value"] = "Press SPACE to join a team or TAB to bring up the player list.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["noteamslots"] = {
      ["value"] = "There are no more slots available on this team.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["nosquadslots"] = {
      ["value"] = "There are no more slots available on this squad.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["navsquad"] = {
      ["value"] = "Use LEFT and RIGHT arrow keys to switch squad.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["joinsquad"] = {
      ["value"] = "Press SPACE to join a squad or TAB to bring up the player list.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["backteam"] = {
      ["value"] = "Press ENTER to return to the team selection screen.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["switchteam"] = {
      ["value"] = "Press F1 to go to the team selection screen.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["waterbarrier"] = {
      ["value"] = "Do not leave the area or the sharks will kill you!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                },
      ["lowfuel"] = {
      ["value"] = "Your fuel level has dropped below 75 percent!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                  },
      ["openrefuel"] = {
      ["value"] = "Make sure to refill at a fuel marker before you run out!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                  },
      ["highdamage"] = {
      ["value"] = "The engine of your vehicle is starting to get severely damaged!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                      },
      ["openrepair"] = {
      ["value"] = "Make sure you get it repaired at a repair marker before you wreck it!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                      },
      ["closerepair"] = {
      ["value"] = "You can not repair your vehicle right now.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                      },
      ["opentransfer"] = {
      ["value"] = "Press SPACE to transfer to the warfactory.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                        },
      ["closetransfer"] = {
      ["value"] = "You can not transfer this vehicle to the warfactory!",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                        },
      ["navcampaign"] = {
      ["value"] = "Use LEFT and RIGHT arrow keys to switch campaign.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                        },
      ["joincampaign"] = {
      ["value"] = "Press SPACE to join a campaign or ENTER to cancel.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                        },
      ["noammo"] = {
      ["value"] = "Your vehicle ran out of ammunition.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                  },
      ["reload"] = {
      ["value"] = "You can go to an ORANGE marker to reload your weapons.",
      ["fontname"] = "arborcrest",
      ["scale"] = 0.5
                  }
               }

CInstructFW = {
      ["0032"] = 16,
      ["0033"] = 9,
      ["0046"] = 9,
      ["0048"] = 23,
      ["0049"] = 9,
      ["0050"] = 23,
      ["0051"] = 23,
      ["0052"] = 24,
      ["0053"] = 23,
      ["0054"] = 23,
      ["0055"] = 23,
      ["0056"] = 25,
      ["0057"] = 23,
      ["0063"] = 23,
      ["0064"] = 27,
      ["0065"] = 27,
      ["0066"] = 25,
      ["0067"] = 25,
      ["0068"] = 25,
      ["0069"] = 22,
      ["0070"] = 22,
      ["0071"] = 26,
      ["0072"] = 24,
      ["0073"] = 9,
      ["0074"] = 18,
      ["0075"] = 25,
      ["0076"] = 22,
      ["0077"] = 29,
      ["0078"] = 24,
      ["0079"] = 25,
      ["0080"] = 26,
      ["0081"] = 26,
      ["0082"] = 26,
      ["0083"] = 23,
      ["0084"] = 23,
      ["0085"] = 25,
      ["0086"] = 27,
      ["0087"] = 35,
      ["0088"] = 27,
      ["0089"] = 27,
      ["0090"] = 24,
      ["0097"] = 20,
      ["0098"] = 20,
      ["0099"] = 19,
      ["0100"] = 20,
      ["0101"] = 21,
      ["0102"] = 15,
      ["0103"] = 21,
      ["0104"] = 20,
      ["0105"] = 9,
      ["0106"] = 9,
      ["0107"] = 20,
      ["0108"] = 9,
      ["0109"] = 28,
      ["0110"] = 21,
      ["0111"] = 20,
      ["0112"] = 20,
      ["0113"] = 20,
      ["0114"] = 13,
      ["0115"] = 21,
      ["0116"] = 15,
      ["0117"] = 20,
      ["0118"] = 21,
      ["0119"] = 29,
      ["0120"] = 22,
      ["0121"] = 21,
      ["0122"] = 20
             }

-- Author: Ace_Gambit