-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

CRoleText = {
      ["engineer"] = {
      ["value"] = "engineer",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                    },
      ["marksman"] = {
      ["value"] = "marksman",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                    },
      ["grenadier"] = {
      ["value"] = "grenadier",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                    },
      ["medic"] = {
      ["value"] = "medic",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                 },
      ["allies"] = {
      ["value"] = "allies",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                  },
      ["axis"] = {
      ["value"] = "axis",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                },
      ["waterbarrier"] = {
      ["value"] = "shark-o-meter",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                        },
      ["refuel"] = {
      ["value"] = "refueling",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                 },
      ["repair"] = {
      ["value"] = "repairing",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                 },
      ["campaign"] = {
      ["value"] = "campaign",
      ["fontname"] = "microgramma",
      ["scale"] = 1.0
                    }
            }

CRoleFW = {
      ["0045"] = 20,
      ["0065"] = 33,
      ["0066"] = 29,
      ["0067"] = 28,
      ["0068"] = 29,
      ["0069"] = 25,
      ["0070"] = 25,
      ["0071"] = 29,
      ["0072"] = 30,
      ["0073"] = 12,
      ["0074"] = 25,
      ["0075"] = 30,
      ["0076"] = 24,
      ["0077"] = 36,
      ["0078"] = 30,
      ["0079"] = 30,
      ["0080"] = 27,
      ["0081"] = 32,
      ["0082"] = 28,
      ["0083"] = 28,
      ["0084"] = 28,
      ["0085"] = 29,
      ["0086"] = 31,
      ["0087"] = 42,
      ["0088"] = 33,
      ["0089"] = 32,
      ["0090"] = 28
         }

-- Author: Ace_Gambit