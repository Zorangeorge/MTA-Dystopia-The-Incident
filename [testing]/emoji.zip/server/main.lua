------------------------------------------------------------------------------------------------------------------
----                            Development by: Fellow     main.lua (server)                                  ----
----                                • 01/08/2018 •                                                            ----
----                                    V.0.0.8                                                               ----
------------------------------------------------------------------------------------------------------------------

local playerChangeImage = {
    {state = "false", img = "gfx/lua.png"},
    {state = "false", img = "gfx/certo.png"},
    {state = "false", img = "gfx/pinto.png"}
}

addEvent("onPlayerRequestEmojiHead", true)
addEventHandler("onPlayerRequestEmojiHead", root, function(emoji)
	triggerClientEvent("onClientPlayerPlayEmojiHead", source, emoji)
end)