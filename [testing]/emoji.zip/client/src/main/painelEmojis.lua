------------------------------------------------------------------------------------------------------------------
----                            Development by: Fellow     painelEmojis.lua (client)                          ----
----                                • 01/08/2018 •                                                            ----
----                                    V.0.0.8                                                               ----
------------------------------------------------------------------------------------------------------------------

local super = Class("CRectangle", Container,
function ()
	static.getInstance = function()
		return LuaObject.getSingleton(static)
	end
end).getSuperclass()

function CRectangle:init()
	super.init(self)

	return self
end

function CRectangle:paint(g)
	local fSx, fSy = self:getLocationOnScreen()
	g:drawSetColor(self:getBackground())
	g:drawFilledRect(fSx, fSy, self:getWidth(), self:getHeight())
end


local super = Class("CPainelEmoji", Container,
function ()
	static.getInstance = function ()
		return LuaObject.getSingleton(static)
	end

end).getSuperclass()

function CPainelEmoji:init()
	super.init(self)

  	self.tick = getTickCount()

 	self.state = 'opering'

	self.m_strState = "nostate"


  	self:setStylesheet(StylesheetParser():parsestr([[
  	#buttonMid {
	    color: #0e111699;
	    cursor: pointer;
  	}

  	#buttonMid:hover {
	    color: #0e111655;
	    cursor: pointer;
	}

  	#buttonMid:active{
	    color: #0e111622;
	    cursor: pointer;
  	}    
	
 ]]))

	self.rot=0 

	local fSx, fSy = Graphics.relativeW(800), Graphics.relativeH(600)

	self:setBounds(Graphics.relativeW(0), Graphics.relativeH(0), Graphics.relativeW(800), Graphics.relativeH(600))

	local x,y,w,h = 0, 0, Graphics.relativeW(800), Graphics.relativeH(600)

	x, y, w, h = Graphics.relativeW(290), Graphics.relativeH(100), Graphics.relativeW(250), Graphics.relativeH(250)
	self.imgBase = Image()
	self.imgBase:setBounds(x, y, w, h)
	self.imgBase:setSource("gfx/painel/base.png")
	self:add(self.imgBase)

	x, y, w, h = Graphics.relativeW(387), Graphics.relativeH(199), Graphics.relativeW(50), Graphics.relativeH(62)
	self.imgInicial = Image2()
	self.imgInicial:setBounds(x, y, w, h)
	self.imgInicial:setId("buttonMid")
	self.imgInicial:setSource("gfx/painel/circle.png")
	self.imgInicial:addMouseListener(self)
	self:add(self.imgInicial)

	x, y, w, h = Graphics.relativeW(16), Graphics.relativeH(15), Graphics.relativeW(22), Graphics.relativeH(26)
	self.imgLua = Image()
	self.imgLua:setBounds(x, y, w, h)
	self.imgLua:setSource("gfx/lua.png")
	self.imgLua.decorator = true
	self.imgInicial:add(self.imgLua)

	x, y, w, h = Graphics.relativeW(368), Graphics.relativeH(128), Graphics.relativeW(90), Graphics.relativeH(70)
	self.imgUp = Image2()
	self.imgUp:setBounds(x, y, w, h)
	self.imgUp:setId("buttonMid")
	self.imgUp:setSource("gfx/painel/cima.png")
	self.imgUp:addMouseListener(self)
	self:add(self.imgUp)

	x, y, w, h = Graphics.relativeW(30), Graphics.relativeH(30), Graphics.relativeW(22), Graphics.relativeH(26)
	self.imgLua2 = Image()
	self.imgLua2:setBounds(x, y, w, h)
	self.imgLua2:setSource("gfx/certo.png")
	self.imgLua2:setZOrder(1)
	self.imgLua2.decorator = true
	self.imgUp:add(self.imgLua2)

	x, y, w, h = Graphics.relativeW(368), Graphics.relativeH(260), Graphics.relativeW(90), Graphics.relativeH(70)
	self.imgUp2 = Image2()
	self.imgUp2:setBounds(x, y, w, h)
	self.imgUp2:setId("buttonMid")
	self.imgUp2:setSource("gfx/painel/baixo.png")
	self.imgUp2:addMouseListener(self)
	self:add(self.imgUp2)

	x, y, w, h = Graphics.relativeW(30), Graphics.relativeH(30), Graphics.relativeW(22), Graphics.relativeH(26)
	self.imgLua3 = Image()
	self.imgLua3:setBounds(x, y, w, h)
	self.imgLua3:setSource("gfx/pinto.png")
	self.imgLua3:setZOrder(1)
	self.imgLua3:addMouseListener(self)
	self.imgLua3.decorator = true
	self.imgUp2:add(self.imgLua3)

	x, y, w, h = Graphics.relativeW(387), Graphics.relativeH(345), Graphics.relativeW(40), Graphics.relativeH(15)
	self.faceUrl = Label()
	self.faceUrl:setText("Developed by: Fellow")
	self.faceUrl:setBounds(x, y, w, h)
	self.faceUrl:setZOrder(8)
	self.faceUrl:setForeground(tocolor(255, 255, 255))
	self.faceUrl:setBackground(tocolor(0, 0, 0))
	self.faceUrl:setScale(Graphics.relativeH(0.6))
	self:add(self.faceUrl)

	--[[x, y, w, h = Graphics.relativeW(436), Graphics.relativeH(165), Graphics.relativeW(50), Graphics.relativeH(130)
	self.imgUp = Image()
	self.imgUp:setBounds(x, y, w, h)
	self.imgUp:setId("buttonMid")
	self.imgUp:setSource("gfx/painel/direita.png")
	self:add(self.imgUp)

	x, y, w, h = Graphics.relativeW(340), Graphics.relativeH(165), Graphics.relativeW(50), Graphics.relativeH(130)
	self.imgUp = Image()
	self.imgUp:setBounds(x, y, w, h)
	self.imgUp:setId("buttonMid")
	self.imgUp:setSource("gfx/painel/esquerda.png")
	self:add(self.imgUp)]]


	self.lastUse = getTickCount()

	return self
end

function CPainelEmoji:setVisible(visible)
  showCursor(visible)
  super.setVisible(self, visible)
end

function CPainelEmoji:mouseReleased(e)
	if (self.lastUse > (getTickCount() - 5000)) then
		outputDebugString("AINDA NAO O CANSADO")
		return
	end

	self.lastUse = getTickCount()

	local emoji = ""
    if (e.source == self.imgInicial) then
    	emoji = "lua"
    elseif (e.source == self.imgUp) then
    	emoji = "certo"
    elseif (e.source == self.imgUp2) then
    	emoji = "pinto"
    end
    
    triggerServerEvent("onPlayerRequestEmojiHead", localPlayer, emoji)
end

function CPainelEmoji:actionPerformed( e)

end

function CPainelEmoji:paint(g)
	local screen = {guiGetScreenSize()}
	local fWidth, fHeight = Graphics.relativeW(800), Graphics.relativeH(600)
	local fSx, fSy = Graphics.relativeW(800), Graphics.relativeH(600)


	super.paint(self, g)
end

function CPainelEmoji:setState(strState)
	self.m_strState = strState
end

function CPainelEmoji:getState()
	return self.m_strState
end

function CPainelEmoji.switch()
	local pLogin = CPainelEmoji.getInstance()
	local bVisible = not pLogin:isVisible()

	pLogin.m_uiTick = getTickCount()
	if (bVisible) then
		pLogin:setVisible(true)
		pLogin:setState("outputDebugString")
		showCursor(true)
		setPlayerHudComponentVisible("all", false)
		showChat(false)
	else
		pLogin:setState("closing")
		pLogin:setVisible(false)
		showCursor(false)
		setPlayerHudComponentVisible("all", true)
		showChat(true)
	end
end

local statePanelEmoji = "down"

addEventHandler("onClientResourceStart", resourceRoot,
function ()
	local pLogin = CPainelEmoji.getInstance()
	pLogin:setVisible(false)
	Toolkit.getInstance(): add(pLogin)

	bindKey("z", "down", stateDown)
	bindKey("z", "up", stateUp)
end)

function stateDown()
	CPainelEmoji.switch()
end

function stateUp()
	CPainelEmoji.switch()
end