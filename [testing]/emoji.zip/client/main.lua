------------------------------------------------------------------------------------------------------------------
----                            Development by: Fellow     main.lua (client)                                  ----
----                                • 01/08/2018 •                                                            ----
----                                    V.0.0.8                                                               ----
------------------------------------------------------------------------------------------------------------------


local players = {}

function drawEmojis()
    for k,player in ipairs(players) do
        if (player.tick < (getTickCount() - 5000)) then 
            table.remove(players, k)
        end

        local cx, cy, cz = getCameraMatrix()
        local px, py, pz = getPedBonePosition(player.element, 8)
        local distance = getDistanceBetweenPoints3D(px, py, pz, cx, cy, cz)
        local sx, sy = getScreenFromWorldPosition(px, py, pz + 0.3)
        
        if sx and sy then
            if (distance <= 120) then
                dxDrawImage(sx * 0.97, sy * 0.8, 52, 60, player.emoji, 0, 0, -120)
            else
                
            end
        end
    end
end
addEventHandler("onClientRender", root, drawEmojis)


addEvent("onClientPlayerPlayEmojiHead", true)
addEventHandler("onClientPlayerPlayEmojiHead", root, function(emoji)
    for k,player in ipairs(players) do
        if (player.element == source) then
            table.remove(players, k)
        end
    end
    
    table.insert(players, {
        element = source,
        emoji = getEmojiPathByName(emoji),
        tick = getTickCount()
    })
end)

function getEmojiPathByName(name)
    --[[if (name == "lua") then
        return "gfx/lua.png"
    elseif (name == "certo") then
        return "gfx/certo.png"
    elseif (name == "pinto") then
        return "gfx/pinto.png"
    end]]

    return "gfx/" .. name .. ".png"
end