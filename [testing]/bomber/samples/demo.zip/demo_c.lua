-- client script
-- MTA:SA Deathmatch 1.0 Developer preview 2 compatible

-- Author: Ace_Gambit