gRoot = getRootElement()
gLPlayer = getLocalPlayer()
gScreenX, gScreenY = guiGetScreenSize()
gCircles = {}

function createCircle(x, y, r, g, b, a, delay, dist, instant)
	--outputChatBox(tostring(dist))
	
	if dist == nil then
		return
	end
	
	--[[
	if type(instant) ~= "boolean" then
		return
	end
	--]]
	
	for i = 1, 1024 do
		if gCircles[i] == nil then
			gCircles[i] = {}
			gCircles[i].x = x
			gCircles[i].y = y
			gCircles[i].r = r
			gCircles[i].g = g
			gCircles[i].b = b
			gCircles[i].a = a
			gCircles[i].a2 = a
			gCircles[i].d = delay
			gCircles[i].i = dist
			gCircles[i].t = getTickCount()
			gCircles[i].inst = instant
			
			--outputChatBox(tostring(gCircles[i].a)), 255, 255, 255)
			break
		end
	end
end

function onClientRenderF_direction()
	---[[ 
	local tx, ty = getWorldFromScreenPosition(gScreenX * 0.5, gScreenY * 0.5, 100)
	local cx, cy = getCameraMatrix()
	local angle = findRotation(cx, cy, tx, ty)
	local px, py = getElementPosition(gLPlayer)
	
	for index, value in pairs(gCircles) do
		if value.a < 0 then
			gCircles[index] = nil
		else
			local angle2 = findRotation(px, py, value.x, value.y)
			local realAngle = angle - angle2
			
			if realAngle < 0 then
				realAngle = realAngle + 360
			end
			
			if realAngle > 360 then
				realAngle = realAngle - 360
			end
			
			for j = -8, 8, 2 do
				local disX = (gScreenX * 0.5) + value.i * math.sin(math.rad(realAngle + j))
				local disY = (gScreenY * 0.5) - value.i * math.cos(math.rad(realAngle + j))
				
				dxDrawImage(disX - 8, disY - 8, 16, 16, "circle.png", 0, 0, 0, tocolor(value.r, value.g, value.b, value.a))
			end
			
			local t = getTickCount()
			--value.a = value.a2 - math.floor(value.a2 * (t - value.t) / value.d)
			value.a = value.a2 - math.floor(value.d * (t - value.t) / 1000)
			
			if value.inst == true then
				gCircles[index] = nil
			end
		end
	end
	--]]
end
addEventHandler("onClientRender", gRoot, onClientRenderF_direction)

function findRotation(startX, startY, targetX, targetY)	-- Doomed-Space-Marine
	local t = -math.deg(math.atan2(targetX - startX, targetY - startY))
	
	if t < 0 then
		t = t + 360
	end
	
	return t
end

function asdF(command, dir)
	createCircle(0, 0, 255, 0, 0, 255, 255, tonumber(dir))
end
addCommandHandler("asd", asdF)