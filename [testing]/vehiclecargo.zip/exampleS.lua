local function getPositionFromElementOffset(element,offX,offY,offZ)
    local m = getElementMatrix ( element )  -- Get the matrix
    local x = offX * m[1][1] + offY * m[2][1] + offZ * m[3][1] + m[4][1]  -- Apply transform
    local y = offX * m[1][2] + offY * m[2][2] + offZ * m[3][2] + m[4][2]
    local z = offX * m[1][3] + offY * m[2][3] + offZ * m[3][3] + m[4][3]
    return x, y, z                               -- Return the transformed point
end

local function testFunction1()
	local vehicleModel = 578 -- DFT-30
	local cargoPos = getVehicleCargoPlacementPosition(vehicleModel)
	--outputChatBox("[" .. vehicleModel .. "]: x = " .. cargoPos.x .. " ; y = " .. cargoPos.y .. " ; z = " .. cargoPos.z)
	
	for k, vehicle in pairs(getElementsByType("vehicle",root,true)) do
		if getElementModel(vehicle) == vehicleModel then
			if cargoPos then
				--	min pos, max pos, loop step
				for iX = -0.8, 0.8, 0.8 do
					for iY = -3, 4, 0.65 do
						for iZ = 0, 0.9, 0.3 do
							local x, y, z = getPositionFromElementOffset(vehicle,cargoPos.x+iX, cargoPos.y-iY, cargoPos.z+iZ)
							local vehicleObject = createObject(1463, x, y, z, 0, 0, 0)
							setElementCollisionsEnabled(vehicleObject, false)
							setObjectScale(vehicleObject, 0.4)
							
							attachElements(vehicleObject, vehicle, cargoPos.x+iX, cargoPos.y-iY, cargoPos.z+iZ)
						end
					end
				end
			end
		end
	end
end
testFunction1()

local function testFunction2()
	local vehicleObject
	if not isElement(vehicleObject) then
		local cargoPos = getVehicleCargoPlacementPosition(source)
		if cargoPos then
			local x, y, z = getPositionFromElementOffset(source,cargoPos.x, cargoPos.y, cargoPos.z+0.285)
			local vehicleObject = createObject(1271, x, y, z, 0, 0, 0)
			setElementCollisionsEnabled(vehicleObject, false)
			setObjectScale(vehicleObject, 1.5)
			attachElements(vehicleObject, source, cargoPos.x, cargoPos.y, cargoPos.z+0.285)
			-- +value on Z because of the object scaling --> the object doesn't collide with the vehicle
			
			addEventHandler("onVehicleExit", source, 
				function()
					if isElement(vehicleObject) then
						destroyElement(vehicleObject)
						vehicleObject = nil
					end
				end
			)
		end
	end
end
addEventHandler("onVehicleEnter", root, testFunction2)

local function testFunction3()
	local vehicleName = "Bobcat"
	local cargoPos = getVehicleCargoPlacementPosition(vehicleName)
	
	for k, vehicle in pairs(getElementsByType("vehicle",root,true)) do
		if getVehicleName(vehicle) == vehicleName then
			if cargoPos then
				--	min pos, max pos, loop step
				for iX = -0.5, 0.5, 1 do
					for iY = -0.6, 1.8, 1.3 do
						local x, y, z = getPositionFromElementOffset(vehicle,cargoPos.x+iX, cargoPos.y-iY, cargoPos.z)
						local vehicleObject = createObject(1463, x, y, z, 0, 0, 0)
						setElementCollisionsEnabled(vehicleObject, false)
						setObjectScale(vehicleObject, 0.375)
						
						attachElements(vehicleObject, vehicle, cargoPos.x+iX, cargoPos.y-iY, cargoPos.z)
					end
				end
			end
		end
	end
end
testFunction3()

function freeMyVehiclesCargoPlace(player)
    local vehicle = getPedOccupiedVehicle(player)
    if (vehicle and getVehicleController(vehicle) == player) then
        local wasChanged = setVehicleCargoSpaceFree(vehicle)
        if (wasChanged) then
            outputChatBox("Vehicle's cargo space is now empty!", player, 0, 255, 0)
        else
            outputChatBox("Vehicle's cargo space remained the same.", player, 255, 255, 0)
        end
    end
end
addCommandHandler("cargospace", freeMyVehiclesCargoPlace)