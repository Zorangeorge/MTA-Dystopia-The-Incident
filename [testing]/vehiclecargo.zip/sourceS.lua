function setVehicleCargoSpaceFree(vehicle)
	if vehicle and isElement(vehicle) and getElementType(vehicle) == "vehicle" then
		local model = getElementModel(vehicle)
		if vehicleCargoPosition[model] then
			local var1, var2 = getVehicleVariant(vehicle)
			
			if vehicleCargoPosition[model].removeVariants then
				for _, variants in pairs(vehicleCargoPosition[model].removeVariants) do
					if variants == var1 or variants == var2 then
						setVehicleVariant(vehicle, 255, 255)
						return true
					end
				end
			end
			
			if vehicleCargoPosition[model].addVariants then
				for _, variants in pairs(vehicleCargoPosition[model].addVariants) do
					if variants ~= var1 then
						setVehicleVariant(vehicle, variants, var2)
						return true
					elseif variants ~= var2 then
						setVehicleVariant(vehicle, var1, variants)
					end
				end
			end
		end
	end
	return false
end