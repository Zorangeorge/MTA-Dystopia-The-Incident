--------------------------------------------------------
--		 These are positions for default vehicle models,
-- NOTE: you may need to adjust the positions depending
--		 on your custom vehicle model, if you have any!
--------------------------------------------------------

vehicleCargoPosition = {
-- Vehicle model, X offset, Y offset, Z offset

	-- HELICOPTERS
	[548] = {x = 0, y = 1, z = -1.65}, -- Cargobob
	[563] = {x = 0, y = 0, z = -0.4}, -- Raindance
	-- BOATS
	[472] = {x = 0, y = 1.9, z = 0.125}, -- Coastguard
	[473] = {x = 0, y = -0.75, z = 0.5}, -- Dinghy
	[595] = {x = 0, y = -1, z = -0.3}, -- Launch
	[484] = {x = 0, y = -2.75, z = 0.825}, -- Marquis
	[430] = {x = 0, y = -1.3, z = 0.125}, -- Predator
	[453] = {x = 0, y = -2.5, z = 0.225}, -- Reefer
	[452] = {x = 0, y = 1.65, z = 0.475}, -- Speeder
	[446] = {x = 0, y = -0.4, z = 0.81}, -- Squalo
	[454] = {x = -0.6, y = -0.8, z = 2.855}, -- Tropic
	-- CARS
	[600] = {x = 0, y = -1.6, z = 0, removeVariants = {0, 1}}, -- Picador
	[552] = {x = 0, y = -1.25, z = 0.185, removeVariants = {0, 1}}, -- Utility Van
	[416] = {x = 0, y = -1.75, z = -0.175}, -- Ambulance
	[433] = {x = 0, y = -2, z = 0.225, removeVariants = {0, 1}}, -- Barracks
	[427] = {x = 0, y = -1.6, z = -0.075}, -- Enforcer
	[490] = {x = 0, y = -2, z = 0}, -- FBI Rancher
	[470] = {x = 0, y = -2.05, z = 0.14, removeVariants = {0, 1, 2}}, -- Patriot
	[599] = {x = 0, y = -1.6, z = 0}, -- Police Ranger
	[428] = {x = 0, y = -1.25, z = 0}, -- Securicar (Security Van)
	[499] = {x = 0, y = -1.8, z = 0}, -- Benson
	-- Boxvilles always have boxes in their cargo space, could be changed via model replace
	[609] = {x = 0, y = -1.3, z = -0.175}, -- Black Boxville
	[498] = {x = 0, y = -1.3, z = -0.175}, -- Boxville
	[578] = {x = 0, y = -1.5, z = -0.15}, -- DFT-30
	[406] = {x = 0, y = -2, z = 0.5}, -- Dumper
	[455] = {x = 0, y = -2.25, z = 0.2, removeVariants = {0, 1, 2}}, -- Flatbed
	[414] = {x = 0, y = -1.6, z = 0}, -- Mule
	[456] = {x = 0, y = -1.6, z = 0.15}, -- Yankee
	[459] = {x = 0, y = -1, z = -0.13, removeVariants = {0}}, -- Berkley's RC Van
	[422] = {x = 0, y = -1.35, z = -0.15, removeVariants = {0, 1}}, -- Bobcat
	[482] = {x = 0, y = -1.25, z = -0.375}, -- Burrito
	[605] = {x = 0, y = -1.5, z = -0.1, removeVariants = {0, 1, 2, 3, 4}}, -- Damaged Sadler
	[530] = {x = 0, y = 0.6, z = 0.06}, -- Forklift
	[418] = {x = 0, y = -1.75, z = -0.325}, -- Moonbeam
	[582] = {x = 0, y = -1.75, z = -0.35}, -- News Van
	[413] = {x = 0, y = -1, z = -0.13, removeVariants = {0}}, -- Pony
	[440] = {x = 0, y = -1.25, z = -0.275}, -- Rumpo
	[543] = {x = 0, y = -1.5, z = -0.1, removeVariants = {0, 1, 2, 3, 4}}, -- Sadler
	[478] = {x = 0, y = -1.5, z = 0.1, removeVariants = {0, 1, 2}}, -- Walton
	[554] = {x = 0, y = -1.75, z = 0}, -- Yosemite
	[579] = {x = 0, y = -2.15, z = 0.35}, -- Huntley
	[400] = {x = 0, y = -1.7, z = 0}, -- Landstalker
	-- removeVariants --> addVariants, makes the roof rack visible
	[404] = {x = 0, y = -1.425, z = 1.1, addVariants = {0}}, -- Perennial (rooftop for roof rack variant)
	[489] = {x = 0, y = -1.6, z = 0}, -- Rancher
	[505] = {x = 0, y = -1.6, z = 0}, -- Rancher Lure
	[479] = {x = 0, y = -2.05, z = 0}, -- Regina
	[442] = {x = 0, y = -1.4, z = 0.1, removeVariants = {0, 1, 2}}, -- Romero
	[458] = {x = 0, y = -2.1, z = -0.05}, -- Solair
	[607] = {x = 0, y = 0, z = -0.2, removeVariants = {0, 1, 2}}, -- Baggage Trailer
	[590] = {x = 0, y = 0, z = -1.1}, -- Box Freight
	[569] = {x = 0, y = 0, z = -0.925}, -- Flat Freight
	[457] = {x = 0, y = -1, z = -0.025, removeVariants = {0, 1, 2, 3, 4, 5}}, -- Caddy
	[495] = {x = 0, y = -1.3, z = -0.025}, -- Sandking
}

-- This function works with vehicle names (e.g. Boxville), vehicle model IDs (e.g. 404) and vehicle elements.
function getVehicleCargoPlacementPosition(vehicle)
	if not isElement(vehicle) then
		if type(vehicle) == "string" then
			local vehicleModelFromName = getVehicleModelFromName(vehicle)
			if vehicleCargoPosition[vehicleModelFromName] then
				return vehicleCargoPosition[vehicleModelFromName]
			end
		end
		
		if type(vehicle) == "number" then
			if vehicleCargoPosition[vehicle] then
				return vehicleCargoPosition[vehicle]
			end
		end
	else
		local vehicleModel = getElementModel(vehicle)
		if vehicleCargoPosition[vehicleModel] then
			return vehicleCargoPosition[vehicleModel]
		end
	end
	return false
end