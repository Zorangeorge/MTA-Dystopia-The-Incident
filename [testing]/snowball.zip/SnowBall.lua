function SnowBall()
	txd = engineLoadTXD ( "SnowBall.txd" )
		engineImportTXD ( txd, 3002 )
	dff = engineLoadDFF ( "SnowBall.dff", 0 )
	engineReplaceModel ( dff, 3002)
end
setTimer ( SnowBall, 1000, 1)

addEventHandler("onClientResourceStop", getResourceRootElement(getThisResource()),
	function()
		destroyElement(txd)
		destroyElement(dff)
	end
)