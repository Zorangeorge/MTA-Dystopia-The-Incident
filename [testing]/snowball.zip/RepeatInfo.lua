-- Information about this resource & how to use it in-game.
outputChatBox ( "#1874CD[#FFFFFFSnowBalls#1874CD] #FFFF00Get a snowball by typing #EEEEFF/ball#FFFF00, And throw it like a grenade! #1874CD[#FFFFFFSnowBalls#1874CD]#FFFFFF", root, 0, 255, 0, true )
setTimer(function()
outputChatBox ( "#1874CD[#FFFFFFSnowBalls#1874CD] #FFFF00Get a snowball by typing #EEEEFF/ball#FFFF00, And throw it like a grenade! #1874CD[#FFFFFFSnowBalls#1874CD]#FFFFFF", root, 0, 255, 0, true )
end, 300000, 0)