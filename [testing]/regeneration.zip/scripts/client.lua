
local developmentSettings = {
	basicFPS = 60, -- 60 fps for starters. When developing, set this basic fps to the same value as the server.	
	developmentMode = false, -- View all the data
	
	memorySaving = false, --[[ 
		[Enable] Will save memory. >> But can cause incapability with some gamemodes (for example race). 
		[Disable] Will use more memory.
		
		When to disable? If the function `warpPedIntoVehicle` is used on players in your gamemode.
		https://wiki.multitheftauto.com/wiki/WarpPedIntoVehicle
	]]
	
}

-----------------------------------------
--[[ 
	Before you are going to change values, please keep in mind that serverside edits some of those values.
]]

local healthRegeneration = {
	
	--[[ 
		Regeneration things for the vehicle 
	]]
	
	vehicle = (function ()
		local vehicleHealthRegeneration
		
		vehicleHealthRegeneration = {
			enabled = false, 
			
			lastDamageTime = -1/0, -- infinity negative
			
			delay =  8000, -- [X milliseconds] delay before kicking in
			
			basicTimeSlice = 1000 / developmentSettings.basicFPS,  -- basic timeslice for developers
			
			status = false, -- watching/updating or not?
			
			additionalHealth = 10, -- X health per second
			
			regenerationOnBurning = false, --[[ 
				When the health of a vehicle is lower than 250, it will start burning. This setting makes health regen enabled or disabled for that scenario.
			]]
			
			watchAndUpdate = function (timeSlice) -- The magic happens here!
				local self_ = vehicleHealthRegeneration
				
				local vehicle = getPedOccupiedVehicle (localPlayer)
				if vehicle and getPedOccupiedVehicleSeat (localPlayer) == 0 and not isVehicleBlown ( vehicle ) then
					local timeNow = getTickCount()
					if timeNow > self_.lastDamageTime + self_.delay then
						
						local currentHealth = getElementHealth(vehicle)
						if developmentSettings.regenerationOnBurning or currentHealth > 250 then
							local maxHealth = 1000
							
							local additionalHealthMultiplier = self_.basicTimeSlice / timeSlice -- calculate the new health based on the time between the frames.
							local currentAdditionalHealth = self_.additionalHealth / 100 * additionalHealthMultiplier
							
							if currentHealth < maxHealth then
								setElementHealth(vehicle, math.min(currentHealth + currentAdditionalHealth, maxHealth))
							else
								self_:stopWatchProcess ()
							end
						else
							self_:stopWatchProcess ()
						end
					end
				else
					self_:stopWatchProcess ()
				end
			end,
			registerDamage = {
				handler = {
					status = false,					
				},
				onDamage = function ()
					vehicleHealthRegeneration.lastDamageTime = getTickCount()
					vehicleHealthRegeneration:startWatchProcess()
				end
			}
		}
		
		-- functions for managing which vehicle should attach onClientVehicleDamage (Currently disabled, but you can enable it for memory saving, see developmentSettings on top)
		function vehicleHealthRegeneration.registerDamage.handler:add(vehicle)
			if not self.status then
			
				if self.lastVehicle and isElement(self.lastVehicle) then
					removeEventHandler("onClientVehicleDamage", self.lastVehicle, vehicleHealthRegeneration.registerDamage.onDamage)
				end
				self.lastVehicle = nil
				
				if not isVehicleBlown ( vehicle ) then
					addEventHandler("onClientVehicleDamage", vehicle, vehicleHealthRegeneration.registerDamage.onDamage, false)
					
					self.lastVehicle = vehicle
					self.status = true
					return true
				end
			end
			return false
		end
		
		function vehicleHealthRegeneration.registerDamage.handler:remove (vehicle)
			if self.status then
				removeEventHandler("onClientVehicleDamage", vehicle, vehicleHealthRegeneration.registerDamage.onDamage)
				self.lastVehicle = nil
				self.status = false
				return true
			end
			return false
		end
		
		-- main functions
		function vehicleHealthRegeneration:isDamaged ()
			local vehicle = getPedOccupiedVehicle (localPlayer)
			if vehicle and getPedOccupiedVehicleSeat (localPlayer) == 0 then
				local currentHealth = getElementHealth(vehicle)
				return currentHealth < 1000
			end
			return false
		end
		
		function vehicleHealthRegeneration:startWatchProcess ()
			if not self.status then
				addEventHandler("onClientPreRender", root, self.watchAndUpdate)
				self.status = true
			end
		end

		function vehicleHealthRegeneration:stopWatchProcess ()
			if self.status then
				removeEventHandler("onClientPreRender", root, self.watchAndUpdate)
				self.status = false
			end
		end
		return vehicleHealthRegeneration
	end)(),
	
	------------------------------------------------------------------------------
	
	--[[ 
		Regeneration things for the player. 
	]]
	
	player = (function ()
		local playerHealthRegeneration
		
		local getPedMaxHealth = function (ped)
			-- Grab his player health stat.
			local stat = getPedStat(ped, 24)

			-- Do a linear interpolation to get how many health a ped can have.
			-- Assumes: 100 health = 569 stat, 200 health = 1000 stat.
			local maxhealth = 100 + (stat - 569) / 4.31

			-- Return the max health. Make sure it can't be below 1
			return math.max(1, maxhealth)
		end 
		-- Documentation/source of this function: https://wiki.multitheftauto.com/wiki/GetPedMaxHealth
		
		playerHealthRegeneration = {
			enabled = false,
		
			lastDamageTime = -1/0, -- infinity negative
			
			delay =  8000, -- [X milliseconds] delay before kicking in
			
			basicTimeSlice = 1000 / developmentSettings.basicFPS,  -- basic timeslice for developers
			
			status = false, -- watching/updating or not?
			
			additionalHealth = 5, -- X health per second
			
			watchAndUpdate = function (timeSlice) -- The magic happens here!
				local self_ = playerHealthRegeneration
				
				local timeNow = getTickCount()
				if timeNow > self_.lastDamageTime + self_.delay then
					
					local currentHealth = getElementHealth(localPlayer)
					local maxHealth = getPedMaxHealth(localPlayer)
					
					local additionalHealthMultiplier = self_.basicTimeSlice / timeSlice -- calculate the new health based on the time between the frames.
					local currentAdditionalHealth = self_.additionalHealth / 100 * additionalHealthMultiplier
					
					if currentHealth < maxHealth then
						setElementHealth(localPlayer, math.min(currentHealth + currentAdditionalHealth, maxHealth))
					else
						self_:stopWatchProcess ()
					end
				end
			end
		}
		
		-- main functions
		function playerHealthRegeneration:isDamaged ()
			local currentHealth = getElementHealth(localPlayer)
			local maxHealth = getPedMaxHealth(localPlayer)
			return currentHealth < maxHealth
		end
		
		function playerHealthRegeneration:startWatchProcess ()
			
			if not self.status then
				addEventHandler("onClientPreRender", root, self.watchAndUpdate)
				self.status = true
			end
		end

		function playerHealthRegeneration:stopWatchProcess ()
			if self.status then
				removeEventHandler("onClientPreRender", root, self.watchAndUpdate)
				self.status = false
			end
		end
		
		return playerHealthRegeneration
	end)()
}







do -- (Re)starting the script? It still works.
	addEvent("health-regeneration-settings--receive", true)
	
	-- receive the settings here!
	local function receiveSettings (settingsContainer)
		removeEventHandler("health-regeneration-settings--receive", resourceRoot, receiveSettings, false)
		receiveSettings = nil
		
		-- Apply the settings from serverside on clientside
		for i=1, #settingsContainer do
			local settingsGroup = settingsContainer[i]
			local settingsGroupType = settingsGroup.type
			local settings = settingsGroup.settings
			for j=1, #settings do
				local setting = settings[j]
				healthRegeneration[settingsGroupType][setting.key] = setting.value
			end
		end
		
		
		-- stop both regeneration types when you die
		addEventHandler("onClientPlayerWasted", localPlayer, 
		function ()
			if healthRegeneration.player.enabled then
				healthRegeneration.player:stopWatchProcess ()
			end
			if healthRegeneration.vehicle.enabled then
				healthRegeneration.vehicle:stopWatchProcess ()
			end
		end, false)

		
		-- enable health regeneration for players
		if healthRegeneration.player.enabled then
			if healthRegeneration.player:isDamaged() then
				healthRegeneration.player:startWatchProcess()
			end
			
			addEventHandler("onClientPlayerDamage", localPlayer, 
			function ()
				healthRegeneration.player.lastDamageTime = getTickCount()
				healthRegeneration.player:startWatchProcess()
			end, false)
			
			addEventHandler("onClientPlayerSpawn", localPlayer, 
			function ()
				healthRegeneration.player:stopWatchProcess ()
			end, false)
		end
		
		
		
		-- enable health regeneration for vehicles with YOU as driver
		if healthRegeneration.vehicle.enabled then
			local vehicle = getPedOccupiedVehicle (localPlayer)
			if vehicle and getPedOccupiedVehicleSeat (localPlayer) == 0 then
			
				if healthRegeneration.vehicle:isDamaged() then
					healthRegeneration.vehicle:startWatchProcess()
				end
			
				if developmentSettings.memorySaving then
					healthRegeneration.vehicle.registerDamage.handler:add(vehicle)
				end
			end
			
			if developmentSettings.memorySaving then -- saving memory?
				addEventHandler("onClientPlayerVehicleEnter", localPlayer, 
				function (vehicle, seat)
					if seat == 0 then
						healthRegeneration.vehicle.registerDamage.handler:add(vehicle)
						
						if healthRegeneration.vehicle:isDamaged () then
							healthRegeneration.vehicle.lastDamageTime = getTickCount() -- No cheating by getting in and out of the vehicle
							healthRegeneration.vehicle:startWatchProcess ()
						end
					end
				end, false)

				addEventHandler("onClientPlayerVehicleExit", localPlayer, 
				function (vehicle, seat)
					if seat == 0 then
						healthRegeneration.vehicle.registerDamage.handler:remove(vehicle)
						healthRegeneration.vehicle:stopWatchProcess ()
					end
				end, false)
			else -- or more memory use and less bugs?
			
				addEventHandler("onClientPlayerVehicleEnter", localPlayer, 
				function (vehicle, seat)
					if seat == 0 and healthRegeneration.vehicle:isDamaged () then
						healthRegeneration.vehicle.lastDamageTime = getTickCount() -- No cheating by getting in and out of the vehicle
						healthRegeneration.vehicle:startWatchProcess ()
					end
				end, false)
				
				addEventHandler("onClientPlayerVehicleExit", localPlayer, 
				function (vehicle, seat)
					if seat == 0 then
						healthRegeneration.vehicle:stopWatchProcess ()
					end
				end, false)
					
				addEventHandler("onClientVehicleDamage", root, 
				function ()
					if source == getPedOccupiedVehicle(localPlayer) and getPedOccupiedVehicleSeat (localPlayer) == 0 and not isVehicleBlown ( source ) then
						local vehicleHealthRegeneration = healthRegeneration.vehicle
						vehicleHealthRegeneration.lastDamageTime = getTickCount()
						vehicleHealthRegeneration:startWatchProcess()
					end
				end)	
			end
		end
		
		
	end
	
	
	local function resourceStartFunction () 
		-- clean up
		removeEventHandler("onClientResourceStart", resourceRoot, resourceStartFunction)
		resourceStartFunction = nil
		
		-- get the settings!
		addEventHandler("health-regeneration-settings--receive", resourceRoot, receiveSettings, false)
		triggerServerEvent("health-regeneration-settings--request", resourceRoot)
		
	end
	addEventHandler("onClientResourceStart", resourceRoot, resourceStartFunction, false)
	
end

-- debug the whole thing!
if developmentSettings.developmentMode then
	addEventHandler("onClientRender", root,
	function ()
		dxDrawText(inspect(healthRegeneration), 20, 200) -- with just one line of output! Whohohoho!
	end)
end