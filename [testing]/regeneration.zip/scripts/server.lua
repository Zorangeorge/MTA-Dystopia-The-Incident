local settingsContainer
do 
	local _outputDebugString = outputDebugString
	local outputDebugString = function  (...)
		local arg = {...}
		arg[1] = "[settings validation] " ..  arg[1]
		_outputDebugString(unpack(arg), 0, 0, 0, 255)
	end
	
	settingsContainer = {
		{
			type = "vehicle",
			settings = {
				{key = "enabled", value = string.lower(tostring(get ("vehicleRegenerationEnabled" ))) == "true"},
				{
					key = "additionalHealth", 
					value = (function () 
						local settingName = "vehicleRegenerationValue"
						local defaultValue = 10
						local value = tonumber(get(settingName))
						if not value then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be filled in. Reset to: " .. tostring(value))
						elseif value < 0 then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be higher than 0. Reset to: " .. tostring(value))
						end
						
						return value
					end)()
				},
				{	key = "delay", 
					value = (function () 
						local settingName = "vehicleRegenerationDelay"
						local defaultValue = 8000
						local value = tonumber(get(settingName))
						if not value then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be filled in. Reset to: " .. tostring(value))
						elseif value < 0 then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be higher than 0. Reset to: " .. tostring(value))
						end
						
						return value
					end)()
				},
				{key = "regenerationOnBurning", value = string.lower(tostring(get ("vehicleRegenerationOnBurning" ))) == "true"}
			}
		},
		{
			type = "player",
			settings = {
				{key = "enabled", value = string.lower(tostring(get ("playerRegenerationEnabled" ))) == "true"},
				{
					key = "additionalHealth", 
					value = (function () 
						local settingName = "playerRegenerationValue"
						local defaultValue = 5
						local value = tonumber(get(settingName))
						if not value then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be filled in. Reset to: " .. tostring(value))
						elseif value < 0 then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be higher than 0. Reset to: " .. tostring(value))
						end
						return value
					end)()
				},
				{
					key = "delay",
					value = (function () 
						local settingName = "playerRegenerationDelay"
						local defaultValue = 8000
						local value = tonumber(get(settingName))
						if not value then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be filled in. Reset to: " .. tostring(value))
						elseif value < 0 then
							value = defaultValue
							outputDebugString(tostring(settingName) .. " must be higher than 0. Reset to: " .. tostring(value))
						end
						
						return value
					end)()
				},
			}
		}
	}
end



addEvent("health-regeneration-settings--request", true)
addEventHandler("health-regeneration-settings--request", resourceRoot, 
function ()
	-- send the settings to the client
	triggerClientEvent(client, "health-regeneration-settings--receive", resourceRoot, settingsContainer)
end)