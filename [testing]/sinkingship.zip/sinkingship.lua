players = getElementsByType ( "player" )
for k,v in pairs(players) do
	r = 10
	angle = math.random(0, 359.99) --random angle between 0 and 359.99
	centerX = 515
	centerY = -2466.5
	spawnX = r*math.cos(angle) + centerX --circle trig math
	spawnY = r*math.sin(angle) + centerY --circle trig math
	spawnAngle = 360 - math.deg( math.atan2 ( (600 - spawnX), (-2500 - spawnY) ) )
	spawnPlayer ( v, spawnX, spawnY, 1, spawnAngle )	
end

setWeather ( 8 )

dummy = createObject ( 3106, 600, -2500, -10.000000, 0, 0.000000, math.deg(45.000000) )
height = 0
ship = {}
ship[1] = createObject ( 9585, 594.024994, -2507.973343, 16.240688, 0.000000, 0.000000, 0.000000 )
ship[2] = createObject ( 9586, 592.341562, -2507.970338, 26.287117, 0.000000, 0.000000, 0.000000 )
ship[3] = createObject ( 9584, 519.213539, -2507.960570, 35.307964, 0.000000, 0.000000, 0.000000 )
ship[4] = createObject ( 9761, 593.563006, -2507.960257, 36.307343, 0.000000, 0.000000, 0.000000 )
ship[5] = createObject ( 9590, 600.276580, -2507.975836, 17.972404, 0.000000, 0.000000, 0.000000 )
ship[6] = createObject ( 9588, 599.583616, -2507.992563, 16.842083, 0.000000, 0.000000, 0.000000 )
ship[7] = createObject ( 9587, 602.710941, -2507.997527, 32.860355, 0.000000, 0.000000, 0.000000 )
ship[8] = createObject ( 9698, 531.703178, -2509.137287, 38.210091, 0.000000, 0.000000, 0.000000 )
ship[9] = createObject ( 9821, 530.456947, -2505.668294, 33.931679, 0.000000, 0.000000, 0.000000 )
ship[10] = createObject ( 9820, 530.690063, -2507.855123, 42.203083, 0.000000, 0.000000, 0.000000 )
ship[11] = createObject ( 9818, 533.328865, -2508.044811, 43.003025, 0.000000, 0.000000, 0.000000 )
ship[12] = createObject ( 9819, 533.565224, -2501.948847, 42.212730, 0.000000, 0.000000, 0.000000 )
ship[13] = createObject ( 1215, 528.850662, -2504.785474, 63.687782, 0.000000, 0.000000, 0.000000 )
ship[14] = createObject ( 1215, 528.831230, -2512.129888, 63.678757, 0.000000, 0.000000, 0.000000 )
ship[15] = createObject ( 1215, 535.183273, -2492.588416, 42.097248, 0.000000, 0.000000, 0.000000 )
ship[16] = createObject ( 1215, 528.183350, -2492.613416, 42.097248, 0.000000, 0.000000, 0.000000 )
ship[17] = createObject ( 1215, 535.143707, -2524.527042, 42.097248, 0.000000, 0.000000, 0.000000 )
ship[18] = createObject ( 1215, 528.293762, -2524.577042, 42.097248, 0.000000, 0.000000, 0.000000 )
ship[19] = createObject ( 1215, 535.307335, -2524.785160, 34.588375, 0.000000, 0.000000, 0.000000 )
ship[20] = createObject ( 1215, 535.336227, -2592.647525, 34.588486, 0.000000, 0.000000, 0.000000 )
ship[21] = createObject ( 1215, 509.676369, -2514.116117, 36.259785, 0.000000, 0.000000, 0.000000 )
ship[22] = createObject ( 1215, 509.676369, -2501.816118, 36.259785, 0.000000, 0.000000, 0.000000 )
ship[23] = createObject ( 1215, 481.725655, -2507.948462, 27.232681, 0.000000, 0.000000, 0.000000 )
ship[24] = createObject ( 1215, 496.538727, -2507.996759, 28.309702, 0.000000, 0.000000, 0.000000 )
ship[25] = createObject ( 2780, 515.756454, -2511.287848, 47.607914, 0.000000, 0.000000, 0.000000 )
ship[26] = createObject ( 2780, 515.756454, -2504.787860, 47.607914, 0.000000, 0.000000, 0.000000 )
ship[27] = createObject ( 2780, 524.303802, -2503.224801, 29.735508, 0.000000, 0.000000, 0.000000 )
ship[28] = createObject ( 2780, 560.012344, -2498.232987, 10.054436, 0.000000, 0.000000, 0.000000 )
ship[29] = createObject ( 2780, 640.127350, -2496.485858, 10.376801, 0.000000, 0.000000, 0.000000 )

attachElements ( ship[1], dummy, -6.024994, -7.973343, 16.240688+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[2], dummy, -8.341562, -7.970338, 26.287117+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[3], dummy, -81.213539, -7.960570, 35.307964+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[4], dummy, -7.563006, -7.960257, 36.307343+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[5], dummy, 0.276580, -7.975836, 17.972404+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[6], dummy, -0.416384, -7.992563, 16.842083+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[7], dummy, 2.710941, -7.997527, 32.860355+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[8], dummy, -69.703178, -9.137287, 38.210091+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[9], dummy, -70.456947, -5.668294, 33.931679+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[10], dummy, -70.690063, -7.855123, 42.203083+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[11], dummy, -66.328865, -8.044811, 43.003025+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[12], dummy, -66.565224, -1.948847, 42.212730+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[13], dummy, -72.850662, -4.785474, 63.687782+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[14], dummy, -72.831230, -12.129888, 63.678757+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[15], dummy, -65.183273, 8.588416, 42.097248+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[16], dummy, -72.183350, 8.613416, 42.097248+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[17], dummy, -65.143707, -24.527042, 42.097248+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[18], dummy, -72.293762, -24.577042, 42.097248+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[19], dummy, -65.307335, -24.785160, 34.588375+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[20], dummy, -65.336227, 8.647525, 34.588486+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[21], dummy, -91.676369, -14.116117, 36.259785+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[22], dummy, -91.676369, -1.816118, 36.259785+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[23], dummy, -119.725655, -7.948462, 27.232681+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[24], dummy, 104.538727, -7.996759, 28.309702+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[25], dummy, -85.756454, -11.287848, 47.607914+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[26], dummy, -85.756454, -4.787860, 47.607914+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[27], dummy, -76.303802, -3.224801, 29.735508+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[28], dummy, -40.012344, 2.232987, 10.054436+height, 0.000000, 0.000000, 0.000000 )
attachElements ( ship[29], dummy, 40.127350, 4.485858, 10.376801+height, 0.000000, 0.000000, 0.000000 )

for k,v in pairs(ship) do -- Make all the objects child of 'dummy'
	setElementParent ( v, dummy )
end

function mapLoad (  )
	setWaveHeight ( 0.7 )
end
addEventHandler ( "onResourceStart", getResourceRootElement(getThisResource()),mapLoad )

function sinkit (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 5000, x, y, z-5, 0, 0, 0 )
	setTimer ( startTiltA, 5000, 1 )
end
addCommandHandler ( "sink", sinkit )

function startTiltA (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 10000, x, y, z-10, 0, 10, 0 )
	setTimer ( startTiltB, 10000, 1 )
end

function startTiltB (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 10000, x, y, z-5, 0, 20, 0 )
	setTimer ( startTiltC, 10000, 1 )
end

function startTiltC (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 15000, x, y, z, 0, 20, 0 )
	setTimer ( startTiltD, 15000, 1 )
end

function startTiltD (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 5000, x, y, z-10, 0, 15, 0 )
	setTimer ( startTiltE, 5000, 1 )
end

function startTiltE (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 10000, x, y, z-50, 0, 15, 0 )
	setTimer ( startTiltF, 10000, 1 )
end

function startTiltF (  )
	local x,y,z = getElementPosition ( dummy )
	moveObject ( dummy, 5000, x, y, z-40, 0, 10, 0 )
end