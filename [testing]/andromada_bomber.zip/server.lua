addEvent ( "onClientAirStrike", true );
addEventHandler ( "onClientAirStrike", root, function ( position )
      
        triggerClientEvent ( root, "onPlayerAirStrike", root, position, source );
        
end );