-- Check if the player is in an andromada when the resource starts
addEventHandler ( "onClientResourceStart", resourceRoot, function ( )
	-- Check to see if the player is in an Andromada, and is piloting it 
	if ( localPlayer.vehicle 
	and localPlayer.vehicle.name == "Andromada"
	and localPlayer.vehicle.controller == localPlayer ) then 
		
		-- Set a timer to create the bombs
		bombTicker = setTimer ( onBombCheckTick, 200, 0 );
	
	end 
end );

-- Detect when a player begins piloting an andromada
addEventHandler ( "onClientPlayerVehicleEnter", root, function ( vehicle, seat )
	-- Check to see if the player is in an Andromada, and is piloting it 
	if ( source == localPlayer and vehicle.name == 'Andromada' and seat == 0 ) then 
		
		-- Does the bombing timer already exist?
		if ( isTimer ( bombTicker ) ) then 
			-- Yes. Kill it
			killTimer ( bombTicker )
		end 
		
		-- Create the bombing timer
		bombTicker = setTimer ( onBombCheckTick, 200, 0 );
		
	end 
end );

-- Kill the timer when a player exists the vehicle
addEventHandler ( "onClientPlayerVehicleExit", root, function ( )
	-- Does the bombing timer exist?
	if ( isTimer ( bombTicker ) ) then 
		-- Yes, kill it 
		killTimer ( bombTicker );
	end
end );

function onBombCheckTick( ) 
	
	-- Check to see if the player is in an Andromada, and is piloting it 
	if ( localPlayer.vehicle 
	and localPlayer.vehicle.name == "Andromada"
	and localPlayer.vehicle.controller == localPlayer ) then 
	    
		-- Are they trying to bomb?
	    if ( getKeyState ( "mouse1" ) ) then 
			
			-- Get their position 
			local x, y, z = getElementPosition ( localPlayer );
			
			-- Get the ground position, belowt hem 
			local ground = getGroundPosition ( x, y, z ) + 2;
			
			-- Are they 10 meters off the groud?
			if ( ( z - ground ) < 10 ) then -- Check to see if they're flying
				return outputChatBox ( "You need to be at least 10 meters off the ground.", 255, 0, 0 );
			end
			
			-- Everything's good, send the request to the server
			triggerServerEvent ( "onClientAirStrike", localPlayer,  { x, y, z } );
		
	    end
	end 
end


addEvent ( "onPlayerAirStrike", true );
addEventHandler ( "onPlayerAirStrike", root, function ( position, creator )
	
	--[[
	
		Event: onPlayerAirStrike
		Called: When the server receives the "onClientAirStrike" event, it forwards to this to sync with all players
		---------------------
		@arg	position	table		The X, Y, Z coordinates of the vehicle dropping the bomb
		@arg	creator		players		The player element that is creating the bomb (Currently not used, but if someone wants to check something, it's here to use)
	
	]]

	
	-- Calculate all positions 
	local x, y, z = unpack ( position );
	local ground = getGroundPosition ( x, y, z ) + 2;
	local dist = ( z - ground );
	
	-- Create the bomb object
	local o = createObject ( 2918, x, y, z - 3 );
	
	-- Calculate the time until it hits the ground 
	local time = ( ( 2*dist ) / 9.8 ) * 100
		
	-- Move it to the ground 
	moveObject ( o, time, x, y, ground, 0, 0, 0  )
	
	-- Wait for it to hit the ground 
	setTimer ( function ( o )
		-- Destroy the bomb and creat an explosion 
	    local x, y, z = getElementPosition ( o );
	    local z = z - 1
	    destroyElement ( o );
	    createExplosion ( x, y, z, 2 );
	end, time, 1, o );
	
end );