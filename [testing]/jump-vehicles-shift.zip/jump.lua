function Init()
    bindKey ("lshift", "down", start)
end
addEventHandler("onClientResourceStart", resourceRoot, Init)
 
function jump()
	local vehicle = getPedOccupiedVehicle(localPlayer)
	local sx, sy, sz = getElementVelocity(vehicle)
	setElementVelocity(vehicle, sx, sy, sz+0.33)
end

function start()
	local vehicle = getPedOccupiedVehicle(localPlayer)
    if vehicle and isPedInVehicle(localPlayer) and getVehicleController(vehicle) == localPlayer then
        local vType = getVehicleType(vehicle)
			if vType == "Plane" or vType == "Helicopter" then return end
			jump()
		end
end