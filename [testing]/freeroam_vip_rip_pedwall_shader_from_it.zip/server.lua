settings = {
	aclGroup = "VIP Group",
}

function loginFunc(_,acc)
	local accountName = getAccountName(acc)
	if not aclGetGroup(settings.aclGroup) then
		if aclCreateGroup(settings.aclGroup) then
			outputChatBox(settings.aclGroup.." #FFFFFFgroup created!",root,255,0,0,true)
		else
			outputChatBox(settings.aclGroup.." #FFFFFFgroup can't found! Please create it.",root,255,0,0,true)
		end
	end
	if isObjectInACLGroup("user."..accountName,aclGetGroup(settings.aclGroup)) then
		triggerClientEvent(source,"vipSystem:createVIPPanel",source)
	end
end
addEvent("vipSystem:onPlayerLogin",true)
addEventHandler("vipSystem:onPlayerLogin",root,loginFunc)
addEventHandler("onPlayerLogin",root,loginFunc)

setTimer(function()
	for i,pl in pairs(getElementsByType("player")) do
		local acc = getPlayerAccount(pl)
		if not isGuestAccount(acc) then
			triggerEvent("vipSystem:onPlayerLogin",pl,_,acc)
		end
	end
end,1000,1)

addEventHandler("onPlayerLogout",root,function() triggerClientEvent(source,"vipSystem:destroyVIPPanel",source) end)

addEvent("vipSystem:setPlayerVisible",true)
addEventHandler("vipSystem:setPlayerVisible",root,function(state)
	if state then
		setElementAlpha(source,0)
		setPlayerNametagShowing(source,false)
	else
		setElementAlpha(source,255)
		setPlayerNametagShowing(source,true)
	end
end)

addEvent("vipSystem:setVehicleVisible",true)
addEventHandler("vipSystem:setVehicleVisible",root,function(veh,state)
	if veh then
		if state then
			setElementAlpha(veh,0)
		else
			setElementAlpha(veh,255)
		end
	end
end)
addEvent("vipSystem:setVehicleDamage",true)
addEventHandler("vipSystem:setVehicleDamage",root,function(veh,state)
	if veh then
		setVehicleDamageProof(veh,state)
	end
end)

addEventHandler("onPlayerVehicleExit",root,function(veh,seat)
	if seat == 0 then
		setElementAlpha(veh,255)
		setVehicleDamageProof(veh,true)
	end
end)
