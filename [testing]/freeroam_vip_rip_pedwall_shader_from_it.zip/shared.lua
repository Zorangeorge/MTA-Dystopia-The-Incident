dataTable = {}
function setElementData(element,key,value)
	if not dataTable[element] then dataTable[element] = {} end
	dataTable[element][key] = value
end
function getElementData(element,key)
	return (dataTable[element] and dataTable[element][key])
end
