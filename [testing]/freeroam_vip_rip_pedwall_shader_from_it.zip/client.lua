sx,sy = guiGetScreenSize()
pg,pu = 500,325
px,py = (sx-pg)/2,(sy-pu)/2

function createVIPPAnel()
	panel = guiCreateWindow(px,py,pg,pu,"V.I.P. Window",false)
	guiSetVisible(panel,false)
	playerLabel = guiCreateLabel(15,25,pg-30,25,"◄► Player Features ◄►",false,panel)
	guiSetFont(playerLabel,"default-bold-small")
	guiLabelSetHorizontalAlign(playerLabel,"center")
	guiLabelSetVerticalAlign(playerLabel,"center")
	wallBox = guiCreateCheckBox(15,50,pg-30,25,"Wallhack",false,false,panel)
	guiSetFont(wallBox,"default-bold-small")
	deathlessBox = guiCreateCheckBox(15,75,pg-30,25,"Deathless",false,false,panel)
	guiSetFont(deathlessBox,"default-bold-small")
	invisibleBox = guiCreateCheckBox(15,100,pg-30,25,"Invisible",false,false,panel)
	guiSetFont(invisibleBox,"default-bold-small")
	megaJumpBox = guiCreateCheckBox(15,125,pg-30,25,"Mega Jump",false,false,panel)
	guiSetFont(megaJumpBox,"default-bold-small")
	
	carLabel = guiCreateLabel(15,150,pg-30,25,"◄► Vehicle Features ◄►",false,panel)
	guiSetFont(carLabel,"default-bold-small")
	guiLabelSetHorizontalAlign(carLabel,"center")
	guiLabelSetVerticalAlign(carLabel,"center")
	jumpCarBox = guiCreateCheckBox(15,175,pg-30,25,"Bouncing Vehicle (Left Shift)",false,false,panel)
	guiSetFont(jumpCarBox,"default-bold-small")
	invisibleCarBox = guiCreateCheckBox(15,200,pg-30,25,"Invisible Vehicle",false,false,panel)
	guiSetFont(invisibleCarBox,"default-bold-small")
	deathlessCarBox = guiCreateCheckBox(15,225,pg-30,25,"Deathless Vehicle",false,false,panel)
	guiSetFont(deathlessCarBox,"default-bold-small")
	flyingCarBox = guiCreateCheckBox(15,250,pg-30,25,"Flying Vehicle",false,false,panel)
	guiSetFont(flyingCarBox,"default-bold-small")
	carSwimBox = guiCreateCheckBox(15,275,pg-30,25,"Floating Vehicle",false,false,panel)
	guiSetFont(carSwimBox,"default-bold-small")

	bindKey("F7","down",bindFunc)
	
end

function bindFunc()
	guiSetVisible(panel,not guiGetVisible(panel))
	showCursor(guiGetVisible(panel))
end

addEvent("vipSystem:createVIPPanel",true)
addEventHandler("vipSystem:createVIPPanel",root,function()
	createVIPPAnel()
	outputChatBox("Press F7 to turn on V.I.P. window!",155,155,255,true)
end)

addEvent("vipSystem:destroyVIPPanel",true)
addEventHandler("vipSystem:destroyVIPPanel",root,function()
	if isElement(panel) then
		unbindKey("F7","down",bindFunc)
		showCursor(false)
		destroyElement(panel)
	end
end)

addEventHandler("onClientGUIClick",resourceRoot,function()
	if source == wallBox then
		showWall = guiCheckBoxGetSelected(wallBox)
	elseif source == deathlessBox then
		setElementData(localPlayer,"olumsuzluk",guiCheckBoxGetSelected(deathlessBox))
	elseif source == invisibleBox then
		triggerServerEvent("vipSystem:setPlayerVisible",localPlayer,guiCheckBoxGetSelected(invisibleBox))
	elseif source == megaJumpBox then
		setWorldSpecialPropertyEnabled("extrajump",guiCheckBoxGetSelected(megaJumpBox))
	elseif source == invisibleCarBox then
		local veh = getPedOccupiedVehicle(localPlayer)
		triggerServerEvent("vipSystem:setVehicleVisible",localPlayer,veh,guiCheckBoxGetSelected(invisibleCarBox))
	elseif source == deathlessCarBox then
		local veh = getPedOccupiedVehicle(localPlayer)
		triggerServerEvent("vipSystem:setVehicleDamage",localPlayer,veh,guiCheckBoxGetSelected(deathlessCarBox))
	elseif source == flyingCarBox then
		setWorldSpecialPropertyEnabled("aircars",guiCheckBoxGetSelected(flyingCarBox))
	elseif source == carSwimBox then
		setWorldSpecialPropertyEnabled("hovercars",guiCheckBoxGetSelected(carSwimBox))
	end
end)

-----------------------------------------------------------------------------------
-- OLUMSUZLUK (players-deathless)
-----------------------------------------------------------------------------------
addEventHandler("onClientPlayerDamage",localPlayer,function(attacker)
	if guiCheckBoxGetSelected(deathlessBox) then 
		return cancelEvent() 
	end
	if attacker and getElementType(attacker) == "player" and getElementData(attacker,"olumsuzluk") then 
		cancelEvent() 
	end
end)

-----------------------------------------------------------------------------------
-- ARAC ZIPLAMA (bouncing vehicle)
-----------------------------------------------------------------------------------
bindKey("lshift","down",function()
	local veh = getPedOccupiedVehicle(localPlayer)
    if veh and isPedInVehicle(localPlayer) and getVehicleController(veh) == localPlayer then
		local type = getVehicleType(veh)
		if type == "Plane" or type == "Helicopter" then return end
		if guiCheckBoxGetSelected(jumpCarBox) then
			local sx,sy,sz = getElementVelocity(veh)
			setElementVelocity(veh,sx,sy,sz+0.33)
		end
	end
end)

-----------------------------------------------------------------------------------
-- GORUNMEZ ARAC (invisible vehicle)
-----------------------------------------------------------------------------------
addEventHandler("onClientPlayerVehicleEnter",localPlayer,function(veh,seat)
	if seat == 0 then
		triggerServerEvent("vipSystem:setVehicleVisible",source,veh,guiCheckBoxGetSelected(invisibleCarBox))
		triggerServerEvent("vipSystem:setVehicleDamage",source,veh,guiCheckBoxGetSelected(deathlessCarBox))
	end
end)

-----------------------------------------------------------------------------------
-- DUVAR ARKASI GORME (wallhack)
-----------------------------------------------------------------------------------
addEventHandler("onClientResourceStart",resourceRoot,function()
	local isMRT = false
	if dxGetStatus().VideoCardNumRenderTargets > 1 then 
		isMRT = true 
		outputDebugString('pedWall: MRT in shaders enabled') 
	end
	triggerEvent("switchPedWall", resourceRoot, true, isMRT) -- default on
	addCommandHandler("sPedWall",function()
		triggerEvent("switchPedWall", resourceRoot, not pwEffectEnabled, isMRT)
	end)
end)
function switchPedWall(pwOn,isMRT)
	outputDebugString("switchPedWall: " .. tostring(pwOn)..' MRT: '..tostring(isMRT))
	if pwOn then
		enablePedWall(isMRT)
	else
		disablePedWall()
	end
end
addEvent("switchPedWall", true)
addEventHandler("switchPedWall", resourceRoot, switchPedWall)
local specularPower = 1.3
local effectMaxDistance = 50
local isPostAura = true
local scx, scy = guiGetScreenSize ()
local effectOn = nil
local myRT = nil
local myShader = nil
local isMRTEnabled = false
local wallShader = {}
local PWTimerUpdate = 110
function enablePedWall(isMRT)
	if isMRT and isPostAura then 
		myRT = dxCreateRenderTarget(scx, scy, true)
		myShader = dxCreateShader("fx/post_edge.fx")
		if not myRT or not myShader then 
			isMRTEnabled = false
			return
		else
			outputDebugString('PedWall: Enabled MRT variant')
			dxSetShaderValue(myShader, "sTex0", myRT)
			dxSetShaderValue(myShader, "sRes", scx, scy)
			isMRTEnabled = true
		end
	else
		outputDebugString('PedWall: Enabled non MRT variant')
		isMRTEnabled = false
	end
	pwEffectEnabled = true
	enablePedWallTimer(isMRTEnabled)
end

function disablePedWall()
	pwEffectEnabled = false
	disablePedWallTimer()
	if isElement(myRT) then
		destroyElement(myRT)
	end
end
function createWallEffectForPlayer(thisPlayer, isMRT)
    if not wallShader[thisPlayer] then
		if isMRT then 
			wallShader[thisPlayer] = dxCreateShader("fx/ped_wall_mrt.fx", 1, 0, true, "ped")
		else
			wallShader[thisPlayer] = dxCreateShader("fx/ped_wall.fx", 1, 0, true, "ped")
		end
		if not wallShader[thisPlayer] then return false
		else
			if myRT then
				dxSetShaderValue (wallShader[thisPlayer], "secondRT", myRT)
			end
			local health = getElementHealth(thisPlayer)*2.55
			local r,g = 255-health,health
			local colorizePed = {r/255, g/255, 0, 1} -- rgba colors 
			dxSetShaderValue(wallShader[thisPlayer], "sColorizePed",colorizePed)
			dxSetShaderValue(wallShader[thisPlayer], "sSpecularPower",specularPower)
			engineApplyShaderToWorldTexture ( wallShader[thisPlayer], "*" , thisPlayer )
			engineRemoveShaderFromWorldTexture(wallShader[thisPlayer],"muzzle_texture*", thisPlayer)
			if not isMRT then
				if getElementAlpha(thisPlayer)==255 then setElementAlpha(thisPlayer, 254) end
			end
		return true
		end
    end
end
function destroyShaderForPlayer(thisPlayer)
    if wallShader[thisPlayer] then
		engineRemoveShaderFromWorldTexture(wallShader[thisPlayer], "*" , thisPlayer)
		destroyElement(wallShader[thisPlayer])
		wallShader[thisPlayer] = nil
	end
end
function enablePedWallTimer(isMRT)
	if PWenTimer then 
		return 
	end
	PWenTimer = setTimer(	function()
		if showWall and pwEffectEnabled then 
			effectOn = true
		else 
			effectOn = false			
		end
		for index,thisPlayer in ipairs(getElementsByType("ped")) do
			if isElementStreamedIn(thisPlayer) and thisPlayer~=localPlayer then
				local hx,hy,hz = getElementPosition(thisPlayer)            
				local cx,cy,cz = getCameraMatrix()
				local dist = getDistanceBetweenPoints3D(cx,cy,cz,hx,hy,hz)
				local isItClear = isLineOfSightClear (cx,cy,cz, hx,hy, hz, true, false, false, true, false, true, false, thisPlayer)
				if (dist<effectMaxDistance ) and not isItClear and effectOn then 
					createWallEffectForPlayer(thisPlayer, isMRT)
				end 
				if (dist>effectMaxDistance ) or  isItClear or not effectOn then 
					destroyShaderForPlayer(thisPlayer) 
				end
			end
			if not isElementStreamedIn(thisPlayer) then destroyShaderForPlayer(thisPlayer) end
		end
	end
	,PWTimerUpdate,0 )
end
function disablePedWallTimer()
	if PWenTimer then
		for index,thisPlayer in ipairs(getElementsByType("player")) do
			destroyShaderForPlayer(thisPlayer)
		end
		killTimer( PWenTimer )
		PWenTimer = nil		
	end
end
addEventHandler("onClientPreRender",root,function()
	if not pwEffectEnabled or not isMRTEnabled or not effectOn then return end
	-- Clear secondary render target
	dxSetRenderTarget( myRT, true )
	dxSetRenderTarget()
	for pl,sh in pairs(wallShader) do
		if isElement(pl) then
			local health = getElementHealth(pl)*2.55
			local r,g = 255-health,health
			local colorizePed = {r/255, g/255, 0, 1} -- rgba colors 
			dxSetShaderValue(sh, "sColorizePed",colorizePed)
		end
	end
end,true,"high")
addEventHandler("onClientHUDRender",root,function()
	if not pwEffectEnabled or not isMRTEnabled or not effectOn then return end
	-- Show contents of secondary render target
	dxDrawImage( 0, 0, scx, scy, myShader )
end)
