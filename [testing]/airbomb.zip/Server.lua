Timers = {}

function attach(playerSource, commandName)
	if isPedInVehicle(playerSource) == true then
		x,y,z = getElementPosition(playerSource)
		rx,ry,rz = getVehicleRotation(getPedOccupiedVehicle(playerSource))
		attachedElements = getAttachedElements(getPedOccupiedVehicle(playerSource))

		if next(attachedElements) == nil then
			missile   = createObject(3786,x,y,z,rx,ry,rz)
			-- attachElements(flowerpot,getPedOccupiedVehicle(playerSource),0,0,-1.7,rz,ry,rz)
			attachElements(missile,getPedOccupiedVehicle(playerSource),0,0,-1.1,0,355,270)
		else
			for ElementKey, ElementValue in ipairs ( attachedElements ) do
				detachElements(ElementValue)
				vx,vy,vz = getElementVelocity(getPedOccupiedVehicle(playerSource))
				flowerpot = createVehicle(594, x,y,z-2,rx,ry,rz)
				setElementVelocity(flowerpot,vx,vy,vz)
				setElementAlpha ( flowerpot, 0 )
				attachElements(ElementValue,flowerpot,0,0,0,0,0,270)
				for i = 1,50 do
					if Timers[i] == null then
						Timers[i] = setTimer(checkBlow, 100,500, flowerpot, playerSource, i)
						break
					end
				end
			end
		end
	end
end

function checkBlow(theBomb, thePlayer, index)
	vx,vy,vz = getElementVelocity(theBomb)
	vehicle1x, vehicle1y, vehicle1z = getElementPosition ( theBomb )
	if isPedInVehicle(thePlayer) then
		vehicle2x, vehicle2y, vehicle2z = getElementPosition ( getPedOccupiedVehicle(thePlayer) )
	else
		return
	end



	 if vz == 0 and getDistanceBetweenPoints3D ( vehicle1x, vehicle1y, vehicle1z, vehicle2x,vehicle2y, vehicle2z ) > 20 then
		local x,y,z = getElementPosition(theBomb)
		createExplosion ( x,y,z, 0)
		createExplosion ( x+10,y,z, 0)
		createExplosion ( x,y+10,z, 0)
		createExplosion ( x-10,y,z, 0)
		createExplosion ( x,y-10,z, 0)
		killTimer(Timers[index])
		Timers[index] = null
		-- blowVehicle(theBomb)
	 end
end

--[[ function loadup()
	createMarker ( float x, float y, float z, [string theType,
end ]]--

addCommandHandler("airstrike", attach)
-- addEventHandler("onResourceStart",getResourceRootElement(getThisResource()),loadup)