camera = false;

controls = {
	{key = "w", ctrl = "accelerate", desc = "Yüksel"}, 
	{key = "a", ctrl = "vehicle_left", desc = "Sol"}, 
	{key = "s", ctrl = "brake_reverse", desc = "Alçal/Hız azalt"}, 
	{key = "d", ctrl = "vehicle_right", desc = "Sağ"},
	{key = "arrow_l", ctrl = "vehicle_left", desc = "Sol"}, 
	{key = "arrow_r", ctrl = "vehicle_right", desc = "Sağ"}, 
	{key = "arrow_u", ctrl = "steer_forward", desc = "Yukarı"},
	{key = "arrow_d", ctrl = "steer_back", desc = "Aşağı"},
	{key = "q", ctrl = "vehicle_look_left", desc = "Sola çevir"},
	{key = "e", ctrl = "vehicle_look_right", desc = "Sağa çevir"}, 
};
keys = {};

for i, v in ipairs (controls) do 
	keys[v.key] = v.ctrl;
end
	
entity = {};

local max_distance = 250;
local sx, sy = guiGetScreenSize ()
local state = true
local sourcePlayer = dxCreateScreenSource (sx, sy)
local sourceDrone = dxCreateScreenSource (sx, sy)

function checkDrone()
	if not mfx then 
		mfx, mfy, mfz = getCameraMatrix();
	end	
	if not isElement (entity.drone) then return; end
	local px, py, pz = getElementPosition (localPlayer);
	local dx, dy, dz = getElementPosition (entity.drone);
	local _, _, rot = getElementRotation (entity.drone);
	if state and sourcePlayer and sourceDrone then 
		state = false
		local matrix = entity.drone.matrix;
		local angle = entity.drone.position + (matrix.up*1.5) - (matrix.forward * 2.5);
		if camera then
			local new = Vector3(0, 1.8, 0);
			local pos = matrix:transformPosition(new);
			angle = pos - (matrix.forward*2);
			entity.drone:setAlpha(0);
		else
			entity.drone:setAlpha(255);
		end	
		offX, offY, offZ = angle.x, angle.y, angle.z;
		setCameraMatrix(offX, offY, offZ, dx, dy, dz, 0, 180)
		dxUpdateScreenSource (sourcePlayer)
	elseif sourcePlayer and sourceDrone then
		setCameraMatrix (mfx, mfy, mfz, px, py, pz, 0, 180)
		state = true
		dxUpdateScreenSource (sourceDrone)
	end	
	
	local distance = getDistanceBetweenPoints3D (dx, dy, dz, px, py, pz)
	local info = {};
	for i, v in ipairs (controls) do 
		local color;
		if getKeyState(v.key) then 
			color = tocolor(0, 255, 0, 255);
		end	
		table.insert (info, {text = v.desc.." - "..v.key, color = color});
	end	
	table.insert (info, {text = "Rotasyon: "..rot});
	local adjustment = (distance / ((max_distance) / 100)) * 2.55;
	local color = tocolor(adjustment, 255 - adjustment, 0, 255);
	if distance > max_distance - 40 then 
		table.insert (info, {text = "Uzaklık: "..distance.. " (BAĞLANTI KOPMAK ÜZERE!!!)", color = tocolor (255, 0, 0, 255)});
	else	
		table.insert (info, {text = "Uzaklık: "..distance, color = color});
	end	
		
	dxDrawImage (0, 0, sx, sy, sourcePlayer);
	local x, y, w, h = sx * 0.6569, sy * 0.4256, sx * 0.3056, sy * 0.3350;
	dxDrawRectangle (x-12, y-12, w+24, h+200, tocolor(0, 0, 0, 125), false);
	dxDrawImage (x, y, w, h, sourceDrone);
	for i, v in ipairs (info) do 
		dxDrawText (v.text, x, (y+h+2) + ((i-1) * 15), w+24, 10, v.color or tocolor(255, 255, 255, 255));
	end	
	
	if distance > max_distance then 
		stopDrone();
	end	
	
	for i, v in ipairs (controls) do 
		moveDrone(keys[v.key], getKeyState(v.key));
	end	
	
	for i, v in ipairs (getElementsByType"player") do
		if isPlayerNametagShowing(v) then 
			setPlayerNametagShowing(v, false);
		end		
	end	
end	