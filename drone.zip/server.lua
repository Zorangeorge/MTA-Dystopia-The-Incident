function loadSettingsRecursively(node, cache)
	local cache = cache or {};
	
	for i, child in ipairs (xmlNodeGetChildren (node)) do 
		local nodeName = xmlNodeGetName (child);
		local prefix = xmlNodeGetAttribute (child, "prefix");
		if nodeName ~= "group" then 			
			local value = xmlNodeGetAttribute (child, "value");
			if prefix then 
				cache[prefix] = value;
			else
				cache[i] = value;
			end	
		else
			cache[prefix] = {};
			loadSettingsRecursively(child, cache[prefix]);
		end
	end
	return cache;
end

local config = xmlLoadFile("config/settings.xml");
local settings = loadSettingsRecursively(config);
xmlUnloadFile(config)

local msg = settings.msg;
local gm = settings.main.gm == "Freeroam" and "Freeroam" or "RolePlay";

local players = {};
local valid_models = {
	[501] = "Drone",
	-- [465] = "Oyuncak Helikopter 2",
	-- [464] = "Drone",
};

function startDrone(player, id)
	if players[player] then 
		errMsg (msg.ALREADY_HAS_DRONE:format("droned"), player);
		return;
	end	
	players[player] = {};
	local x,y,z = getElementPosition(player)
	local drone = createVehicle(id, x+1.5, y+1.5, z)
	local ped = createPed(180, x+1.5, y+1.5, z)
	players[player].drone = drone;
	players[player].ped = ped
	setElementAlpha(ped, 0)
	warpPedIntoVehicle(ped, drone)
	giveWeapon(player, 40, 1, true)
	triggerClientEvent(player, "drone.start", resourceRoot, drone, ped)
	setPedAnimation(player, "CAMERA", "camstnd_lkabt",-1, false, false, false, true)
	toggleAllControls (player, false, true, false);
	addEventHandler ("onVehicleExplode", drone, function () stopDrone(player) end);	
	addEventHandler ("onElementDestroy", drone, function () stopDrone(player) end);
end

function stopDrone(player)
	if not players[player] then return false; end
	local ped = players[player].ped;
	local drone = players[player].drone;
	
	if isElement (drone) and isElement (ped) and eventName ~= "onElementDestroy" then 
		drone:destroy();
		ped:destroy();	
	end	
	takeWeapon(player, 40);
	player:setAnimation();
	if eventName ~= "onResourceStop" then 
		triggerClientEvent (player, "drone.stop", player);
	end	
	players[player] = nil;
end

function droneHelp(player)
	if gm == "RolePlay" then 
		output (msg.HELP_CMD_START, player);
		output (msg.HELP_CMD_STOP, player);
		output (msg.HELP_VALID_MODEL_TEXT, player);
		for i, v in pairs (valid_models) do 
			output (msg.HELP_VALID_MODELS:format(i, v), player);
		end
	else
		--gui
	end	
end

addCommandHandler ("droneyardim", 
	function (player)
		droneHelp(player);
	end
);	

addCommandHandler ("drone",
	function (player, cmd, ...)
		local id = arg[1] or 501;
		if tonumber (id) then 
			id=tonumber(id);
			if valid_models[id] then 
				startDrone (player, id);
			else
				errMsg (msg.INVALID_ID, player);
			end
		else
			errMsg (msg.INVALID_ID, player);
		end
	end
);	

addCommandHandler ("droned",
	function (player)
		if players[player] then 
			stopDrone(player);
		end
	end
);	

addEvent ("drone.stop", true);
addEvent ("drone.ctrl", true);

addEventHandler ("drone.ctrl", root, 
	function (ped, ctrl, state)
		triggerClientEvent (root, "drone.ctrl_c", resourceRoot, ped, ctrl, state);
	end
);

addEventHandler ("drone.stop", root, 
	function ()
		stopDrone(client);
	end
);	

addEventHandler ("onResourceStop", resourceRoot,
	function ()
		for i in pairs (players) do 
			stopDrone(i);
		end
	end
);	

addEventHandler ("onPlayerQuit", root, 
	function ()
		stopDrone(source);
	end
);	

addEventHandler ("onPlayerWasted", root, 
	function ()
		stopDrone(source);
	end
);

function errMsg(msg_, player)
	return outputChatBox(msg_, player, 255, 0, 0, true);
end	

function output(msg_, player)
	return outputChatBox(msg_, player, 255, 255, 255, true);
end	